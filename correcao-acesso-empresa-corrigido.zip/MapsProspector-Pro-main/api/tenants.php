<?php
/**
 * API de Empresas (Tenants) - SaaS
 * Endpoint: /api/tenants.php
 * Apenas super_admin pode listar, criar, editar e desativar empresas.
 */

ob_start();

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

ob_clean();

$userId = requireSuperAdmin();
$db = Database::getInstance()->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $id = isset($_GET['id']) ? (int) $_GET['id'] : null;

    if ($id) {
        try {
            $stmt = $db->prepare("
                SELECT t.id, t.name, t.slug, t.plan_id, t.plan_access_until, t.status, t.created_at, t.updated_at,
                       p.name as plan_name, p.token_limit as plan_token_limit,
                       (SELECT u.email FROM users u WHERE u.tenant_id = t.id ORDER BY (u.profile = 'admin') DESC, u.id ASC LIMIT 1) as admin_email
                FROM tenants t
                LEFT JOIN plans p ON p.id = t.plan_id
                WHERE t.id = ?
            ");
            $stmt->execute([$id]);
            $tenant = $stmt->fetch();
        } catch (PDOException $e) {
            error_log("tenants.php GET id: " . $e->getMessage());
            jsonError('Erro ao buscar empresa. Verifique se a tabela tenants existe.', 500);
        }
        if (!$tenant) {
            jsonError('Empresa não encontrada', 404);
        }
        $tenant['id'] = (string) $tenant['id'];
        $tenant['planId'] = isset($tenant['plan_id']) ? (string) $tenant['plan_id'] : '1';
        $tenant['planAccessUntil'] = $tenant['plan_access_until'];
        $tenant['plan'] = $tenant['plan_name'] ?? 'Básico';
        $tenant['planTokenLimit'] = isset($tenant['plan_token_limit']) ? (int) $tenant['plan_token_limit'] : 100;
        $tenant['email'] = isset($tenant['admin_email']) ? trim($tenant['admin_email']) : '';
        if ($tenant['email'] === '' && (int) $tenant['id'] !== 1) {
            $legacyAdmins = mpFindLegacyTenantAdmins($db, (int) $tenant['id']);
            if (count($legacyAdmins) === 1) {
                $tenant['email'] = trim((string) ($legacyAdmins[0]['email'] ?? ''));
            }
        }
        $tenant['createdAt'] = $tenant['created_at'];
        $tenant['updatedAt'] = $tenant['updated_at'];
        unset($tenant['plan_id'], $tenant['plan_access_until'], $tenant['plan_name'], $tenant['plan_token_limit'], $tenant['admin_email'], $tenant['created_at'], $tenant['updated_at']);
        jsonSuccess($tenant);
    }

    try {
        $stmt = $db->query("
            SELECT t.id, t.name, t.slug, t.plan_id, t.plan_access_until, t.status, t.created_at,
                   p.name as plan_name, p.token_limit as plan_token_limit,
                   (SELECT COUNT(*) FROM users u WHERE u.tenant_id = t.id) as users_count,
                   (SELECT u.email FROM users u WHERE u.tenant_id = t.id ORDER BY (u.profile = 'admin') DESC, u.id ASC LIMIT 1) as admin_email
            FROM tenants t
            LEFT JOIN plans p ON p.id = t.plan_id
            WHERE t.id != 1
            ORDER BY t.created_at DESC, t.name ASC
        ");
        $tenants = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $totalCount = count($tenants);
        foreach ($tenants as &$row) {
            $tenantId = (int) $row['id'];
            $row['id'] = (string) $row['id'];
            $row['planId'] = isset($row['plan_id']) ? (string) $row['plan_id'] : '1';
            $row['planAccessUntil'] = $row['plan_access_until'];
            $row['plan'] = $row['plan_name'] ?? 'Básico';
            $row['planTokenLimit'] = isset($row['plan_token_limit']) ? (int) $row['plan_token_limit'] : 100;
            $row['usersCount'] = (int) ($row['users_count'] ?? 0);
            $row['email'] = isset($row['admin_email']) ? trim($row['admin_email']) : '';
            if ($row['usersCount'] === 0) {
                $legacyAdmins = mpFindLegacyTenantAdmins($db, $tenantId);
                $row['usersCount'] = count($legacyAdmins);
                if (count($legacyAdmins) === 1) {
                    $row['email'] = trim((string) ($legacyAdmins[0]['email'] ?? ''));
                }
            }
            $row['createdAt'] = isset($row['created_at']) ? (string) $row['created_at'] : '';
            $planLimit = getTenantPlanTokenLimit($db, $tenantId);
            $bonus = getTenantTokenBonus($db, $tenantId, null);
            $row['tokensUsed'] = getTenantTokensUsed($db, $tenantId, null);
            $row['tokensLimit'] = $planLimit > 0 ? $planLimit + $bonus : 0;
            unset($row['plan_id'], $row['plan_access_until'], $row['plan_name'], $row['plan_token_limit'], $row['users_count'], $row['admin_email'], $row['created_at']);
        }
        unset($row);
        jsonSuccess(['items' => $tenants, 'total' => $totalCount]);
    } catch (PDOException $e) {
        error_log("tenants.php GET list: " . $e->getMessage());
        $msg = $e->getMessage();
        if (strpos($msg, 'exist') !== false || strpos($msg, '1146') !== false) {
            jsonError('Tabela de empresas não existe. Execute database_migration_saas.sql no banco de dados.', 500);
        }
        jsonError('Erro ao listar empresas. Execute a migração database_migration_saas.sql no banco de dados.', 500);
    }

} elseif ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $name = sanitizeInput($input['name'] ?? '');
    $slug = sanitizeInput($input['slug'] ?? '');
    $planId = isset($input['planId']) ? (int) $input['planId'] : 1;
    $status = isset($input['status']) ? sanitizeInput($input['status']) : 'active';
    
    $adminName = sanitizeInput($input['adminName'] ?? '');
    $adminEmail = isset($input['adminEmail']) ? trim(strtolower($input['adminEmail'])) : '';
    $adminPassword = $input['adminPassword'] ?? '';

    if (empty($name)) {
        jsonError('Nome da empresa é obrigatório', 400);
    }

    if (empty($slug)) {
        $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $name));
        $slug = trim($slug, '-');
    }
    if (empty($slug)) {
        jsonError('Slug inválido. Informe um identificador único (ex: minha-empresa).', 400);
    }

    $allowedStatus = ['active', 'suspended'];
    if (!in_array($status, $allowedStatus)) {
        $status = 'active';
    }

    if (empty($adminEmail)) {
        jsonError('E-mail do administrador é obrigatório', 400);
    }
    if (!filter_var($adminEmail, FILTER_VALIDATE_EMAIL)) {
        jsonError('E-mail inválido', 400);
    }
    if (empty($adminPassword) || strlen($adminPassword) < 6) {
        jsonError('Senha do administrador deve ter pelo menos 6 caracteres', 400);
    }
    if (empty($adminName)) {
        $adminName = $name;
    }

    try {
        $stmt = $db->prepare("SELECT id FROM plans WHERE id = ? AND status = 'active'");
        $stmt->execute([$planId]);
        if (!$stmt->fetch()) {
            jsonError('Plano selecionado não existe ou está inativo. Escolha um plano válido.', 400);
        }

        $stmt = $db->prepare("SELECT id FROM tenants WHERE slug = ?");
        $stmt->execute([$slug]);
        if ($stmt->fetch()) {
            jsonError('Já existe uma empresa com este identificador (slug). Escolha outro.', 400);
        }

        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$adminEmail]);
        if ($stmt->fetch()) {
            jsonError('Já existe um usuário com este e-mail. Escolha outro.', 400);
        }

        $db->beginTransaction();

        $stmt = $db->prepare("INSERT INTO tenants (name, slug, plan_id, status) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $slug, $planId, $status]);
        $newId = (int) $db->lastInsertId();

        $hashedPassword = password_hash($adminPassword, PASSWORD_DEFAULT);
        $stmt = $db->prepare("INSERT INTO users (name, email, password, tenant_id, profile) VALUES (?, ?, ?, ?, 'admin')");
        $stmt->execute([$adminName, $adminEmail, $hashedPassword, $newId]);
        $userId = (int) $db->lastInsertId();

        $db->commit();

        $stmt = $db->prepare("
            SELECT t.id, t.name, t.slug, t.plan_id, t.status, t.created_at, p.name as plan_name, p.token_limit as plan_token_limit
            FROM tenants t LEFT JOIN plans p ON p.id = t.plan_id WHERE t.id = ?
        ");
        $stmt->execute([$newId]);
        $tenant = $stmt->fetch();
        $tenant['id'] = (string) $tenant['id'];
        $tenant['planId'] = (string) $tenant['plan_id'];
        $tenant['plan'] = $tenant['plan_name'] ?? 'Básico';
        $tenant['planTokenLimit'] = isset($tenant['plan_token_limit']) ? (int) $tenant['plan_token_limit'] : 100;
        $tenant['createdAt'] = $tenant['created_at'];
        $tenant['adminEmail'] = $adminEmail;
        $tenant['adminUserId'] = (string) $userId;
        unset($tenant['plan_id'], $tenant['plan_name'], $tenant['plan_token_limit'], $tenant['created_at']);
        jsonSuccess($tenant, 'Empresa e usuário administrador criados com sucesso');
    } catch (PDOException $e) {
        if (isset($db) && $db->inTransaction()) {
            $db->rollBack();
        }
        error_log("Erro ao criar tenant: " . $e->getMessage());
        jsonError('Erro ao criar empresa. Execute database_migration_plans.sql se a coluna plan_id não existir.', 500);
    }

} elseif ($method === 'PUT') {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    if (($input['action'] ?? '') === 'set_plan_due_date') {
        $id = isset($input['id']) ? (int) $input['id'] : 0;
        $rawDueDate = $input['dueDate'] ?? null;
        $dueDate = $rawDueDate === null || $rawDueDate === '' ? null : trim((string) $rawDueDate);
        if ($id <= 1) {
            jsonError('Selecione uma empresa válida.', 400);
        }
        if ($dueDate !== null) {
            if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $dueDate, $parts)
                || !checkdate((int) $parts[2], (int) $parts[3], (int) $parts[1])) {
                jsonError('Informe uma data de vencimento válida.', 422);
            }
        }
        try {
            $db->beginTransaction();
            $stmt = $db->prepare('SELECT plan_access_until FROM tenants WHERE id = ? FOR UPDATE');
            $stmt->execute([$id]);
            $currentDueDate = $stmt->fetchColumn();
            if ($currentDueDate === false) {
                $db->rollBack();
                jsonError('Empresa não encontrada.', 404);
            }
            $db->prepare('UPDATE tenants SET plan_access_until = ? WHERE id = ?')->execute([$dueDate, $id]);
            $db->prepare(
                "UPDATE asaas_subscriptions
                    SET access_until = ?
                  WHERE tenant_id = ? AND COALESCE(product_kind, 'prospecting') = 'prospecting'
                    AND status IN ('pending', 'active', 'overdue')"
            )->execute([$dueDate, $id]);
            $db->prepare(
                'INSERT INTO tenant_plan_due_date_audit
                    (tenant_id, old_due_date, new_due_date, changed_by_user_id)
                 VALUES (?, ?, ?, ?)'
            )->execute([$id, $currentDueDate ?: null, $dueDate, $userId]);
            $db->commit();
            jsonSuccess(['id' => (string) $id, 'planAccessUntil' => $dueDate], 'Vencimento do acesso atualizado. A data da próxima cobrança Asaas não foi alterada.');
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            error_log('tenants.php due date: ' . $e->getMessage());
            jsonError('Não foi possível atualizar o vencimento. Confirme se a migração de vencimentos foi aplicada.', 500);
        }
    }
    $id = isset($input['id']) ? (int) $input['id'] : 0;
    if (!$id) {
        jsonError('ID da empresa é obrigatório', 400);
    }

    $name = sanitizeInput($input['name'] ?? '');
    $slug = sanitizeInput($input['slug'] ?? '');
    $planId = isset($input['planId']) ? (int) $input['planId'] : null;
    $status = isset($input['status']) ? sanitizeInput($input['status']) : null;
    $emailRaw = isset($input['email']) ? trim(strtolower($input['email'])) : '';

    $stmt = $db->prepare("SELECT id FROM tenants WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonError('Empresa não encontrada', 404);
    }

    $updates = [];
    $params = [];
    if ($name !== '') {
        $updates[] = "name = ?";
        $params[] = $name;
    }
    if ($slug !== '') {
        $stmt = $db->prepare("SELECT id FROM tenants WHERE slug = ? AND id != ?");
        $stmt->execute([$slug, $id]);
        if ($stmt->fetch()) {
            jsonError('Já existe outra empresa com este identificador (slug).', 400);
        }
        $updates[] = "slug = ?";
        $params[] = $slug;
    }
    if ($planId !== null && $planId > 0) {
        $stmt = $db->prepare("SELECT id FROM plans WHERE id = ? AND status = 'active'");
        $stmt->execute([$planId]);
        if (!$stmt->fetch()) {
            jsonError('Plano selecionado não existe ou está inativo.', 400);
        }
        $updates[] = "plan_id = ?";
        $params[] = $planId;
    }
    if ($status !== null && in_array($status, ['active', 'suspended'])) {
        $updates[] = "status = ?";
        $params[] = $status;
    }

    if ($emailRaw !== '') {
        if (!validateEmail($emailRaw)) {
            jsonError('E-mail inválido.', 400);
        }
        $adminUser = $db->prepare("SELECT id FROM users WHERE tenant_id = ? ORDER BY (profile = 'admin') DESC, id ASC LIMIT 1");
        $adminUser->execute([$id]);
        $adminRow = $adminUser->fetch(PDO::FETCH_ASSOC);
        if (!$adminRow) {
            $legacyAdmins = mpFindLegacyTenantAdmins($db, $id);
            if (count($legacyAdmins) > 1) {
                jsonError('Há mais de uma conta legada possível para esta empresa. Revise o vínculo antes de alterar o e-mail.', 409);
            }
            $adminRow = $legacyAdmins[0] ?? null;
        }
        if (!$adminRow) {
            jsonError('Não foi encontrada uma conta de administrador vinculada a esta empresa.', 404);
        }

        $stmt = $db->prepare('SELECT id FROM users WHERE email = ? AND id != ? LIMIT 1');
        $stmt->execute([$emailRaw, (int) $adminRow['id']]);
        if ($stmt->fetch()) {
            jsonError('Este e-mail já está em uso por outra conta.', 400);
        }
        $db->prepare('UPDATE users SET email = ? WHERE id = ?')->execute([$emailRaw, (int) $adminRow['id']]);
    }

    if (empty($updates)) {
        if ($emailRaw === '') {
            jsonError('Nenhum campo para atualizar', 400);
        }
    } else {
        $params[] = $id;
        $sql = "UPDATE tenants SET " . implode(', ', $updates) . " WHERE id = ?";
        $db->prepare($sql)->execute($params);
    }

    $stmt = $db->prepare("
        SELECT t.id, t.name, t.slug, t.plan_id, t.status, t.created_at, t.updated_at, p.name as plan_name, p.token_limit as plan_token_limit,
               (SELECT u.email FROM users u WHERE u.tenant_id = t.id ORDER BY (u.profile = 'admin') DESC, u.id ASC LIMIT 1) as admin_email
        FROM tenants t LEFT JOIN plans p ON p.id = t.plan_id WHERE t.id = ?
    ");
    $stmt->execute([$id]);
    $tenant = $stmt->fetch();
    $tenant['id'] = (string) $tenant['id'];
    $tenant['planId'] = isset($tenant['plan_id']) ? (string) $tenant['plan_id'] : '1';
    $tenant['plan'] = $tenant['plan_name'] ?? 'Básico';
    $tenant['planTokenLimit'] = isset($tenant['plan_token_limit']) ? (int) $tenant['plan_token_limit'] : 100;
    $tenant['email'] = isset($tenant['admin_email']) ? trim($tenant['admin_email']) : '';
    if ($tenant['email'] === '') {
        $legacyAdmins = mpFindLegacyTenantAdmins($db, $id);
        if (count($legacyAdmins) === 1) {
            $tenant['email'] = trim((string) ($legacyAdmins[0]['email'] ?? ''));
        }
    }
    $tenant['createdAt'] = $tenant['created_at'];
    $tenant['updatedAt'] = $tenant['updated_at'];
    unset($tenant['plan_id'], $tenant['plan_name'], $tenant['plan_token_limit'], $tenant['admin_email'], $tenant['created_at'], $tenant['updated_at']);
    jsonSuccess($tenant, 'Empresa atualizada com sucesso');

} elseif ($method === 'DELETE') {
    $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
    if (!$id) {
        jsonError('ID da empresa é obrigatório', 400);
    }
    if ($id === 1) {
        jsonError('Não é permitido excluir a empresa padrão.', 400);
    }

    $stmt = $db->prepare("SELECT id, status FROM tenants WHERE id = ?");
    $stmt->execute([$id]);
    $tenant = $stmt->fetch();
    if (!$tenant) {
        jsonError('Empresa não encontrada', 404);
    }
    if (($tenant['status'] ?? '') !== 'suspended') {
        jsonError('Só é possível excluir uma empresa que esteja desativada. Desative-a antes de excluir.', 400);
    }

    $db->prepare("UPDATE users SET tenant_id = 1 WHERE tenant_id = ?")->execute([$id]);
    $db->prepare("DELETE FROM tenants WHERE id = ?")->execute([$id]);
    jsonSuccess(null, 'Empresa removida com sucesso');

} else {
    jsonError('Método não permitido', 405);
}
