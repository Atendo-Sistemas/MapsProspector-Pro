# Database – MapsProspector Pro

Scripts SQL para importação do schema em outro ambiente (MySQL/MariaDB).

## Arquivo principal (instalação em outro lugar)

| Arquivo | Descrição |
|--------|-----------|
| `maps_schema_full.sql` | **Schema completo para nova instalação.** Tabelas, FKs e dados iniciais (seed). Basta executar este arquivo no MySQL/MariaDB; nenhuma migração adicional é obrigatória. |

## Uso – quando instalar em outro lugar

1. **Nova instalação**  
   Execute **apenas** `maps_schema_full.sql` no MySQL/MariaDB (phpMyAdmin, linha de comando ou cliente).  
   O script cria o banco `maps` (se não existir), todas as tabelas, chaves estrangeiras e dados iniciais (planos Básico e Período de teste, tenant padrão, usuário admin, `platform_settings`).

2. **Outro nome de banco**  
   Abra `maps_schema_full.sql`, altere o nome em `CREATE DATABASE` e em `USE` para o banco desejado.

3. **Após a importação**  
   Acesse o sistema com `admin@atendo.maps` / senha `admin123` e **altere a senha do admin** em produção.

4. **Reexecução no mesmo banco**  
   O script usa `CREATE TABLE IF NOT EXISTS` e `ON DUPLICATE KEY` nos inserts. As `ALTER TABLE ... ADD CONSTRAINT` não são idempotentes: para rodar de novo no mesmo banco, use um banco vazio ou remova/drop das tabelas antes.

## Tabelas incluídas (em maps_schema_full.sql)

- `plans` – Planos e limites de tokens
- `tenants` – Empresas (multi-tenant)
- `users` – Usuários (com campo `password` para login)
- `settings` – Configurações por usuário (webhook, CRM)
- `search_history` – Histórico de buscas
- `leads` – Leads das buscas
- `sessions` – Sessões
- `tenant_usage` – Uso de tokens por tenant/período
- `credit_requests` – Solicitações de créditos
- `plan_requests` – Solicitações de mudança de plano
- `payments` – Pedidos e registros de pagamento manual
- `payment_bonus_grants` – Controle idempotente de bônus de contratação
- `lead_unlocks` – Leads desbloqueados por usuário
- `platform_settings` – Configurações globais (chave API de busca, preço avulso, nome SaaS)

## Requisitos

- MySQL 5.7+ ou MariaDB 10.2+
- Charset: `utf8mb4`, collation: `utf8mb4_unicode_ci`

## Módulo de pagamentos e vencimentos

O schema completo já cria `payments` e `payment_bonus_grants`. Em bancos existentes, execute `database_migration_manual_payments.sql` para que a criação e a aprovação manuais de compras funcionem; essa migração é segura para reexecução. Ela usa o banco `maps`; ajuste a cláusula `USE` se necessário.

Na aba Solicitações, o super administrador pode conceder de 1 a 10.000 créditos sem cobrança. Eles integram o bônus do período atual (mensal ou anual); o registro da operação, administrador e quantidade fica em `payment_bonus_grants`. A tabela deve existir antes do uso. Se a resposta de uma concessão não chegar, mantenha a mesma aba e use o botão novamente para conferir a operação sem duplicá-la.

Se uma cobrança Asaas ficar pendente sem link após uma falha, confira o pedido e a referência no painel Asaas antes de tomar qualquer ação ou tentar outra cobrança; a aplicação não cria outra cobrança igual enquanto esse pedido estiver pendente. Um webhook de pagamento confirmado continua liberando os créditos.

Para assinar mensalmente pelo Asaas, o gateway precisa estar ativo, com chave e token de webhook configurados, tabelas `asaas_orders` e `asaas_subscriptions` e coluna `asaas_subscriptions.product_kind`. Quando o automático estiver indisponível, o botão informa o erro e não abre pedido manual; a opção manual continua separada. Solicitações manuais pendentes devem ser analisadas antes de iniciar uma contratação automática. Confira no Asaas se já existe assinatura antes de recusar uma solicitação e tentar novamente.

A configuração do Asaas fica em **Empresa SaaS → Pagamentos (Asaas)**. A chave de API autoriza chamadas ao Asaas; o token de webhook, distinto da chave, autentica as notificações recebidas. Campos de credenciais vazios mantêm os valores existentes. Ao gerar ou rotacionar o token, ele é alterado imediatamente: copie o novo valor exibido e atualize o token do webhook no painel Asaas, ou as notificações deixarão de ser autenticadas. Se a operação não puder ser confirmada, verifique a configuração antes de tentar novamente.

Na Central de Notificações, configure separadamente os textos de seleção de plano com e sem CPF/CNPJ. A escolha usa o documento da empresa cadastrado no perfil (11 ou 14 dígitos); isso não valida o número junto à Receita nem confirma a aceitação pelo Asaas.

Para habilitar pagamentos Asaas em uma instalação nova ou existente, execute `sql/asaas-finance.sql` e depois `database_migration_billing_due_dates.sql`. A migração é reexecutável, completa os campos do catálogo de planos usados pela cobrança, adiciona o tipo de assinatura e cria os campos/tabela de auditoria para vencimentos administrativos.

## Migrações opcionais (apenas para instalações antigas)

Use estas migrações **somente** se você já tinha o banco criado por uma versão anterior e não está rodando `maps_schema_full.sql` do zero.

| Arquivo | Descrição |
|--------|-----------|
| `database_migration_plan_trial.sql` | Insere o plano **Período de teste** (10 créditos). O schema completo já inclui; use só se o banco foi criado antes. |
| `database_migration_user_password.sql` | Adiciona a coluna `password` na tabela `users`. O schema completo já inclui; use só em instalações antigas. |
| `database_migration_admin_password_fix.sql` | Corrige a senha do usuário admin para `admin123` (hash bcrypt). Use se o admin não conseguir entrar (hash antigo era para outra senha). |
| `database_migration_billing_due_dates.sql` | Adiciona o vencimento administrativo do acesso e completa o schema de assinaturas Asaas. |
| `database_migration_manual_payments.sql` | Cria os registros de pagamento e a tabela de idempotência de bônus necessários para solicitações e aprovações manuais. |
| `database_migration_password_search_permissions.sql` | Adiciona CNPJ/CPF da empresa, permissão de pesquisa por usuário, token de sessão e tokens para recuperação de senha. |
| `database_migration_search_quality.sql` | Cria telemetria agregada de qualidade das pesquisas Maps, LinkedIn e CNPJ, sem armazenar filtros, usuários ou empresas. |

A rota legada `api/cnpj-search-local.php` exige sessão autenticada com permissão de pesquisa e usa `CNPJ_LOCAL_DB_HOST`, `CNPJ_LOCAL_DB_NAME`, `CNPJ_LOCAL_DB_USER` e `CNPJ_LOCAL_DB_PASSWORD`. Sem essas variáveis, a rota permanece indisponível.

Para métricas de qualidade, aplique `database_migration_search_quality.sql` nos bancos existentes. O resumo de 30 dias fica restrito ao super administrador e não expõe datas individuais, filtros de busca ou dados por empresa. Nenhuma data de pesquisa reutilizada entre empresas é enviada ao usuário final.

## Dados iniciais

Após a importação existem:

- Planos **Básico** (id 1) e **Período de teste** (id 2, 10 créditos)
- Tenant **Nome da empresa SaaS** (id 1)
- Usuário **admin** (`admin@atendo.maps` / senha: `admin123`)
- Registro em `platform_settings` para `scraper_api_key`

Altere a senha do admin após o primeiro acesso.
