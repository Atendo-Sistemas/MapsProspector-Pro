<?php
declare(strict_types=1);
ini_set('display_errors', '0');
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../services/instagramApifyService.php';

try {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') jsonError('Método não permitido.', 405);
    $userId = (int) requireAuth();
    $auth = getAuthUser();
    $tenantId = (int) ($auth['tenant_id'] ?? 0);
    if ($tenantId <= 0) jsonError('Sua conta não possui uma empresa vinculada.', 403);
    $db = Database::getInstance()->getConnection();
    requireSearchPermission($db);
    $input = json_decode((string) file_get_contents('php://input'), true);
    if (!is_array($input)) jsonError('Dados da pesquisa inválidos.', 422);
    $mode = strtolower(trim((string) ($input['mode'] ?? 'post')));
    if (!in_array($mode, ['post', 'location'], true)) jsonError('Modo de pesquisa inválido.', 422);
    $postsLimit = max(1, min(20, (int) ($input['posts_limit'] ?? 5)));
    $commentsLimit = max(1, min(250, (int) ($input['comments_limit'] ?? 50)));
    $totalLimit = max($commentsLimit, min(500, (int) ($input['total_comments_limit'] ?? 300)));
    $includeReplies = !empty($input['include_replies']);
    $value = trim((string) ($input['value'] ?? ''));
    if ($value === '') jsonError($mode === 'post' ? 'Informe a URL da publicação ou Reel.' : 'Informe o local da pesquisa.', 422);

    $service = new InstagramApifyService($db);
    $normalized = null;
    if ($mode === 'post') {
        $value = InstagramApifyService::normalizeInstagramUrl($value);
        $started = $service->startComments($value, $commentsLimit, $includeReplies);
        $stage = 'comments';
    } else {
        $normalized = InstagramApifyService::normalizeLocation($value);
        $started = $service->startLocation($normalized, $postsLimit);
        $stage = 'posts';
    }

    $stmt = $db->prepare(
        'INSERT INTO instagram_runs
         (tenant_id, user_id, mode, input_value, normalized_location, status, stage, requested_posts, requested_comments, max_total_comments, external_run_id, dataset_id, actor_id, api_key_id, started_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())'
    );
    $stmt->execute([
        $tenantId, $userId, $mode, $value, $normalized, 'running', $stage,
        $mode === 'location' ? $postsLimit : 0, $commentsLimit, $totalLimit,
        $started['run_id'], $started['dataset_id'], $started['actor'], $started['key_id']
    ]);
    $runId = (int) $db->lastInsertId();
    jsonSuccess([
        'runId' => $runId,
        'status' => 'running',
        'stage' => $stage,
        'mode' => $mode,
        'postsLimit' => $postsLimit,
        'commentsLimit' => $commentsLimit,
        'totalCommentsLimit' => $totalLimit,
        'message' => $mode === 'location' ? 'Local recebido; publicações relacionadas estão sendo identificadas.' : 'Publicação recebida; comentários públicos estão sendo processados.'
    ]);
} catch (InvalidArgumentException $e) {
    jsonError($e->getMessage(), 422);
} catch (Throwable $e) {
    error_log('instagram-search: ' . $e->getMessage());
    jsonError('Não foi possível iniciar a pesquisa Instagram agora. Tente novamente.', 502);
}
