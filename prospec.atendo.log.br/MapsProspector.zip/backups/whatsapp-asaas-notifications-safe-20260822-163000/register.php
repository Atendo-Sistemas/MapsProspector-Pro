<?php
/**
 * API de Cadastro Público de Empresa com registro explícito de aceite.
 * Substitua /api/register.php por este arquivo somente após executar
 * sql/linkedin-implementacao.sql no banco.
 */

ob_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
ob_clean();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonError('Método não permitido', 405);
}

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$companyName = sanitizeInput(trim($input['companyName'] ?? $input['name'] ?? ''));
$slug = isset($input['slug']) ? sanitizeInput(trim($input['slug'])) : '';
$adminEmail = trim(strtolower($input['adminEmail'] ?? $input['email'] ?? ''));
$adminPhone = sanitizeInput(trim($input['adminPhone'] ?? $input['phone'] ?? ''));
$adminName = sanitizeInput(trim($input['adminName'] ?? ''));
$adminPassword = $input['adminPassword'] ?? $input['password'] ?? '';
$legalConsents = is_array($input['legalConsents'] ?? null) ? $input['legalConsents'] : [];
$termsConsent = is_array($legalConsents['terms_of_use'] ?? null) ? $legalConsents['terms_of_use'] : [];
$privacyConsent = is_array($legalConsents['privacy_policy'] ?? null) ? $legalConsents['privacy_policy'] : [];
$termsAccepted = ($termsConsent['accepted'] ?? false) === true;
$privacyAccepted = ($privacyConsent['accepted'] ?? false) === true;
// As versões são controladas no servidor. Uma alteração exige novo aceite,
// sem apagar as versões anteriores registradas em legal_consents.
$termsVersion = '2026-08-17';
$privacyVersion = '2026-08-17';
$termsUrl = 'termos.php';
$privacyUrl = 'privacidade.php';

if ($companyName === '') {
    jsonError('Nome da empresa é obrigatório', 400);
}
if ($adminPhone === '') {
    jsonError('O número de WhatsApp é obrigatório para o cadastro', 400);
}
if ($adminEmail === '' || !validateEmail($adminEmail)) {
    jsonError('E-mail do administrador é obrigatório e deve ser válido', 400);
}
if (strlen($adminPassword) < 6) {
    jsonError('A senha deve ter no mínimo 6 caracteres', 400);
}
if (!$termsAccepted || !$privacyAccepted) {
    jsonError('É necessário aceitar os Termos de Uso e a Política de Privacidade para criar a conta.', 400);
}

try {
    $db = Database::getInstance()->getConnection();
} catch (Exception $e) {
    jsonError($e->getMessage(), 500);
}

try {
    $db->query('SELECT 1 FROM tenants LIMIT 1');
    $db->query('SELECT 1 FROM legal_consents LIMIT 1');
} catch (PDOException $e) {
    if (strpos($e->getMessage(), 'legal_consents') !== false || strpos($e->getMessage(), '1146') !== false) {
        jsonError('A tabela de aceites não existe. Execute sql/linkedin-implementacao.sql no banco antes de habilitar o cadastro com termos.', 500);
    }
    jsonError('Estrutura de banco necessária para o cadastro não encontrada.', 500);
}

if ($slug === '') {
    $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $companyName));
    $slug = trim($slug, '-');
}
if ($slug === '' || strlen($slug) > 100) {
    jsonError('Não foi possível gerar um identificador válido para a empresa.', 400);
}
if ($adminName === '') {
    $adminName = ucfirst(explode('@', $adminEmail)[0]);
}

try {
    $stmt = $db->prepare('SELECT id FROM users WHERE email = ?');
    $stmt->execute([$adminEmail]);
    if ($stmt->fetch()) {
        jsonError('Este e-mail já está cadastrado. Use a tela de login para entrar.', 400);
    }

    $slugBase = $slug;
    for ($suffix = 1; $suffix <= 9999; $suffix++) {
        $slugToUse = $suffix === 1 ? $slugBase : $slugBase . '-' . $suffix;
        $stmt = $db->prepare('SELECT id FROM tenants WHERE slug = ?');
        $stmt->execute([$slugToUse]);
        if (!$stmt->fetch()) {
            $slug = $slugToUse;
            break;
        }
    }
    if ($suffix > 9999) {
        jsonError('Não foi possível gerar um identificador único. Tente outro nome.', 400);
    }

    $planId = 1;
    $planSlug = 'basic';
    try {
        $stmt = $db->prepare("SELECT id, slug FROM plans WHERE slug = 'trial' AND status = 'active' LIMIT 1");
        $stmt->execute();
        $trial = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($trial) {
            $planId = (int) $trial['id'];
            $planSlug = $trial['slug'];
        }
    } catch (PDOException $ignored) {
    }

    $db->beginTransaction();

    $stmt = $db->prepare("INSERT INTO tenants (name, slug, plan_id, plan, status) VALUES (?, ?, ?, ?, 'active')");
    $stmt->execute([$companyName, $slug, $planId, $planSlug]);
    $tenantId = (int) $db->lastInsertId();

    $passwordHash = password_hash($adminPassword, PASSWORD_DEFAULT);
    $stmt = $db->prepare('INSERT INTO users (name, email, phone, password, tenant_id, profile) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([$adminName, $adminEmail, $adminPhone, $passwordHash, $tenantId, 'admin']);
    $userId = (int) $db->lastInsertId();

    $userAgent = substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
    $stmt = $db->prepare(
        'INSERT INTO legal_consents
         (tenant_id, user_id, consent_key, document_version, document_url, source, accepted_at, user_agent)
         VALUES (?, ?, ?, ?, ?, ?, NOW(), ?)'
    );
    $stmt->execute([
        $tenantId, $userId, 'terms_of_use', $termsVersion,
        $termsUrl, 'company_registration', $userAgent,
    ]);
    $stmt->execute([
        $tenantId, $userId, 'privacy_policy', $privacyVersion,
        $privacyUrl, 'company_registration', $userAgent,
    ]);

    try {
        $stmt = $db->prepare('INSERT INTO settings (user_id, tenant_name) VALUES (?, ?)');
        $stmt->execute([$userId, $companyName]);
    } catch (PDOException $e) {
        error_log('register.php: não foi possível criar settings iniciais: ' . $e->getMessage());
    }

    $db->commit();

    try {
        require_once __DIR__ . '/../services/notificationService.php';
        NotificationService::notifyNewRegistration($db, $companyName, $adminEmail, $adminPhone);
    } catch (Exception $e) {
        error_log('register.php: erro ao enviar notificações de boas-vindas: ' . $e->getMessage());
    }

    jsonSuccess([
        'tenantId' => (string) $tenantId,
        'userId' => (string) $userId,
        'tenantName' => $companyName,
    ], 'Empresa cadastrada com sucesso. Faça login com seu e-mail.');
} catch (PDOException $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Erro ao registrar empresa: ' . $e->getMessage());
    jsonError('Erro ao cadastrar. Tente novamente.', 500);
}
