<?php
/**
 * Maps Prospector — Webhook Asaas para créditos e assinaturas recorrentes v65.0.0.
 *
 * URL configurada no Asaas: https://seudominio.com/webhook-asaas.php
 * O Asaas envia dois formatos:
 *   1. Evento (POST /v3/webhooks): JSON { id, event, payment: {...} }
 *      com header "asaas-access-token: <token configurado no painel>".
 *   2. Chamada simples de teste (GET): respondemos 200.
 *
 * Eventos de pagamento de assinatura mantêm o plano ativo apenas após a
 * confirmação. Inadimplência e cancelamento preservam o período já pago;
 * o rebaixamento é realizado pela rotina diária, também de forma idempotente.
 */

declare(strict_types=1);

ob_start();
ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/asaas-secrets.php';
require_once __DIR__ . '/services/AsaasSubscriptionService.php';
require_once __DIR__ . '/services/AsaasCommissionPayoutService.php';

header('Content-Type: application/json; charset=utf-8');

function whJson(int $status = 200, array $data = []): void
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function whGetSetting(PDO $db, string $key): string
{
    if (asaSecretKeyAllowed($key)) {
        return asaSecretGetOrMigrate($db, $key);
    }
    try {
        $stmt = $db->prepare('SELECT setting_value FROM platform_settings WHERE setting_key = ? LIMIT 1');
        $stmt->execute([$key]);
        $value = $stmt->fetchColumn();
        if ($value !== false) {
            return trim((string) $value);
        }
    } catch (Throwable $e) {
        error_log('webhook-asaas: setting read: ' . $e->getMessage());
    }
    if (function_exists('getPlatformSetting')) {
        return trim((string) (getPlatformSetting($db, $key) ?? ''));
    }
    return '';
}

function whTransferAuthorization(PDO $db, array $payload): void
{
    $transfer = is_array($payload['transfer'] ?? null) ? $payload['transfer'] : [];
    $transferId = trim((string) ($transfer['id'] ?? ''));
    $reference = trim((string) ($transfer['externalReference'] ?? ''));
    $valueCents = (int) round(((float) ($transfer['value'] ?? 0)) * 100);
    $pixKey = trim((string) ($transfer['pixAddressKey'] ?? ($transfer['bankAccount']['pixAddressKey'] ?? '')));
    if ($valueCents <= 0 || ($transferId === '' && $reference === '')) {
        whJson(200, ['status' => 'REFUSED', 'refuseReason' => 'Operação sem identificador ou valor válido.']);
    }
    $row = null;
    if ($transferId !== '') {
        $stmt = $db->prepare("SELECT wt.withdrawal_id, wt.amount_cents, wt.pix_key, wt.status, w.status AS withdrawal_status
            FROM referral_withdrawal_transfers wt
            INNER JOIN referral_withdrawals w ON w.id = wt.withdrawal_id
            WHERE wt.asaas_transfer_id = ? LIMIT 1");
        $stmt->execute([$transferId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    if (!is_array($row) && $reference !== '') {
        $stmt = $db->prepare("SELECT wt.withdrawal_id, wt.amount_cents, wt.pix_key, wt.status, w.status AS withdrawal_status
            FROM referral_withdrawal_transfers wt
            INNER JOIN referral_withdrawals w ON w.id = wt.withdrawal_id
            WHERE wt.external_reference = ? LIMIT 1");
        $stmt->execute([$reference]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    $valid = is_array($row)
        && (int) ($row['amount_cents'] ?? 0) === $valueCents
        && (string) ($row['withdrawal_status'] ?? '') === 'approved'
        && in_array(strtoupper((string) ($row['status'] ?? '')), ['CREATING', 'PENDING', 'BLOCKED'], true);
    if ($valid && $pixKey !== '') {
        $valid = hash_equals((string) ($row['pix_key'] ?? ''), $pixKey);
    }
    if (!$valid) {
        whJson(200, ['status' => 'REFUSED', 'refuseReason' => 'Transferência não encontrada ou divergente do saque aprovado.']);
    }
    whJson(200, ['status' => 'APPROVED']);
}

function whNotifySubscriptionConfirmed(PDO $db, string $subscriptionId, array $payment): void
{
    if ($subscriptionId === '') return;
    try {
        require_once __DIR__ . '/services/notificationService.php';
        if (!class_exists('NotificationService')) return;
        $stmt = $db->prepare(
            "SELECT s.tenant_id, s.product_kind, p.name AS product_name, t.name AS company_name,
                    u.id AS user_id, u.name AS user_name, u.email, u.phone
               FROM asaas_subscriptions s
               INNER JOIN tenants t ON t.id = s.tenant_id
               LEFT JOIN plans p ON p.id = s.plan_id
               LEFT JOIN users u ON u.tenant_id = s.tenant_id
              WHERE s.asaas_subscription_id = ?
              ORDER BY CASE WHEN u.profile = 'admin' THEN 0 ELSE 1 END, u.id ASC
              LIMIT 1"
        );
        $stmt->execute([$subscriptionId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row)) return;
        $companyName = (string) ($row['company_name'] ?? 'sua empresa');
        $productName = (string) ($row['product_name'] ?? 'Plano contratado');
        $clientReference = (string) ($row['user_id'] ?? $row['tenant_id'] ?? $subscriptionId);
        $phone = (string) ($row['phone'] ?? '');
        $paymentReference = (string) ($payment['id'] ?? $subscriptionId);
        if ((string) ($row['product_kind'] ?? 'prospecting') === 'crm_addon') {
            NotificationService::notifyCrmApproval($db, $companyName, $productName, $clientReference, $phone, $paymentReference);
        } else {
            NotificationService::notifyPlanApproval($db, $companyName, $productName, (string) ($row['email'] ?? ''), $phone, $paymentReference);
        }
    } catch (Throwable $e) {
        error_log('webhook-asaas: notificação de assinatura não enviada.');
    }
}

try {
    $db = Database::getInstance()->getConnection();
} catch (Throwable $e) {
    error_log('webhook-asaas: db connection: ' . $e->getMessage());
    whJson(200, []);
}

// Teste de configuração do Asaas (GET).
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    whJson(200, ['ok' => true]);
}

$token = trim((string) ($_SERVER['HTTP_ASAAS_ACCESS_TOKEN'] ?? ''));
$configuredToken = whGetSetting($db, 'asaas_webhook_token');

$rawInput = (string) file_get_contents('php://input');
$payload = json_decode($rawInput, true);
if (!is_array($payload)) {
    $payload = [];
}

// O token pode vir do cabeçalho padrão do Asaas ou, para testes via painel,
// da query string ?token=... . Se nenhum token foi configurado, o webhook
// responde 200 mas não processa eventos (sem processar duplicados).
$authorized = $token !== '' && $configuredToken !== '' && hash_equals($configuredToken, $token);
if (!$authorized) {
    $queryToken = trim((string) ($_GET['token'] ?? ''));
    if ($queryToken !== '' && $configuredToken !== '' && hash_equals($configuredToken, $queryToken)) {
        $authorized = true;
    }
}

if (!$authorized) {
    whJson(200, []);
}

// Este payload é o Webhook especial de autorização crítica de saques. Ele não
// possui `event`; deve ser avaliado a cada chamada e não deduplicado como um
// evento financeiro, porque o Asaas pode reenviar a solicitação até receber
// APPROVED/REFUSED.
if ((string) ($payload['type'] ?? '') === 'TRANSFER' && is_array($payload['transfer'] ?? null)) {
    whTransferAuthorization($db, $payload);
}

// O Asaas entrega o id da assinatura no pagamento recorrente ou no objeto
// subscription, dependendo do tipo do evento configurado.
$eventId = isset($payload['id']) ? substr((string) $payload['id'], 0, 64) : '';
$payment = is_array($payload['payment'] ?? null) ? $payload['payment'] : [];
$transfer = is_array($payload['transfer'] ?? null) ? $payload['transfer'] : [];
$eventType = (string) ($payload['event'] ?? '');
$paymentStatus = is_string($payment['status'] ?? null) ? strtoupper((string) $payment['status']) : '';
$paymentId = isset($payment['id']) ? substr((string) $payment['id'], 0, 64) : '';
$transferId = isset($transfer['id']) ? substr((string) $transfer['id'], 0, 128) : '';
$subscriptionPayload = $payload['subscription'] ?? null;
$subscriptionId = '';
if (isset($payment['subscription']) && is_string($payment['subscription'])) {
    $subscriptionId = trim((string) $payment['subscription']);
} elseif (is_array($subscriptionPayload) && isset($subscriptionPayload['id'])) {
    $subscriptionId = trim((string) $subscriptionPayload['id']);
} elseif (is_string($subscriptionPayload)) {
    $subscriptionId = trim($subscriptionPayload);
}
if ($eventId === '') {
    $eventId = substr(hash('sha256', $eventType . '|' . $paymentId . '|' . $transferId . '|' . $subscriptionId . '|' . $rawInput), 0, 64);
}

// Idempotência única para pagamentos avulsos e recorrentes: um mesmo evento
// só entra uma vez, mesmo quando o provedor faz novas tentativas de entrega.
try {
    $insert = $db->prepare(
        'INSERT IGNORE INTO asaas_webhook_events (webhook_event_id, payment_id, event_type, payload_json, processed)
         VALUES (?, ?, ?, ?, 0)'
    );
    $insert->execute([$eventId, $paymentId !== '' ? $paymentId : null, $eventType, mb_substr($rawInput, 0, 65000)]);
    if ($insert->rowCount() === 0) {
        whJson(200, []);
    }
} catch (Throwable $e) {
    error_log('webhook-asaas: event insert: ' . $e->getMessage());
    whJson(200, []);
}

try {
    $confirmedEvents = ['PAYMENT_RECEIVED', 'PAYMENT_CONFIRMED', 'SUBSCRIPTION_PAYMENT_CONFIRMED'];
    $overdueEvents = ['PAYMENT_OVERDUE', 'SUBSCRIPTION_PAYMENT_OVERDUE'];
    $cancelledEvents = ['SUBSCRIPTION_DELETED', 'SUBSCRIPTION_CANCELLED'];
    $transferEvents = ['TRANSFER_CREATED', 'TRANSFER_PENDING', 'TRANSFER_IN_BANK_PROCESSING', 'TRANSFER_BLOCKED', 'TRANSFER_DONE', 'TRANSFER_FAILED', 'TRANSFER_CANCELLED'];
    $isConfirmedPayment = in_array($eventType, $confirmedEvents, true)
        && in_array($paymentStatus, ['RECEIVED', 'CONFIRMED', 'SETTLED'], true);

    if (in_array($eventType, $transferEvents, true)) {
        MapsProspectorAsaasCommissionPayoutService::handleWebhook($db, $eventType, $payload);
    } elseif ($subscriptionId !== '' && $isConfirmedPayment) {
        if (mpAsaasConfirmSubscriptionPayment($db, $subscriptionId, $payment)) {
            whNotifySubscriptionConfirmed($db, $subscriptionId, $payment);
        }
    } elseif ($subscriptionId !== '' && in_array($eventType, $overdueEvents, true)) {
        mpAsaasMarkSubscriptionOverdue($db, $subscriptionId, $payment);
    } elseif ($subscriptionId !== '' && in_array($eventType, $cancelledEvents, true)) {
        mpAsaasMarkSubscriptionCancelled($db, $subscriptionId);
    } elseif ($subscriptionId === '' && in_array($eventType, ['PAYMENT_RECEIVED', 'PAYMENT_CONFIRMED'], true) && $isConfirmedPayment) {
        // Cobrança avulsa de créditos: comportamento legado preservado.
        $externalReference = isset($payment['externalReference']) ? (string) $payment['externalReference'] : '';

        // Localiza o pedido pelo external_reference (order_nsu) ou pelo
        // asaas_payment_id gravado na criação da cobrança.
        $stmt = $db->prepare(
            'SELECT * FROM asaas_orders
              WHERE status = \'pending\'
                AND (order_nsu = ?
                     OR CONCAT(\'MP-CREDITS|T\', tenant_id, \'|\', order_nsu) = ?
                     OR asaas_payment_id = ?)
              ORDER BY id ASC LIMIT 1'
        );
        $stmt->execute([$externalReference, $externalReference, $paymentId !== '' ? $paymentId : null]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);

        if (is_array($order) && (int) $order['amount_cents'] > 0) {
            // Idempotência dupla: somente o primeiro acerto libera os créditos.
            $update = $db->prepare(
                'UPDATE asaas_orders
                   SET status = \'paid\', paid_at = NOW(), asaas_payment_id = COALESCE(asaas_payment_id, ?)
                 WHERE id = ? AND status = \'pending\''
            );
            $update->execute([$paymentId !== '' ? $paymentId : null, (int) $order['id']]);
            if ((int) $update->rowCount() > 0) {
                $amountCents = (int) $order['amount_cents'];
                $creditQuantity = (int) ($order['quantity'] ?? 0);
                $plan = $db->prepare('SELECT p.period FROM tenants t INNER JOIN plans p ON p.id = t.plan_id WHERE t.id = ? LIMIT 1');
                $plan->execute([$order['tenant_id']]);
                $period = (string) (($plan->fetch(PDO::FETCH_ASSOC)['period'] ?? 'monthly'));
                $periodStart = $period === 'yearly' ? date('Y-01-01') : date('Y-m-01');
                if ($creditQuantity > 0) {
                    $usage = $db->prepare('INSERT INTO tenant_usage (tenant_id, period_start, tokens_used, token_bonus) VALUES (?, ?, 0, ?) ON DUPLICATE KEY UPDATE token_bonus = COALESCE(token_bonus, 0) + ?');
                    $usage->execute([$order['tenant_id'], $periodStart, $creditQuantity, $creditQuantity]);
                }

                // Comissão do programa de indicações (valor por conversão).
                try {
                    $payout = 10.00;
                    if (function_exists('refSettingFloat')) {
                        $payout = refSettingFloat($db, 'payout_per_conversion', 10.00);
                    } else {
                        $ps = $db->prepare('SELECT setting_value FROM referral_settings WHERE setting_key = ? LIMIT 1');
                        $ps->execute(['payout_per_conversion']);
                        $psv = $ps->fetchColumn();
                        if ($psv !== false && is_numeric((string) $psv)) {
                            $payout = (float) $psv;
                        }
                    }
                    $ref = $db->prepare(
                        "SELECT id, referrer_user_id AS user_id, referrer_tenant_id AS tenant_id, 0.00 AS payout_amount
                           FROM referral_visits
                          WHERE signup_tenant_id = ? AND status IN ('registered', 'converted')
                          ORDER BY attributed_at DESC, id DESC LIMIT 1"
                    );
                    $ref->execute([$order['tenant_id']]);
                    $refRow = $ref->fetch(PDO::FETCH_ASSOC);
                    if (is_array($refRow)) {
                        $db->prepare("UPDATE referral_visits SET status = 'converted', converted_at = COALESCE(converted_at, NOW()) WHERE id = ?")
                            ->execute([(int) $refRow['id']]);
                        $amount = $refRow['payout_amount'] > 0 ? (float) $refRow['payout_amount'] : $payout;
                        $com = $db->prepare(
                            'INSERT INTO referral_commissions
                                (referrer_user_id, referrer_tenant_id, payer_tenant_id, order_id, amount, status)
                             VALUES (?, ?, ?, ?, ?, \'pending\')
                             ON DUPLICATE KEY UPDATE status = status'
                        );
                        $com->execute([(int) $refRow['user_id'], $refRow['tenant_id'], $order['tenant_id'], (int) $order['id'], $amount]);
                    }
                } catch (Throwable $e) {
                    error_log('webhook-asaas: commission: ' . $e->getMessage());
                }

                // Notificação interna de crédito aprovado.
                if (is_file(__DIR__ . '/services/notificationService.php')) {
                    require_once __DIR__ . '/services/notificationService.php';
                    if (class_exists('NotificationService')) {
                        NotificationService::notifyPaymentConfirmed(
                            $db,
                            ['id' => $order['user_id'], 'tenant_id' => $order['tenant_id'], 'name' => '', 'email' => ''],
                            $amountCents
                        );
                    }
                }
            }
        }
    }
    $mark = $db->prepare('UPDATE asaas_webhook_events SET processed = 1 WHERE webhook_event_id = ? LIMIT 1');
    $mark->execute([$eventId]);
} catch (Throwable $e) {
    error_log('webhook-asaas: processing: ' . $e->getMessage());
}

whJson(200, []);
