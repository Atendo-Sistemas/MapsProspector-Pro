var API_BASE = (typeof window.API_BASE_URL !== 'undefined' ? window.API_BASE_URL : 'api/');

// Estado global da aplicação
var AppState = window.AppState || {
    user: null,
    tenant: null,
    tokenUsage: null,
    impersonating: false,
    impersonatingTenantName: '',
    platformCompanyName: null,
    config: null,
    activeTab: 'dashboard',
    userCoords: null,
    userLocationName: '',
    locStatus: 'idle',
    leads: [],
    searchId: null,
    history: [],
    folders: [],
    visibleCount: 12,
    currentSearch: { query: '', location: '', tag: '', folderId: null, folderName: '' },
    localData: {
        municipios: [],
        cnaes: [],
        loaded: false
    }
};

var THEME_STORAGE_KEY = 'mapsprospector-theme';
function getStoredTheme() {
    try {
        var stored = localStorage.getItem(THEME_STORAGE_KEY);
        if (stored === 'dark' || stored === 'light') {
            return stored;
        }
        if (stored === null) {
            if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                return 'dark';
            }
        }
        return 'light';
    } catch (e) { return 'light'; }
}
function getStoredTheme() {
    try {
        var stored = localStorage.getItem(THEME_STORAGE_KEY);
        if (stored === 'dark' || stored === 'light') {
            return stored;
        }
        if (stored === null) {
            if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                return 'dark';
            }
        }
        return 'light';
    } catch (e) { return 'light'; }
}

function applyTheme(theme) {
    var root = document.documentElement; // <html> tag
    if (theme === 'dark') {
        root.classList.add('dark');
        root.setAttribute('data-theme', 'dark'); // Opcional, ajuda em alguns frameworks
    } else {
        root.classList.remove('dark');
        root.removeAttribute('data-theme');
    }
    
    try { 
        localStorage.setItem(THEME_STORAGE_KEY, theme); 
    } catch (e) {}
    
    // Atualiza ícones do topo (Dashboard)
    var sunIcon = document.getElementById('theme-icon-sun');
    var moonIcon = document.getElementById('theme-icon-moon');
    if (sunIcon && moonIcon) {
        if (theme === 'dark') {
            sunIcon.classList.remove('hidden');
            moonIcon.classList.add('hidden');
        } else {
            sunIcon.classList.add('hidden');
            moonIcon.classList.remove('hidden');
        }
    }
    updateThemeIconsLanding();
}

function toggleTheme() {
    var current = getStoredTheme();
    var next = current === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    updateThemeIconsLanding();
}   
function updateThemeIconsLanding() {
    var sunIcon = document.getElementById('theme-icon-sun-landing');
    var moonIcon = document.getElementById('theme-icon-moon-landing');
    var currentTheme = getStoredTheme();
    if (sunIcon && moonIcon) {
        if (currentTheme === 'dark') {
            sunIcon.classList.remove('hidden');
            moonIcon.classList.add('hidden');
        } else {
            sunIcon.classList.add('hidden');
            moonIcon.classList.remove('hidden');
        }
    }
}
function initApp() {
    console.log('DOM loaded, initializing...');
    applyTheme(getStoredTheme());
    showLandingPage();
    checkAuth();
    setupEventListeners();
    console.log('Initialization complete');
}

// Executa a inicialização assim que o DOM estiver pronto
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    initApp();
}
async function checkAuth() {
    try {
        const res = await fetch(API_BASE + 'auth.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'check' })
        });
        
        if (res.ok) {
            const data = await res.json();
            if (data.success) {
                AppState.user = data.data.user;
                AppState.tenant = data.data.tenant || null;
                AppState.tokenUsage = data.data.tokenUsage || null;
                AppState.activeTab = 'dashboard';
                await loadConfig();
                showDashboard();
            } else {
                showLandingPage();
            }
        } else {
            showLandingPage();
        }
    } catch (e) {
        console.error('Erro ao verificar auth:', e);
        showLandingPage();
    }
}
async function loadConfig() {
    try {
        const res = await fetch(API_BASE + 'settings.php', { credentials: 'include' });
        const raw = await res.text();
        if (!raw.trim()) {
            throw new Error(`Resposta vazia de settings.php (HTTP ${res.status})`);
        }

        let data;
        try {
            data = JSON.parse(raw);
        } catch (parseError) {
            const preview = raw.replace(/\s+/g, ' ').slice(0, 240);
            throw new Error(`Resposta inválida de settings.php (HTTP ${res.status}): ${preview}`);
        }

        if (!res.ok) {
            throw new Error(data.error || `settings.php respondeu HTTP ${res.status}`);
        }

        if (data.success) {
            AppState.config = data.data;
            
            // Atualiza o indicador se a função existir
            if (typeof updateSearchApiUI === 'function') updateSearchApiUI();
            if (typeof updateApiStatusDisplay === 'function') updateApiStatusDisplay();

            var isSuperAdmin = AppState.user && String(AppState.user.profile).toLowerCase() === 'super_admin';
            var instanceName = (AppState.config.tenantName && String(AppState.config.tenantName).trim()) ? String(AppState.config.tenantName).trim() : (AppState.tenant && AppState.tenant.name) ? AppState.tenant.name : 'Nome da empresa SaaS';
            var instanceEl = document.getElementById('sidebar-instance-name');
            if (instanceEl) instanceEl.textContent = instanceName;
            if (!isSuperAdmin) {
                var subtitleEl = document.getElementById('header-dashboard-subtitle');
                if (subtitleEl) subtitleEl.textContent = 'Dashboard ' + instanceName.toUpperCase();
            }
            updateDocumentTitle();
        } else {
            throw new Error(data.error || 'Não foi possível carregar as configurações.');
        }
    } catch (e) {
        console.error('Erro ao carregar config:', e);
        if (typeof updateSearchApiUI === 'function') updateSearchApiUI();
    }
}
async function handleLogin(e) {
    if (e && e.preventDefault) e.preventDefault();
    const emailInput = document.getElementById('login-email');
    const passwordInput = document.getElementById('login-password');
    const errorEl = document.getElementById('login-error');
    const btn = document.getElementById('btn-login');
    
    const email = (emailInput && emailInput.value ? emailInput.value.trim().toLowerCase() : '') || '';
    const password = (passwordInput && passwordInput.value ? passwordInput.value : '') || '';
    
    if (errorEl) {
        errorEl.classList.add('hidden');
        errorEl.textContent = '';
    }
    if (!email || !email.includes('@')) {
        if (errorEl) {
            errorEl.textContent = 'Por favor, insira um e-mail válido.';
            errorEl.classList.remove('hidden');
        }
        return;
    }
    btn.innerHTML = '<span class="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin inline-block"></span> Entrando...';
    try {
        const res = await fetch(API_BASE + 'auth.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'login', email: email, password: password })
        });
        const text = await res.text();
        
        if (!text || text.trim() === '') {
            throw new Error('Resposta vazia do servidor');
        }
        
        const data = JSON.parse(text);
        
        if (data.success) {
            AppState.user = data.data.user;
            AppState.tenant = data.data.tenant || null;
            AppState.tokenUsage = data.data.tokenUsage || null;
            AppState.impersonating = !!(data.data && data.data.impersonating);
            AppState.impersonatingTenantName = (data.data && data.data.impersonatingTenantName) || '';
            
            window.location.reload();
        } else {
            if (errorEl) {
                errorEl.textContent = data.error || 'Falha no login. Tente novamente.';
                errorEl.classList.remove('hidden');
            } else {
                alert('Erro ao fazer login: ' + (data.error || 'Tente novamente.'));
            }
        }
    } catch (err) {
        if (errorEl) {
            errorEl.textContent = 'Erro de conexão: ' + (err.message || 'Verifique o servidor');
            errorEl.classList.remove('hidden');
        } else {
            alert('Erro de conexão: ' + (err.message || 'Verifique o servidor'));
        }
    } finally {
        btn.disabled = false;
        btn.innerHTML = 'Entrar <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>';
    }
}
function showLogin() {
    var loginScreen = document.getElementById('login-screen');
    var dashboard = document.getElementById('dashboard');
    var landingPage = document.getElementById('landing-page');
    var themeToggle = document.getElementById('btn-theme-toggle');
    if (landingPage) landingPage.style.display = 'none';
    if (loginScreen) loginScreen.style.display = 'flex';
    if (dashboard) dashboard.style.display = 'none';
    if (themeToggle) themeToggle.classList.add('hidden');
}
function showLandingPage() {
    var loginScreen = document.getElementById('login-screen');
    var dashboard = document.getElementById('dashboard');
    var landingPage = document.getElementById('landing-page');
    var themeToggle = document.getElementById('btn-theme-toggle');
    
    if (loginScreen) loginScreen.style.display = 'none';
    if (dashboard) dashboard.style.display = 'none';
    if (landingPage) {
        landingPage.style.display = 'block';
    }
    
    if (themeToggle) {
        themeToggle.classList.remove('hidden');
    }
    
    updateThemeIconsLanding();
    loadLandingPageContent();
    loadLandingPagePlans();
}
function loadLandingPageContent() {
    // O endpoint pode devolver as seções na raiz ou dentro de data.
    // Se a tabela ainda estiver vazia, a landing continua funcional com conteúdo padrão.
    fetch(API_BASE + 'landing-page-public.php?t=' + new Date().getTime(), { cache: 'no-store' })
        .then(function(r) {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.text();
        })
        .then(function(text) {
            var data = {};
            try { data = text ? JSON.parse(text) : {}; } catch (e) { data = {}; }
            var sections = (data && Array.isArray(data.sections))
                ? data.sections
                : (data && data.data && Array.isArray(data.data.sections) ? data.data.sections : []);
            if (sections.length > 0) {
                renderLandingSections(sections);
            } else {
                renderLandingSections(getDefaultLandingSections());
            }
        })
        .catch(function() {
            renderLandingSections(getDefaultLandingSections());
        });
}
function loadLandingPagePlans() {
    fetch(API_BASE + 'plans-public.php', { cache: 'no-store' })
        .then(function(r) {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.text();
        })
        .then(function(data) {
            var parsed = {};
            try { parsed = data ? JSON.parse(data) : {}; } catch (e) { parsed = {}; }
            var items = parsed && parsed.data && Array.isArray(parsed.data.items)
                ? parsed.data.items
                : (parsed && Array.isArray(parsed.items) ? parsed.items : []);
            renderLandingPlans(items);
        })
        .catch(function() {
            renderLandingPlans([]);
        });
}
function getDefaultLandingSections() {
    return [
        {
            sectionKey: 'hero',
            sectionTitle: 'Prospecção comercial com mais clareza',
            sectionSubtitle: 'Encontre empresas, organize oportunidades e transforme buscas em ações comerciais.',
            sectionContent: '<p>Centralize suas pesquisas de mercado em uma experiência simples para sua equipe, com histórico e próximos passos no mesmo fluxo.</p>',
            extraData: { cta_text: 'Começar agora' }
        },
        {
            sectionKey: 'features',
            sectionTitle: 'Ferramentas para sua rotina comercial',
            sectionSubtitle: 'Uma base organizada para pesquisar, consultar e acompanhar seus próximos contatos.',
            extraData: { items: [
                { icon: 'map', title: 'Pesquisa no Maps', description: 'Encontre empresas por categoria e localização.' },
                { icon: 'search', title: 'Pesquisa LinkedIn', description: 'Organize buscas por cargo, localidade e empresa.' },
                { icon: 'chart', title: 'Acompanhamento', description: 'Consulte seu histórico e mantenha o trabalho comercial organizado.' },
                { icon: 'check-circle', title: 'Consulta de CNPJ', description: 'Consulte dados cadastrais por CNPJ, sem confundir a busca com razão social.' }
            ] }
        },
        {
            sectionKey: 'how_it_works',
            sectionTitle: 'Como funciona',
            sectionSubtitle: 'Comece com uma busca objetiva e avance com os dados que fazem sentido para sua equipe.',
            sectionContent: '<p>Escolha o tipo de pesquisa, informe os critérios e analise os resultados antes de iniciar o contato.</p>',
            extraData: { steps: [
                { number: '01', title: 'Escolha a pesquisa', description: 'Selecione Maps, LinkedIn ou consulta de CNPJ conforme o objetivo comercial.' },
                { number: '02', title: 'Defina os critérios', description: 'Informe localização, categoria, cargo ou CNPJ com o máximo de clareza.' },
                { number: '03', title: 'Revise e avance', description: 'Analise os dados retornados, consulte o histórico e organize a próxima ação.' }
            ] }
        },
        {
            sectionKey: 'benefits',
            sectionTitle: 'Mais foco para sua prospecção',
            sectionSubtitle: 'Reduza tarefas dispersas e mantenha as informações importantes em um só lugar.',
            extraData: { items: [
                { icon: 'clock', title: 'Mais agilidade', description: 'Encontre informações essenciais com menos etapas.' },
                { icon: 'shield', title: 'Uso responsável', description: 'Consulte os dados de acordo com as regras e os termos aplicáveis.' },
                { icon: 'check-circle', title: 'Fluxo organizado', description: 'Retome suas pesquisas pelo histórico sempre que precisar.' },
                { icon: 'users', title: 'Equipe alinhada', description: 'Dê visibilidade aos critérios e às pesquisas que orientam o trabalho comercial.' }
            ] }
        },
        {
            sectionKey: 'faq',
            sectionTitle: 'Dúvidas frequentes',
            sectionSubtitle: 'Veja os pontos principais antes de iniciar.',
            extraData: { items: [
                { question: 'Preciso criar uma conta para utilizar o sistema?', answer: 'Sim. O acesso às ferramentas depende de uma conta ativa.' },
                { question: 'Posso consultar pesquisas anteriores?', answer: 'Sim. As pesquisas salvas ficam disponíveis no histórico da conta conforme as regras configuradas para o seu acesso.' },
                { question: 'A pesquisa LinkedIn exige uma empresa?', answer: 'Não. A empresa é opcional; cargo e localização são os critérios obrigatórios.' },
                { question: 'A consulta de CNPJ busca razão social?', answer: 'Não. Nesta versão, a ferramenta realiza consulta cadastral por CNPJ.' }
            ] }
        },
        {
            sectionKey: 'cta',
            sectionTitle: 'Pronto para organizar sua prospecção?',
            sectionSubtitle: 'Entre na sua conta ou conheça o fluxo de cadastro.',
            sectionContent: '<p>Comece com uma pesquisa e avance no seu ritmo.</p>',
            extraData: { cta_text: 'Entrar', secondary_cta_text: 'Criar conta' }
        },
        {
            sectionKey: 'footer',
            sectionContent: '<p>Maps Prospector — prospecção comercial organizada.</p>'
        }
    ];
}
function renderLandingHero(section) {
    var heroTitle = document.getElementById('lp-hero-title');
    var heroSubtitle = document.getElementById('lp-hero-subtitle');
    var heroContent = document.getElementById('lp-hero-content');
    var heroCta = document.getElementById('lp-hero-cta');

    var title = section.sectionTitle || section.section_title || '';
    var subtitle = section.sectionSubtitle || section.section_subtitle || '';
    var content = section.sectionContent || section.section_content || '';

    if (heroTitle) heroTitle.textContent = title;
    if (heroSubtitle) heroSubtitle.textContent = subtitle;
    if (heroContent) heroContent.innerHTML = content;
    if (heroCta) {
        var heroCtaText = (section.extraData && (section.extraData.cta_text || section.extraData.ctaText)) || 'Começar agora';
        heroCta.textContent = heroCtaText;
        heroCta.classList.remove('hidden');
    }
}

function renderLandingFeatures(section, icons) {
    var featuresTitle = document.getElementById('lp-features-title');
    var featuresSubtitle = document.getElementById('lp-features-subtitle');
    var featuresGrid = document.getElementById('lp-features-grid');

    var title = section.sectionTitle || section.section_title || '';
    var subtitle = section.sectionSubtitle || section.section_subtitle || '';

    if (featuresTitle) featuresTitle.textContent = title;
    if (featuresSubtitle) featuresSubtitle.textContent = subtitle;
    
    var items = (section.extraData && section.extraData.items) || (section.extra_data && section.extra_data.items);
    if (featuresGrid && items) {
        featuresGrid.innerHTML = items.map(function(item) {
            return '<div class="bg-slate-50 dark:bg-slate-800 rounded-2xl p-6 hover:shadow-lg transition">' +
                '<div class="w-14 h-14 bg-blue-100 dark:bg-blue-900/30 rounded-2xl flex items-center justify-center text-blue-600 dark:text-blue-400 mb-4">' + (icons[item.icon] || icons.search) + '</div>' +
                '<h3 class="text-lg font-bold text-slate-900 dark:text-white mb-2">' + item.title + '</h3>' +
                '<p class="text-slate-600 dark:text-slate-400 text-sm">' + item.description + '</p></div>';
        }).join('');
    }
}

function renderLandingHowItWorks(section) {
    var howTitle = document.getElementById('lp-how-title');
    var howSubtitle = document.getElementById('lp-how-subtitle');
    var howContent = document.getElementById('lp-how-content');

    var title = section.sectionTitle || section.section_title || '';
    var subtitle = section.sectionSubtitle || section.section_subtitle || '';
    var content = section.sectionContent || section.section_content || '';

    if (howTitle) howTitle.textContent = title;
    if (howSubtitle) howSubtitle.textContent = subtitle;
    if (howContent) {
        var steps = (section.extraData && section.extraData.steps) || (section.extra_data && section.extra_data.steps);
        var stepsHtml = Array.isArray(steps) && steps.length > 0
            ? '<div class="grid gap-4 md:grid-cols-3 mt-6">' + steps.map(function(step) {
                return '<div class="bg-slate-50 dark:bg-slate-800 rounded-2xl p-5 border border-slate-100 dark:border-slate-700">' +
                    '<div class="text-blue-600 dark:text-blue-400 font-black text-sm mb-3">' + (step.number || '') + '</div>' +
                    '<h3 class="text-base font-bold text-slate-900 dark:text-white mb-2">' + (step.title || '') + '</h3>' +
                    '<p class="text-slate-600 dark:text-slate-400 text-sm">' + (step.description || '') + '</p></div>';
            }).join('') + '</div>'
            : '';
        howContent.innerHTML = content + stepsHtml;
    }
}

function renderLandingBenefits(section, icons) {
    var benefitsTitle = document.getElementById('lp-benefits-title');
    var benefitsSubtitle = document.getElementById('lp-benefits-subtitle');
    var benefitsGrid = document.getElementById('lp-benefits-grid');

    var title = section.sectionTitle || section.section_title || '';
    var subtitle = section.sectionSubtitle || section.section_subtitle || '';

    if (benefitsTitle) benefitsTitle.textContent = title;
    if (benefitsSubtitle) benefitsSubtitle.textContent = subtitle;

    var items = (section.extraData && section.extraData.items) || (section.extra_data && section.extra_data.items);
    if (benefitsGrid && items) {
        benefitsGrid.innerHTML = items.map(function(item) {
            return '<div class="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm">' +
                '<div class="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 rounded-xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-4">' + (icons[item.icon] || icons['check-circle']) + '</div>' +
                '<h3 class="text-lg font-bold text-slate-900 dark:text-white mb-2">' + item.title + '</h3>' +
                '<p class="text-slate-600 dark:text-slate-400 text-sm">' + item.description + '</p></div>';
        }).join('');
    }
}

function renderLandingTestimonials(section) {
    var testimonialsTitle = document.getElementById('lp-testimonials-title');
    var testimonialsSubtitle = document.getElementById('lp-testimonials-subtitle');
    var testimonialsGrid = document.getElementById('lp-testimonials-grid');

    var title = section.sectionTitle || section.section_title || '';
    var subtitle = section.sectionSubtitle || section.section_subtitle || '';

    if (testimonialsTitle) testimonialsTitle.textContent = title;
    if (testimonialsSubtitle) testimonialsSubtitle.textContent = subtitle;

    var items = (section.extraData && section.extraData.items) || (section.extra_data && section.extra_data.items);
    var testimonialsSection = document.getElementById('testimonials');
    if (!testimonialsSection && testimonialsGrid && testimonialsGrid.closest) testimonialsSection = testimonialsGrid.closest('section');
    if (!testimonialsSection && testimonialsTitle && testimonialsTitle.closest) testimonialsSection = testimonialsTitle.closest('section');
    var hasItems = Array.isArray(items) && items.length > 0;
    if (testimonialsSection) testimonialsSection.classList.toggle('hidden', !hasItems);
    if (!hasItems) {
        if (testimonialsTitle) testimonialsTitle.textContent = '';
        if (testimonialsSubtitle) testimonialsSubtitle.textContent = '';
        if (testimonialsGrid) testimonialsGrid.innerHTML = '';
        return;
    }
    if (testimonialsGrid && hasItems) {
        testimonialsGrid.innerHTML = items.map(function(item) {
            return '<div class="bg-slate-50 dark:bg-slate-800 rounded-2xl p-6">' +
                '<p class="text-slate-700 dark:text-slate-300 mb-4">"' + item.text + '"</p>' +
                '<div class="flex items-center gap-3">' +
                '<div class="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">' + item.name.charAt(0) + '</div>' +
                '<div><p class="font-bold text-slate-900 dark:text-white text-sm">' + item.name + '</p>' +
                '<p class="text-slate-500 dark:text-slate-400 text-xs">' + item.company + '</p></div></div></div>';
        }).join('');
    }
}

function renderLandingFaq(section) {
    var faqTitle = document.getElementById('lp-faq-title');
    var faqSubtitle = document.getElementById('lp-faq-subtitle');
    var faqList = document.getElementById('lp-faq-list');

    var title = section.sectionTitle || section.section_title || '';
    var subtitle = section.sectionSubtitle || section.section_subtitle || '';

    if (faqTitle) faqTitle.textContent = title;
    if (faqSubtitle) faqSubtitle.textContent = subtitle;

    var items = (section.extraData && section.extraData.items) || (section.extra_data && section.extra_data.items);
    if (faqList && items) {
        faqList.innerHTML = items.map(function(item) {
            return '<div class="bg-white dark:bg-slate-800 rounded-xl p-6 shadow-sm">' +
                '<h3 class="font-bold text-slate-900 dark:text-white mb-2">' + item.question + '</h3>' +
                '<p class="text-slate-600 dark:text-slate-400 text-sm">' + item.answer + '</p></div>';
        }).join('');
    }
}

function renderLandingCta(section) {
    var ctaTitle = document.getElementById('lp-cta-title');
    var ctaSubtitle = document.getElementById('lp-cta-subtitle');
    var ctaContent = document.getElementById('lp-cta-content');
    var ctaButton = document.getElementById('lp-cta-button');
    var ctaSecondary = document.getElementById('lp-cta-secondary');

    if (ctaTitle) ctaTitle.textContent = section.sectionTitle || '';
    if (ctaSubtitle) ctaSubtitle.textContent = section.sectionSubtitle || '';
    if (ctaContent) ctaContent.innerHTML = section.sectionContent || '';
    if (ctaButton && section.extraData && section.extraData.cta_text) {
        ctaButton.textContent = section.extraData.cta_text;
    }
    if (ctaSecondary && section.extraData && section.extraData.secondary_cta_text) {
        ctaSecondary.textContent = section.extraData.secondary_cta_text;
        ctaSecondary.classList.remove('hidden');
    }
}

function renderLandingFooter(section) {
    var footerContent = document.getElementById('lp-footer-content');
    var content = section.sectionContent || section.section_content || '';
    if (footerContent) footerContent.innerHTML = content;
}

function renderLandingSections(sections) {
    var icons = {
        search: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>',
        map: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>',
        chart: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>',
        zap: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>',
        shield: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>',
        users: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>',
        clock: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>',
        'check-circle': '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>'
    };

    if (!Array.isArray(sections)) return;

    // Não exibe uma seção de depoimentos vazia. Conteúdo de clientes só pode
    // aparecer quando houver dados reais cadastrados pelo administrador.
    renderLandingTestimonials({});

    sections.forEach(function(section) {
        var key = section.sectionKey || section.section_key;
        switch(key) {
            case 'hero': renderLandingHero(section); break;
            case 'features': renderLandingFeatures(section, icons); break;            case 'how_it_works': renderLandingHowItWorks(section); break;
            case 'benefits': renderLandingBenefits(section, icons); break;
            case 'testimonials': renderLandingTestimonials(section); break;
            case 'faq': renderLandingFaq(section); break;
            case 'cta': renderLandingCta(section); break;
            case 'footer': renderLandingFooter(section); break;
        }
    });
}

function renderLandingPlans(plans) {
    var container = document.getElementById('landing-plans-grid');
    if (!container) return;
    if (!plans || plans.length === 0) {
        container.innerHTML = '<p class="text-center col-span-full text-slate-500">Nenhum plano disponível no momento.</p>';
        return;
    }
    container.innerHTML = plans.map(function(plan) {
        var isFree = plan.priceMonthly === 0 || plan.priceMonthly === '0.00' || !plan.priceMonthly;
        var price = isFree ? 'Grátis' : 'R$ ' + parseFloat(plan.priceMonthly).toFixed(2).replace('.', ',');
        var limitText = (plan.tokenLimit || 0) + ' créditos';

        // 💡 Botão direcionando diretamente para o Cadastro via openCadastroModal()
        return '<div class="bg-slate-50 dark:bg-slate-800 rounded-2xl p-6 ' + (isFree ? 'ring-2 ring-blue-500' : '') + '">' +
            '<h3 class="text-xl font-black text-slate-900 dark:text-white mb-2">' + plan.name + '</h3>' +
            '<div class="mb-4"><span class="text-3xl font-black text-slate-900 dark:text-white">' + price + '</span>' +
            (!isFree ? '<span class="text-slate-500 dark:text-slate-400">/mês</span>' : '') + '</div>' +
            '<p class="text-slate-600 dark:text-slate-400 text-sm mb-6">' + limitText + '</p>' +
            '<button type="button" onclick="openCadastroModal()" class="block w-full py-3 text-center ' + (isFree ? 'bg-blue-600 hover:bg-blue-700' : 'bg-slate-900 hover:bg-slate-800') + ' text-white font-bold rounded-xl transition">Assinar</button></div>';
    }).join('');
}

function openLoginModal() {
    var landingPage = document.getElementById('landing-page');
    var loginScreen = document.getElementById('login-screen');
    if (landingPage) landingPage.style.display = 'none';
    if (loginScreen) loginScreen.style.display = 'flex';
}

// Compatibilidade com os botões da página pública que usam onclick inline.
window.openLoginModal = openLoginModal;

function renderHeaderTokenWarning() {
    var tokenBanner = document.getElementById('header-token-warning');
    if (!tokenBanner) return;

    var tenant = AppState.tenant || {};
    var isSuperAdmin = AppState.user && String(AppState.user.profile).toLowerCase() === 'super_admin';

    if (isSuperAdmin) {
        tokenBanner.classList.add('hidden');
        return;
    }

    var daysLeft = tenant.trialDaysLeft !== undefined ? tenant.trialDaysLeft : 30;
    var isExpired = tenant.trialExpired || tenant.status === 'suspended' || daysLeft <= 0;

    if (isExpired) {
        tokenBanner.className = 'p-3 bg-red-600 text-white text-xs font-bold flex items-center justify-between px-6 shadow-md';
        tokenBanner.innerHTML = `
            <span>⚠️ <strong>Seu período de teste de 30 dias expirou!</strong> Adquira mais créditos ou assine um plano para liberar o acesso total.</span>
            <button onclick="setActiveTab('choose-plan')" class="bg-white text-red-600 px-3 py-1 rounded-lg text-xs font-black uppercase hover:bg-slate-100">Ver Planos</button>
        `;
        tokenBanner.classList.remove('hidden');
    } else if (daysLeft <= 7) {
        tokenBanner.className = 'p-3 bg-amber-500 text-white text-xs font-bold flex items-center justify-between px-6 shadow-md';
        tokenBanner.innerHTML = `
            <span>⏳ Você tem <strong>${daysLeft} dia(s) restante(s)</strong> no seu período de teste.</span>
            <button onclick="setActiveTab('choose-plan')" class="bg-slate-900 text-white px-3 py-1 rounded-lg text-xs font-black uppercase hover:bg-slate-800">Ver Planos</button>
        `;
        tokenBanner.classList.remove('hidden');
    } else {
        tokenBanner.classList.add('hidden');
    }
}

function updateSearchApiUI() {
    const indicator = document.getElementById('search-api-indicator');
    const status = document.getElementById('search-api-status');
    if (!indicator || !status) return;
    
    var configured = false;
    if (AppState.config) {
        var isSuperAdmin = AppState.user && String(AppState.user.profile).toLowerCase() === 'super_admin';
        configured = isSuperAdmin
            ? (AppState.config.scraperApiKey && String(AppState.config.scraperApiKey).trim()) !== ''
            : !!AppState.config.scraperApiKeyConfigured;
    }
    
    if (configured) {
        indicator.className = 'w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]';
        status.textContent = 'Conectado ao Google Maps';
    } else if (!AppState.config) {
        indicator.className = 'w-2 h-2 rounded-full bg-yellow-500 animate-pulse';
        status.textContent = 'Verificando...';
    } else {
        indicator.className = 'w-2 h-2 rounded-full bg-red-500';
        status.textContent = 'API não configurada';
    }
}
function updateDocumentTitle() {
    if (!AppState.user) return;
    var isSuperAdmin = String(AppState.user.profile).toLowerCase() === 'super_admin';
    syncApiBuscaMenuAccess();
    var companyName = isSuperAdmin
        ? (AppState.platformCompanyName && String(AppState.platformCompanyName).trim() ? AppState.platformCompanyName.trim() : 'MapsProspector Pro')
        : (AppState.tenant && AppState.tenant.name ? String(AppState.tenant.name).trim() : 'Empresa');
    var instanceName = (AppState.config && AppState.config.tenantName && String(AppState.config.tenantName).trim()) ? String(AppState.config.tenantName).trim() : 'Nome da empresa SaaS';
    document.title = companyName + ' | ' + instanceName;
}

// Controle de acesso visual da API de Busca. O item pode variar entre
// versões do index.php, por isso a regra combina atributos, IDs, classes e
// o texto efetivamente renderizado na barra lateral.
function syncApiBuscaMenuAccess() {
    if (!AppState.user) return;

    var isSuperAdmin = String(AppState.user.profile || '').toLowerCase() === 'super_admin';
    var restricted = !isSuperAdmin;
    var body = document.body;

    if (body) {
        body.setAttribute('data-api-busca-restricted', restricted ? 'true' : 'false');
    }

    if (!document.getElementById('api-busca-access-style')) {
        var style = document.createElement('style');
        style.id = 'api-busca-access-style';
        style.textContent = [
            'body[data-api-busca-restricted="true"] [data-tab="api-busca"],',
            'body[data-api-busca-restricted="true"] [data-tab="api_busca"],',
            'body[data-api-busca-restricted="true"] [data-tab="apiBusca"],',
            'body[data-api-busca-restricted="true"] #nav-api-busca,',
            'body[data-api-busca-restricted="true"] #nav-btn-api-busca,',
            'body[data-api-busca-restricted="true"] .nav-item-api-busca,',
            'body[data-api-busca-restricted="true"] .api-busca-nav { display: none !important; }'
        ].join('\n');
        document.head.appendChild(style);
    }

    var knownSelectors = [
        '[data-tab="api-busca"]',
        '[data-tab="api_busca"]',
        '[data-tab="apiBusca"]',
        '#nav-api-busca',
        '#nav-btn-api-busca',
        '.nav-item-api-busca',
        '.api-busca-nav'
    ];

    document.querySelectorAll(knownSelectors.join(',')).forEach(function(menuItem) {
        menuItem.classList.toggle('hidden', restricted);
        menuItem.style.display = restricted ? 'none' : '';
        menuItem.setAttribute('aria-hidden', restricted ? 'true' : 'false');
        if (restricted) menuItem.setAttribute('tabindex', '-1');
        else menuItem.removeAttribute('tabindex');
    });

    // Fallback para estruturas antigas que não têm data-tab no botão.
    document.querySelectorAll('#dashboard .tab-btn, #dashboard button, #dashboard a, #dashboard [role="button"]').forEach(function(candidate) {
        var label = (candidate.getAttribute('aria-label') || candidate.textContent || '')
            .replace(/\s+/g, ' ')
            .trim()
            .toLocaleLowerCase('pt-BR');

        if (label === 'api de busca' || label.indexOf('api de busca') !== -1) {
            var menuItem = candidate.closest('[data-tab], .tab-btn, li, button, a, [role="button"]') || candidate;
            menuItem.classList.toggle('hidden', restricted);
            menuItem.style.display = restricted ? 'none' : '';
            menuItem.setAttribute('aria-hidden', restricted ? 'true' : 'false');
            if (restricted) menuItem.setAttribute('tabindex', '-1');
            else menuItem.removeAttribute('tabindex');
        }
    });

    // Mantém a regra se a navegação for reconstruída posteriormente por outro script.
    if (!window.__apiBuscaMenuObserver && body) {
        var refreshTimer;
        window.__apiBuscaMenuObserver = new MutationObserver(function() {
            clearTimeout(refreshTimer);
            refreshTimer = setTimeout(syncApiBuscaMenuAccess, 0);
        });
        window.__apiBuscaMenuObserver.observe(body, { childList: true, subtree: true });
    }
}

// A Central de Notificações manipula textos globais e pode disparar testes de
// WhatsApp/e-mail. Por isso, nunca pode aparecer para empresas, mesmo quando
// outro script reconstrói o menu depois que o dashboard já foi carregado.
function syncNotificationsMenuAccess() {
    if (!AppState.user) return;

    var isSuperAdmin = String(AppState.user.profile || '').toLowerCase() === 'super_admin';
    var restricted = !isSuperAdmin;
    var body = document.body;

    if (body) {
        body.setAttribute('data-notifications-restricted', restricted ? 'true' : 'false');
    }

    if (!document.getElementById('notifications-access-style')) {
        var style = document.createElement('style');
        style.id = 'notifications-access-style';
        style.textContent = [
            'body[data-notifications-restricted="true"] [data-tab="notifications"],',
            'body[data-notifications-restricted="true"] #nav-notifications,',
            'body[data-notifications-restricted="true"] #nav-btn-notifications,',
            'body[data-notifications-restricted="true"] .notifications-nav,',
            'body[data-notifications-restricted="true"] .super-admin-only { display: none !important; }'
        ].join('\n');
        document.head.appendChild(style);
    }

    var knownSelectors = [
        '[data-tab="notifications"]',
        '#nav-notifications',
        '#nav-btn-notifications',
        '.notifications-nav',
        '.super-admin-only'
    ];

    document.querySelectorAll(knownSelectors.join(',')).forEach(function(menuItem) {
        menuItem.classList.toggle('hidden', restricted);
        menuItem.style.display = restricted ? 'none' : '';
        menuItem.setAttribute('aria-hidden', restricted ? 'true' : 'false');
        if (restricted) menuItem.setAttribute('tabindex', '-1');
        else menuItem.removeAttribute('tabindex');
    });

    // Compatibilidade com menus antigos sem data-tab ou ID padronizado.
    document.querySelectorAll('#dashboard .tab-btn, #dashboard button, #dashboard a, #dashboard [role="button"]').forEach(function(candidate) {
        var label = (candidate.getAttribute('aria-label') || candidate.textContent || '')
            .replace(/\s+/g, ' ')
            .trim()
            .toLocaleLowerCase('pt-BR');
        if (label === 'notificações' || label.indexOf('notificações') !== -1) {
            var menuItem = candidate.closest('[data-tab], .tab-btn, li, button, a, [role="button"]') || candidate;
            menuItem.classList.toggle('hidden', restricted);
            menuItem.style.display = restricted ? 'none' : '';
            menuItem.setAttribute('aria-hidden', restricted ? 'true' : 'false');
            if (restricted) menuItem.setAttribute('tabindex', '-1');
            else menuItem.removeAttribute('tabindex');
        }
    });

    if (!window.__notificationsMenuObserver && body) {
        var refreshTimer;
        window.__notificationsMenuObserver = new MutationObserver(function() {
            clearTimeout(refreshTimer);
            refreshTimer = setTimeout(syncNotificationsMenuAccess, 0);
        });
        window.__notificationsMenuObserver.observe(body, { childList: true, subtree: true });
    }
}

function loadSidebarCompanyName() {
    var isSuperAdmin = AppState.user && String(AppState.user.profile).toLowerCase() === 'super_admin';
    
    fetch(API_BASE + 'platform-config.php', { credentials: 'include' })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            var d = data.data || data;
            
            // 1. Nome da Marca Principal / SaaS (Título em Negrito)
            var saasName = (d && d.saasCompanyName && String(d.saasCompanyName).trim()) 
                ? String(d.saasCompanyName).trim() 
                : 'Maps Prospector';
            AppState.platformCompanyName = saasName;
            
            var el = document.getElementById('sidebar-company-name');
            if (el) el.textContent = saasName;

            // 2. Nome do Cliente / Instância (Texto Secundário em Cinza)
            // Prioridade: Configuração de Instância -> Nome da Empresa Cadastrada -> Nome do SaaS
            var instanceName = '';
            
            if (AppState.config && AppState.config.tenantName && String(AppState.config.tenantName).trim() !== '') {
                instanceName = String(AppState.config.tenantName).trim();
            } else if (AppState.tenant && AppState.tenant.name && String(AppState.tenant.name).trim() !== '') {
                instanceName = String(AppState.tenant.name).trim();
            } else if (AppState.user && AppState.user.companyName && String(AppState.user.companyName).trim() !== '') {
                instanceName = String(AppState.user.companyName).trim();
            } else {
                instanceName = isSuperAdmin ? 'Painel Plataforma' : 'Minha Empresa';
            }

            var instanceEl = document.getElementById('sidebar-instance-name');
            if (instanceEl) instanceEl.textContent = instanceName;

            // Atualiza o subtítulo no topo do Dashboard
            var subtitleEl = document.getElementById('header-dashboard-subtitle');
            if (subtitleEl) {
                subtitleEl.textContent = 'Dashboard ' + instanceName.toUpperCase();
            }

            updateDocumentTitle();
        })
        .catch(function(err) {
            console.warn('Erro ao carregar nome da marca:', err);
        });
}
function showDashboard() {
    var loginScreen = document.getElementById('login-screen');
    var dashboard = document.getElementById('dashboard');
    var landingPage = document.getElementById('landing-page');
    
    // 💡 Declaração da variável do tema
    var themeToggle = document.getElementById('btn-theme-toggle');
    if (themeToggle) {
        themeToggle.onclick = function(e) {
            e.stopPropagation();
            toggleTheme();
        };
    }

    if (landingPage) landingPage.style.display = 'none';
    if (loginScreen) {
        loginScreen.style.setProperty('display', 'none', 'important');
        loginScreen.classList.add('hidden');
    }
    if (dashboard) {
        dashboard.style.setProperty('display', 'flex', 'important');
        dashboard.classList.remove('hidden');
    }
    
    if (themeToggle) themeToggle.classList.remove('hidden');
    
    loadSidebarCompanyName();
    renderHeaderTokenWarning();
    updateSearchApiUI();
    
    if (AppState.user) {
        var userNameEl = document.getElementById('user-name');
        if (userNameEl) userNameEl.textContent = AppState.user.name;
        
        var roleEl = document.getElementById('user-role');
        if (roleEl) {
            var roleLabels = { super_admin: 'Super Admin', admin: 'Admin', manager: 'Gerente', gerente: 'Gerente', user: 'Usuário' };
            roleEl.textContent = roleLabels[AppState.user.profile] || AppState.user.profile || 'Usuário';
        }
        
        var isSuperAdmin = String(AppState.user.profile).toLowerCase() === 'super_admin';
        syncApiBuscaMenuAccess();
        var blockAdmin = document.getElementById('nav-block-administracao');
        var dividerNormal = document.getElementById('nav-divider-normal');
        
        if (blockAdmin) blockAdmin.classList.toggle('hidden', !isSuperAdmin);
        if (dividerNormal) dividerNormal.classList.toggle('hidden', isSuperAdmin);
        
        var hasTenant = AppState.tenant && AppState.tenant.id;
        var btnMeuPlano = document.getElementById('nav-btn-choose-plan');
        if (btnMeuPlano) btnMeuPlano.classList.toggle('hidden', !(hasTenant && !isSuperAdmin));
        
        var apiStatusWidget = document.getElementById('sidebar-api-status-widget');
        if (apiStatusWidget) apiStatusWidget.classList.toggle('hidden', !isSuperAdmin);
        
        const profile = String(AppState.user.profile).toLowerCase();
        const isAdmin = profile === 'admin' || profile === 'super_admin';
        const isManager = profile === 'manager' || profile === 'gerente';
        const isAuthorized = isAdmin || isManager;

        // A pesquisa LinkedIn é uma funcionalidade operacional para administradores
        // e gerentes de qualquer empresa; não deve ser confundida com a aba
        // administrativa de configuração da API de Busca.
        const btnLinkedIn = document.getElementById('nav-btn-linkedin');
        if (btnLinkedIn) btnLinkedIn.classList.toggle('hidden', !isAuthorized);
        
        document.querySelectorAll('.admin-only').forEach(function(el) {
            el.classList.toggle('hidden', !isAuthorized);
        });
        // Templates globais e testes de disparo são exclusivos do super administrador.
        // A classe admin-only é usada também por outros itens, portanto a aba
        // Notificações precisa desta regra própria para nunca aparecer para
        // administradores, supervisores ou gerentes de empresas.
        const btnNotifications = document.querySelector('[data-tab="notifications"]');
        if (btnNotifications) btnNotifications.classList.toggle('hidden', !isSuperAdmin);
        syncNotificationsMenuAccess();
        const btnLandingPage = document.querySelector('[data-tab="landing-page"]');
	if (btnLandingPage) {
	     btnLandingPage.classList.toggle('hidden', !isSuperAdmin);
}
        const btnTeam = document.getElementById('nav-btn-team');
        const btnCnpj = document.querySelector('[data-tab="cnpj-lookup"]');
        const btnCredits = document.querySelector('[data-tab="request-credits"]');
        const btnSettings = document.querySelector('[data-tab="settings"]');
        // Configurações de webhook: plataforma (super_admin), empresa e pessoal
        // (admin) ou somente pessoal (supervisor e usuário normal).
        const canAccessSettings = isSuperAdmin || profile === 'admin' || profile === 'supervisor' || profile === 'normal';
        const canManageTeam = ['super_admin', 'admin', 'supervisor', 'manager', 'gerente'].includes(profile);
        
        if (btnTeam) btnTeam.classList.toggle('hidden', !canManageTeam);
        if (btnCnpj) btnCnpj.classList.toggle('hidden', !isAuthorized);
        if (btnCredits) btnCredits.classList.toggle('hidden', !isAuthorized);
        if (btnSettings) btnSettings.classList.toggle('hidden', !canAccessSettings);
    }
    
    var impersonationBanner = document.getElementById('impersonation-banner');
    var impersonationTenantName = document.getElementById('impersonation-tenant-name');
    if (impersonationBanner) {
        if (AppState.impersonating && AppState.impersonatingTenantName) {
            if (impersonationTenantName) impersonationTenantName.textContent = AppState.impersonatingTenantName;
            impersonationBanner.classList.remove('hidden');
        } else {
            impersonationBanner.classList.add('hidden');
        }
    }
    setActiveTab(AppState.activeTab);
}

function logout() {
    fetch(API_BASE + 'auth.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'logout' }),
        credentials: 'same-origin'
    }).then(function() {
        AppState.user = null;
        AppState.tenant = null;
        AppState.tokenUsage = null;
        AppState.platformCompanyName = null;
        AppState.activeTab = 'dashboard';
        document.title = 'MapsProspector Pro | CRM Integration';
        var tokenBanner = document.getElementById('header-token-warning');
        if (tokenBanner) tokenBanner.classList.add('hidden');
        var userDropdown = document.getElementById('user-dropdown');
        if (userDropdown) userDropdown.classList.add('hidden');
        showLogin();
    }).catch(function() {
        showLogin();
    });
}
function showCadastro() {
    const overlay = document.getElementById('modal-cadastro-overlay');
    const success = document.getElementById('cadastro-success');
    if (overlay) overlay.classList.remove('hidden');
    if (success) { success.classList.add('hidden'); success.textContent = ''; }
    document.body.style.overflow = 'hidden';
}

function hideCadastro() {
    const overlay = document.getElementById('modal-cadastro-overlay');
    if (overlay) overlay.classList.add('hidden');
    document.body.style.overflow = '';
}

async function handleCadastroSubmit(e) {
    if (e && e.preventDefault) e.preventDefault();
    const company = (document.getElementById('reg-company')?.value || '').trim();
    const email = (document.getElementById('reg-email')?.value || '').trim().toLowerCase();
    const phone = (document.getElementById('reg-phone')?.value || '').trim();
    const name = (document.getElementById('reg-name')?.value || '').trim();
    const regPassword = document.getElementById('reg-password')?.value || '';
    const regPasswordConfirm = document.getElementById('reg-password-confirm')?.value || '';
    const errorEl = document.getElementById('reg-error');
    const btn = document.getElementById('btn-cadastro');

    if (errorEl) { errorEl.classList.add('hidden'); errorEl.textContent = ''; }
    
    if (!company) { if (errorEl) { errorEl.textContent = 'Nome da empresa é obrigatório.'; errorEl.classList.remove('hidden'); } return; }
    if (!email || !email.includes('@')) { if (errorEl) { errorEl.textContent = 'E-mail inválido.'; errorEl.classList.remove('hidden'); } return; }
    if (regPassword.length < 6) { if (errorEl) { errorEl.textContent = 'A senha deve ter no mínimo 6 caracteres.'; errorEl.classList.remove('hidden'); } return; }
    if (regPassword !== regPasswordConfirm) { if (errorEl) { errorEl.textContent = 'As senhas não coincidem.'; errorEl.classList.remove('hidden'); } return; }
    
    if (btn) btn.disabled = true;
    try {
        const res = await fetch(API_BASE + 'register.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                companyName: company, 
                adminEmail: email, 
                adminPhone: phone, 
                adminName: name || undefined, 
                adminPassword: regPassword 
            })  
        });
        const data = await res.json();
        if (data.success) {
            hideCadastro();
            const successEl = document.getElementById('cadastro-success');
            const loginEmail = document.getElementById('login-email');
            if (successEl) { successEl.textContent = data.message || 'Empresa cadastrada com sucesso.'; successEl.classList.remove('hidden'); }
            if (loginEmail) loginEmail.value = email;
            document.querySelectorAll('#form-cadastro input').forEach(input => input.value = '');
        } else {
            if (errorEl) { errorEl.textContent = data.error || 'Erro ao cadastrar.'; errorEl.classList.remove('hidden'); }
        }
    } catch (err) {
        if (errorEl) { errorEl.textContent = 'Erro de conexão.'; errorEl.classList.remove('hidden'); }
    } finally {
        if (btn) btn.disabled = false;
    }
}

function showModalPerfil() {
    var overlay = document.getElementById('modal-perfil-overlay');
    var errorEl = document.getElementById('perfil-error');
    var successEl = document.getElementById('perfil-success');
    if (overlay) overlay.classList.remove('hidden');
    if (errorEl) { errorEl.classList.add('hidden'); errorEl.textContent = ''; }
    if (successEl) { successEl.classList.add('hidden'); successEl.textContent = ''; }
    
    var current = document.getElementById('perfil-senha-atual');
    var nova = document.getElementById('perfil-senha-nova');
    var confirm = document.getElementById('perfil-senha-confirm');
    if (current) current.value = '';
    if (nova) nova.value = '';
    if (confirm) confirm.value = '';
    
    var phone = document.getElementById('perfil-phone');
    if (phone && AppState.user) phone.value = AppState.user.phone || '';
    document.body.style.overflow = 'hidden';
}

function hideModalPerfil() {
    var overlay = document.getElementById('modal-perfil-overlay');
    if (overlay) overlay.classList.add('hidden');
    document.body.style.overflow = '';
}

async function handlePerfilSenhaSubmit(e) {
    if (e && e.preventDefault) e.preventDefault();
    
    var currentPassword = document.getElementById('perfil-senha-atual')?.value || '';
    var newPassword = document.getElementById('perfil-senha-nova')?.value || '';
    var newPasswordConfirm = document.getElementById('perfil-senha-confirm')?.value || '';
    var newPhone = document.getElementById('perfil-phone')?.value || '';
    var errorEl = document.getElementById('perfil-error');
    var successEl = document.getElementById('perfil-success');
    var btn = document.getElementById('btn-perfil-salvar');

    if (errorEl) { errorEl.classList.add('hidden'); errorEl.textContent = ''; }
    
    if (newPassword && newPassword.length < 6) { 
        errorEl.textContent = 'A nova senha deve ter no mínimo 6 caracteres.'; 
        errorEl.classList.remove('hidden'); 
        return; 
    }
    if (newPassword !== newPasswordConfirm) { 
        errorEl.textContent = 'As senhas não coincidem.'; 
        errorEl.classList.remove('hidden'); 
        return; 
    }

    if (btn) btn.disabled = true;
    try {
        var res = await fetch(API_BASE + 'auth.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                action: 'update_profile', 
                currentPassword: currentPassword, 
                newPassword: newPassword,
                phone: newPhone 
            })
        });
        var data = await res.json();
        if (data.success) {
            if (successEl) { successEl.textContent = 'Perfil atualizado com sucesso.'; successEl.classList.remove('hidden'); }
            if (AppState.user) AppState.user.phone = newPhone;
            setTimeout(hideModalPerfil, 1500);
        } else {
            errorEl.textContent = data.error || 'Erro ao atualizar perfil.';
            errorEl.classList.remove('hidden');
        }
    } catch (err) {
        errorEl.textContent = 'Erro de conexão com servidor.';
        errorEl.classList.remove('hidden');
    } finally {
        if (btn) btn.disabled = false;
    }
}
function setupEventListeners() {
    console.log('Setting up event listeners...');
    
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleLogin(e);
        });
    }

    const btnLogin = document.getElementById('btn-login');
    if (btnLogin) {
        btnLogin.addEventListener('click', function(e) {
            e.preventDefault();
            handleLogin(e);
        });
    }

    const linkCadastro = document.getElementById('link-cadastro');
    if (linkCadastro) linkCadastro.addEventListener('click', showCadastro);
    
    const btnCadastroVoltar = document.getElementById('btn-cadastro-voltar');
    if (btnCadastroVoltar) btnCadastroVoltar.addEventListener('click', hideCadastro);
    
    const modalCadastroFechar = document.getElementById('modal-cadastro-fechar');
    if (modalCadastroFechar) modalCadastroFechar.addEventListener('click', hideCadastro);
    
    const modalCadastroOverlay = document.getElementById('modal-cadastro-overlay');
    if (modalCadastroOverlay) {
        modalCadastroOverlay.addEventListener('click', function(e) {
            if (e.target === modalCadastroOverlay) hideCadastro();
        });
    }

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const cadastroOverlay = document.getElementById('modal-cadastro-overlay');
            const perfilOverlay = document.getElementById('modal-perfil-overlay');
            if (cadastroOverlay && !cadastroOverlay.classList.contains('hidden')) hideCadastro();
            else if (perfilOverlay && !perfilOverlay.classList.contains('hidden')) hideModalPerfil();
        }
    });

    const formCadastro = document.getElementById('form-cadastro');
    if (formCadastro) formCadastro.addEventListener('submit', handleCadastroSubmit);

    var modalPerfilFechar = document.getElementById('modal-perfil-fechar');
    if (modalPerfilFechar) modalPerfilFechar.addEventListener('click', hideModalPerfil);
    
    var btnPerfilFechar = document.getElementById('btn-perfil-fechar');
    if (btnPerfilFechar) btnPerfilFechar.addEventListener('click', hideModalPerfil);
    
    var modalPerfilOverlay = document.getElementById('modal-perfil-overlay');
    if (modalPerfilOverlay) {
        modalPerfilOverlay.addEventListener('click', function(e) {
            if (e.target === modalPerfilOverlay) hideModalPerfil();
        });
    }
    
    var formPerfilSenha = document.getElementById('form-perfil-senha');
    if (formPerfilSenha) formPerfilSenha.addEventListener('submit', handlePerfilSenhaSubmit);

    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const tab = btn.dataset.tab;
            if (tab) setActiveTab(tab);
        });
    });
    
    var btnThemeToggle = document.getElementById('btn-theme-toggle');
    if (btnThemeToggle) {
        btnThemeToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleTheme();
        });
    }
    
    var btnThemeToggleLanding = document.getElementById('btn-theme-toggle-landing');
    if (btnThemeToggleLanding) {
        btnThemeToggleLanding.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleTheme();
            updateThemeIconsLanding();
        });
    }

    var headerUserArea = document.getElementById('header-user-area');
    var userDropdown = document.getElementById('user-dropdown');
    var btnLogout = document.getElementById('btn-logout');
    var btnPerfil = document.getElementById('btn-perfil');

    if (headerUserArea && userDropdown) {
        headerUserArea.onclick = function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('hidden');
        };
    }

    if (btnPerfil) {
        btnPerfil.onclick = function(e) {
            e.stopPropagation();
            userDropdown.classList.add('hidden');
            showModalPerfil();
        };
    }

    if (btnLogout) {
        btnLogout.onclick = function(e) {
            e.stopPropagation();
            userDropdown.classList.add('hidden');
            logout();
        };
    }
    
    var btnStopImpersonate = document.getElementById('btn-stop-impersonate');
    if (btnStopImpersonate) {
        btnStopImpersonate.onclick = function() {
            fetch(API_BASE + 'auth.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ action: 'stop_impersonate' })
            }).then(function(r) { return r.json(); }).then(function(res) {
                if (res.success) {
                    AppState.impersonating = false;
                    AppState.impersonatingTenantName = '';
                    checkAuth();
                    window.location.reload();
                } else {
                    alert(res.error || 'Erro ao sair do acesso.');
                }
            }).catch(function() { alert('Erro de conexão.'); });
        };
    }
    document.addEventListener('click', function(e) {
        if (userDropdown && !userDropdown.contains(e.target) && headerUserArea && !headerUserArea.contains(e.target)) {
            userDropdown.classList.add('hidden');
        }
    });
}
function renderDashboardTab(contentArea) {
    var isSuperAdmin = AppState.user && String(AppState.user.profile).toLowerCase() === 'super_admin';

    if (isSuperAdmin) {
        contentArea.innerHTML = `
            <div class="max-w-6xl mx-auto space-y-8 pb-20">
                <div class="flex justify-between items-center flex-wrap gap-4">
                    <div>
                        <h3 class="text-2xl font-black text-slate-900 dark:text-slate-100">Visão Geral da Plataforma</h3>
                        <p class="text-sm text-slate-500 dark:text-slate-400">Métricas e estatísticas globais do seu SaaS.</p>
                    </div>
                    <button type="button" onclick="loadSuperAdminDashboardStats()" class="bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2">🔄 Atualizar Métricas</button>
                </div>

                <div id="super-admin-stats-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div class="bg-white dark:bg-slate-800 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-wider mb-1">Empresas Cadastradas</p>
                        <p id="stat-companies" class="text-3xl font-black text-slate-900 dark:text-slate-100">-</p>
                        <p id="stat-companies-sub" class="text-xs text-slate-500 dark:text-slate-400 mt-2">Carregando...</p>
                    </div>
                    <div class="bg-white dark:bg-slate-800 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-wider mb-1">Total de Leads Gerados</p>
                        <p id="stat-leads" class="text-3xl font-black text-emerald-600">-</p>
                        <p id="stat-searches-sub" class="text-xs text-slate-500 dark:text-slate-400 mt-2">Carregando...</p>
                    </div>
                    <div class="bg-white dark:bg-slate-800 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-wider mb-1">Chaves de pesquisa ativas</p>
                        <p id="stat-apify" class="text-3xl font-black text-purple-600">-</p>
                        <p id="stat-apify-sub" class="text-xs text-slate-500 dark:text-slate-400 mt-2">Carregando...</p>
                    </div>
                    <div class="bg-white dark:bg-slate-800 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-wider mb-1">Solicitações Pendentes</p>
                        <p id="stat-pending" class="text-3xl font-black text-amber-600">-</p>
                        <p class="text-xs text-slate-500 dark:text-slate-400 mt-2">Planos ou créditos</p>
                    </div>
                </div>

                <div class="mt-10">
                    <h3 class="text-xl font-black text-slate-900 dark:text-slate-100 mb-6">Uso de créditos por empresa</h3>
                    <div id="dashboard-tenants-usage" class="bg-white dark:bg-slate-800 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm overflow-hidden">
                        <div class="p-8 text-center text-slate-500 dark:text-slate-400">
                            <span class="inline-block w-8 h-8 border-2 border-slate-300 border-t-blue-600 rounded-full animate-spin"></span>
                            <p class="mt-3 text-sm font-bold">Carregando empresas…</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        loadSuperAdminDashboardStats();
        setTimeout(function() { loadDashboardTenantsUsage(); }, 0);
        return;
    }

    var u = AppState.tokenUsage || { used: 0, limit: 0, limitReached: false };
    var used = u.used || 0;
    var limit = u.limit != null ? u.limit : 0;
    var limitLabel = limit === 0 ? 'Ilimitado' : limit;
    var available = limit === 0 ? 'Ilimitado' : Math.max(0, limit - used);
    var tenantName = (AppState.tenant && AppState.tenant.name) ? AppState.tenant.name : '—';
    
    contentArea.innerHTML = '<div class="max-w-4xl mx-auto">' +
        '<h3 class="text-2xl font-black text-slate-900 dark:text-slate-100 mb-8">Estatísticas da conta</h3>' +
        '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">' +
        '<div class="bg-white dark:bg-slate-800 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm">' +
        '<div class="flex items-center gap-4 mb-4"><div class="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center">' +
        '<svg class="w-7 h-7 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg></div>' +
        '<div><p class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Créditos utilizados</p><p class="text-3xl font-black text-slate-900 dark:text-slate-100">' + used + '</p></div></div>' +
        '<p class="text-xs text-slate-500 dark:text-slate-400">Consumo: 1 crédito por lead único capturado no Google Maps e 5 créditos por consulta de CNPJ.</p></div>' +
        '<div class="bg-white dark:bg-slate-800 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm">' +
        '<div class="flex items-center gap-4 mb-4"><div class="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center">' +
        '<svg class="w-7 h-7 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg></div>' +
        '<div><p class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Créditos permitidos (plano)</p><p class="text-3xl font-black text-slate-900 dark:text-slate-100">' + limitLabel + '</p></div></div>' +
        '<p class="text-xs text-slate-500 dark:text-slate-400">Limite do plano vinculado à sua empresa neste período.</p></div>' +
        '<div class="bg-white dark:bg-slate-800 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm sm:col-span-2 lg:col-span-1">' +
        '<div class="flex items-center gap-4 mb-4"><div class="w-14 h-14 bg-slate-100 dark:bg-slate-700 rounded-2xl flex items-center justify-center">' +
        '<svg class="w-7 h-7 text-slate-600 dark:text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg></div>' +
        '<div><p class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Disponível</p><p class="text-3xl font-black text-slate-900 dark:text-slate-100">' + available + '</p></div></div>' +
        '<p class="text-xs text-slate-500 dark:text-slate-400">Créditos restantes para novas buscas e consultas.</p></div>' +
        '</div>' +
        '<div class="mt-8 p-6 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-600">' +
        '<p class="text-sm font-bold text-slate-700 dark:text-slate-300"><span class="text-slate-500 dark:text-slate-400">Empresa:</span> ' + tenantName + '</p>' +
        '</div>' +
        '</div>';
}

function loadDashboardTenantsUsage() {
    var container = document.getElementById('dashboard-tenants-usage');
    if (!container) return;
    fetch(API_BASE + 'tenants.php', { method: 'GET', credentials: 'include', cache: 'no-store' })
        .then(function(r) { return r.json(); })
        .then(function(res) {
            if (!res.success || !res.data) {
                container.innerHTML = '<div class="p-8 text-center text-amber-600 font-bold text-sm">Erro ao carregar empresas.</div>';
                return;
            }
            var items = (res.data.items && res.data.items.length) ? res.data.items : (Array.isArray(res.data) ? res.data : []);
            if (items.length === 0) {
                container.innerHTML = '<div class="p-8 text-center text-slate-500 dark:text-slate-400 text-sm font-bold">Nenhuma empresa cadastrada.</div>';
                return;
            }
            var html = '<div class="overflow-x-auto"><table class="w-full text-left"><thead><tr class="border-b border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-800/50"><th class="px-6 py-4 text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider">Empresa</th><th class="px-6 py-4 text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Tokens válidos (limite)</th><th class="px-6 py-4 text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Tokens utilizados</th></tr></thead><tbody>';
            items.forEach(function(t) {
                var limitLabel = (t.tokensLimit != null && t.tokensLimit === 0) ? 'Ilimitado' : (t.tokensLimit != null ? t.tokensLimit : '—');
                var used = t.tokensUsed != null ? t.tokensUsed : 0;
                html += '<tr class="border-b border-slate-100 dark:border-slate-600 hover:bg-slate-50/50 dark:hover:bg-slate-700/50"><td class="px-6 py-4"><span class="font-bold text-slate-900 dark:text-slate-100">' + (t.name || '—') + '</span>' + (t.plan ? '<span class="block text-[11px] font-bold text-slate-400 uppercase">' + t.plan + '</span>' : '') + '</td><td class="px-6 py-4 text-right font-bold text-slate-700 dark:text-slate-300">' + limitLabel + '</td><td class="px-6 py-4 text-right font-bold text-slate-900 dark:text-slate-100">' + used + '</td></tr>';
            });
            html += '</tbody></table></div>';
            container.innerHTML = html;
        })
        .catch(function() {
            if (container) container.innerHTML = '<div class="p-8 text-center text-amber-600 font-bold text-sm">Erro de conexão ao carregar empresas.</div>';
        });
}
function renderRequestCreditsTab(contentArea) {
    contentArea.innerHTML = '<div class="max-w-2xl mx-auto">' +
        '<h3 class="text-2xl font-black text-slate-900 dark:text-slate-100 mb-6">Solicitar créditos</h3>' +
        '<p class="text-sm text-slate-500 dark:text-slate-400 mb-8">Solicite créditos (tokens) adicionais para sua empresa. O administrador da plataforma analisará e poderá aprovar ou recusar.</p>' +
        '<div id="request-credits-error" class="hidden mb-6 p-4 bg-red-50 border border-red-200 rounded-2xl text-red-700 text-sm font-medium"></div>' +
        '<div id="request-credits-success" class="hidden mb-6 p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-700 text-sm font-medium"></div>' +
        '<div class="bg-white dark:bg-slate-800 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm mb-10">' +
        '<form id="request-credits-form" class="space-y-4">' +
        '<div><div class="flex flex-wrap items-end gap-4">' +
        '<div class="flex-1 min-w-[140px]"><label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Quantidade de créditos (tokens)</label>' +
        '<input id="request-credits-amount" type="number" min="100" max="10000" class="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium placeholder-slate-400 dark:placeholder-slate-500" placeholder="Ex: 100" required /></div>' +
        '<div id="request-credits-total-wrap" class="flex-1 min-w-[140px] pb-1 hidden"><p class="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Valor a pagar</p>' +
        '<p id="request-credits-total-line" class="text-lg font-bold text-blue-600"><span id="request-credits-total-value">—</span></p></div></div>' +
        '<div class="mt-3"><label class="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase mb-2">Ou arraste até 10.000</label>' +
        '<input id="request-credits-slider" type="range" min="100" max="10000" step="1" value="100" class="w-full h-3 rounded-full appearance-none bg-slate-200 accent-blue-600 cursor-pointer" />' +
        '<p id="request-credits-slider-label" class="text-[10px] text-slate-400 mt-1 text-right">100 créditos</p></div>' +
        '<p class="text-[10px] text-slate-400 mt-1">Cada crédito = 1 busca no período atual.</p>' +
        '<p id="request-credits-price-line" class="text-sm font-medium text-slate-600 dark:text-slate-400 mt-2 hidden">Valor avulso: <span class="font-bold text-slate-800 dark:text-slate-200"></span> por crédito</p></div>' +
        '<button type="submit" id="request-credits-submit" class="w-full py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700">Enviar solicitação</button>' +
        '</form></div>' +
        '<h4 class="text-lg font-black text-slate-900 dark:text-slate-100 mb-4">Minhas solicitações</h4>' +
        '<div id="request-credits-list"></div></div>';
    setupRequestCreditsEvents();
    loadRequestCreditsList();
}

function setupRequestCreditsEvents() {
    var form = document.getElementById('request-credits-form');
    if (!form) return;
    var amountEl = document.getElementById('request-credits-amount');
    var sliderEl = document.getElementById('request-credits-slider');
    var sliderLabel = document.getElementById('request-credits-slider-label');
    var totalWrap = document.getElementById('request-credits-total-wrap');
    var totalValue = document.getElementById('request-credits-total-value');

    function getAmountNum() {
        var n = parseInt(amountEl.value, 10);
        if (isNaN(n) || n < 100) return 100;
        if (n > 10000) return 10000;
        return n;
    }
    function getPricePerCredit() {
        return parseFloat(form.dataset.pricePerCredit || '0', 10);
    }
    function syncFromInput() {
        var num = getAmountNum();
        var pricePerCredit = getPricePerCredit();
        if (sliderEl) sliderEl.value = num;
        if (sliderLabel) sliderLabel.textContent = num.toLocaleString('pt-BR') + ' créditos';
        if (totalWrap && totalValue) {
            if (pricePerCredit > 0 && num >= 100) {
                totalValue.textContent = 'R$ ' + (num * pricePerCredit).toFixed(2).replace('.', ',');
                totalWrap.classList.remove('hidden');
            } else {
                totalValue.textContent = '—';
            }
        }
    }
    function syncFromSlider() {
        var num = parseInt(sliderEl.value, 10);
        var pricePerCredit = getPricePerCredit();
        amountEl.value = num;
        if (sliderLabel) sliderLabel.textContent = num.toLocaleString('pt-BR') + ' créditos';
        if (totalWrap && totalValue) {
            if (pricePerCredit > 0 && num >= 100) {
                totalValue.textContent = 'R$ ' + (num * pricePerCredit).toFixed(2).replace('.', ',');
                totalWrap.classList.remove('hidden');
            } else {
                totalValue.textContent = '—';
            }
        }
    }
    if (amountEl) {
        amountEl.addEventListener('input', syncFromInput);
        amountEl.addEventListener('change', syncFromInput);
    }
    if (sliderEl) sliderEl.addEventListener('input', syncFromSlider);

    form.onsubmit = async function(e) {
        e.preventDefault();
        var num = getAmountNum();
        if (num < 100 || num > 10000) {
            var err = document.getElementById('request-credits-error');
            if (err) {
                err.textContent = 'Informe uma quantidade entre 100 e 10.000.';
                err.classList.remove('hidden');
            }
            return;
        }

        var errEl = document.getElementById('request-credits-error');
        var successEl = document.getElementById('request-credits-success');
        if (errEl) errEl.classList.add('hidden');
        if (successEl) successEl.classList.add('hidden');
        
        var btn = document.getElementById('request-credits-submit');
        if (btn) {
            btn.disabled = true;
            btn.textContent = 'Enviando solicitação...';
        }

        try {
            const res = await fetch(API_BASE + 'create-payment.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({
                    type: 'credits',
                    amount: 0,
                    credits: num
                })
            });
            const raw = await res.text();
            let data = null;
            try {
                data = raw ? JSON.parse(raw) : null;
            } catch (parseError) {
                throw new Error('Resposta inválida do servidor.');
            }
            if (res.ok && data && data.success) {
                if (successEl) {
                    successEl.textContent = data.message || 'Solicitação de créditos enviada para análise.';
                    successEl.classList.remove('hidden');
                }
                amountEl.value = '';
                if (sliderEl) sliderEl.value = 100;
                if (sliderLabel) sliderLabel.textContent = '100 créditos';
                if (totalValue) totalValue.textContent = '—';
                if (totalWrap) totalWrap.classList.add('hidden');
                loadRequestCreditsList();
            } else {
                if (errEl) {
                    errEl.textContent = (data && data.error) ? data.error : 'Erro ao enviar a solicitação.';
                    errEl.classList.remove('hidden');
                }
            }
        } catch (err) {
            console.error('Falha ao confirmar solicitação de créditos:', err);
            if (errEl) {
                errEl.textContent = 'Não foi possível confirmar a solicitação agora. Atualize a página antes de tentar novamente.';
                errEl.classList.remove('hidden');
            }
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.textContent = 'Enviar solicitação';
            }
        }
    };
}

function loadRequestCreditsList() {
    var form = document.getElementById('request-credits-form');
    var priceLine = document.getElementById('request-credits-price-line');
    var listEl = document.getElementById('request-credits-list');
    
    if (!listEl) return;

    fetch(API_BASE + 'credit-requests.php', { credentials: 'include' })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        var pricePerCredit = (data.success && data.data && data.data.hasOwnProperty('pricePerCredit')) ? parseFloat(data.data.pricePerCredit, 10) : 0;
        if (isNaN(pricePerCredit)) pricePerCredit = 0;
        if (form) form.dataset.pricePerCredit = String(pricePerCredit);
        
        if (priceLine) {
            if (pricePerCredit > 0) {
                var priceStr = 'R$ ' + pricePerCredit.toFixed(2).replace('.', ',');
                priceLine.querySelector('span').textContent = priceStr + ' por crédito';
                priceLine.classList.remove('hidden');
            } else {
                priceLine.classList.add('hidden');
            }
        }

        if (!data.success || !data.data || !data.data.items) {
            listEl.innerHTML = '<div class="py-12 text-center border-2 border-dashed border-slate-200 dark:border-slate-600 rounded-[2rem]"><p class="text-slate-400 font-bold uppercase text-[10px]">Nenhuma solicitação</p></div>';
            return;
        }

        var items = data.data.items;
        if (items.length === 0) {
            listEl.innerHTML = '<div class="py-12 text-center border-2 border-dashed border-slate-200 dark:border-slate-600 rounded-[2rem]"><p class="text-slate-400 font-bold uppercase text-[10px]">Nenhuma solicitação</p></div>';
            return;
        }

        var html = '<div class="space-y-4">';
        items.forEach(function(r) {
            var statusLabel = r.status === 'pending' ? 'Pendente' : r.status === 'approved' ? 'Aprovado' : 'Recusado';
            var statusClass = r.status === 'pending' ? 'text-amber-600' : r.status === 'approved' ? 'text-emerald-600' : 'text-red-600';
            var dateStr = r.createdAt ? new Date(r.createdAt).toLocaleString('pt-BR') : '';
            html += '<div class="bg-white dark:bg-slate-800 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600 flex items-center justify-between">';
            var valueStr = pricePerCredit > 0 ? ' · <span class="text-blue-600 font-bold">R$ ' + (r.tokensRequested * pricePerCredit).toFixed(2).replace('.', ',') + '</span>' : '';
            html += '<div><p class="font-extrabold text-slate-900 dark:text-slate-100">' + r.tokensRequested + ' créditos' + valueStr + '</p>';
            html += '<p class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">' + dateStr + ' · <span class="' + statusClass + '">' + statusLabel + '</span></p></div>';
            if (r.status === 'pending') html += '<span class="bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-xs font-bold">Aguardando</span>';
            html += '</div>';
        });
        html += '</div>';
        listEl.innerHTML = html;
    })
    .catch(function(err) {
        var listElRetry = document.getElementById('request-credits-list');
        if (listElRetry) {
            listElRetry.innerHTML = '<div class="py-12 text-center border-2 border-dashed border-slate-200 dark:border-slate-600 rounded-[2rem]"><p class="text-slate-400 font-bold uppercase text-[10px]">Erro ao carregar</p></div>';
        }
        console.error("Erro na lista de créditos:", err);
    });
}
function renderChoosePlanTab(contentArea) {
    var currentPlanName = (AppState.tenant && AppState.tenant.planName) ? AppState.tenant.planName : '';
    var currentPlanId = (AppState.tenant && AppState.tenant.planId) ? String(AppState.tenant.planId) : '';
    contentArea.innerHTML = '<div class="max-w-4xl mx-auto">' +
        '<h3 class="text-2xl font-black text-slate-900 dark:text-slate-100 mb-2">Meu plano</h3>' +
        '<p class="text-sm text-slate-500 dark:text-slate-400 mb-8">Escolha um plano para sua empresa. Após solicitar, o administrador confirmará e seu plano será atualizado.</p>' +
        (currentPlanName ? '<div class="mb-8 p-6 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-600"><p class="text-[10px] font-black text-slate-400 uppercase tracking-wider mb-1">Plano atual</p><p class="text-lg font-bold text-slate-900 dark:text-slate-100">' + currentPlanName + '</p></div>' : '') +
        '<div id="choose-plan-pending" class="hidden mb-8 p-4 bg-amber-50 border border-amber-200 rounded-2xl text-amber-800 text-sm font-medium"></div>' +
        '<div id="choose-plan-error" class="hidden mb-6 p-4 bg-red-50 border border-red-200 rounded-2xl text-red-700 text-sm font-medium"></div>' +
        '<div id="choose-plan-spinner" class="py-24 text-center"><span class="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin inline-block"></span></div>' +
        '<div id="choose-plan-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10 hidden"></div>' +
        '<div id="choose-plan-history" class="hidden mt-10"><h4 class="text-lg font-black text-slate-900 dark:text-slate-100 mb-4">Histórico de solicitações</h4><div id="choose-plan-history-list"></div></div></div>';
    loadChoosePlanData(currentPlanId);
}

function loadChoosePlanData(currentPlanId) {
    var spinnerEl = document.getElementById('choose-plan-spinner');
    var gridEl = document.getElementById('choose-plan-grid');
    var errorEl = document.getElementById('choose-plan-error');
    if (!gridEl) return;

    fetch(API_BASE + 'plans-public.php', { credentials: 'include' })
        .then(function(r) { return r.json(); })
        .then(function(plansData) {
            if (spinnerEl) spinnerEl.classList.add('hidden');
            var plans = (plansData.success && plansData.data && plansData.data.items) ? plansData.data.items : [];
            
            var html = '';
            plans.forEach(function(p) {
                var isCurrent = currentPlanId === String(p.id);
                var isTrial = p.slug === 'trial';
                var priceNum = parseFloat(p.priceMonthly || 0);
                var priceText = isTrial ? 'Grátis' : 'R$ ' + priceNum.toFixed(2).replace('.', ',');
                var tokenText = (p.tokenLimit || 0).toLocaleString('pt-BR') + ' créditos';

                html += '<div class="bg-white dark:bg-slate-800 p-6 rounded-[2rem] border-2 ' + (isCurrent ? 'border-blue-400 bg-blue-50/50 dark:bg-blue-900/30' : 'border-slate-200 dark:border-slate-600') + '">';
                html += '<div class="flex items-center gap-4 mb-4"><div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center text-lg font-black text-blue-600">' + (p.tokenLimit >= 1000 ? (p.tokenLimit / 1000) + 'K' : p.tokenLimit) + '</div>';
                html += '<div><h4 class="font-extrabold text-slate-900 dark:text-slate-100 text-lg">' + (p.name || '') + '</h4><p class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">' + tokenText + '</p></div></div>';
                html += '<p class="text-2xl font-black mb-4">' + (isTrial ? '<span class="text-emerald-600">' + priceText + '</span>' : priceText) + '<span class="text-sm font-bold text-slate-400">/mês</span></p>';
                
                if (isCurrent) {
                    html += '<p class="text-sm font-bold text-blue-600">Plano atual</p>';
                } else if (!isTrial && priceNum > 0) {
                    html += '<button type="button" class="btn-request-plan w-full py-3 rounded-xl bg-blue-600 text-white font-bold text-sm hover:bg-blue-700 shadow-lg shadow-blue-600/20" data-plan-id="' + p.id + '" data-price="' + priceNum + '">Solicitar este plano</button>';
                } else {
                    html += '<p class="text-sm text-slate-400">Gratuito</p>';
                }
                html += '</div>';
            });
            gridEl.innerHTML = html;
            gridEl.classList.remove('hidden');

            gridEl.querySelectorAll('.btn-request-plan').forEach(function(btn) {
                btn.onclick = async function() {
                    var planId = btn.getAttribute('data-plan-id');
                    btn.disabled = true;
                    btn.textContent = 'Enviando solicitação...';

                    try {
                        const res = await fetch(API_BASE + 'create-payment.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            credentials: 'include',
                            body: JSON.stringify({
                                type: 'plan',
                                amount: 0,
                                planId: parseInt(planId, 10)
                            })
                        });
                        const data = await res.json().catch(function() { return null; });

                        if (data && data.success) {
                            var pendingEl = document.getElementById('choose-plan-pending');
                            if (pendingEl) {
                                pendingEl.textContent = data.message || 'Solicitação de plano enviada para análise.';
                                pendingEl.className = 'mb-8 p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-700 text-sm font-medium';
                            }
                        } else {
                            alert((data && data.error) ? data.error : 'Erro ao enviar a solicitação de plano.');
                        }
                    } catch (e) {
                        alert('Erro de conexão ao enviar a solicitação de plano.');
                    } finally {
                        btn.disabled = false;
                        btn.textContent = 'Solicitar este plano';
                    }
                };
            });
        }).catch(function() {
            if (spinnerEl) spinnerEl.classList.add('hidden');
            if (errorEl) { errorEl.textContent = 'Erro ao carregar planos.'; errorEl.classList.remove('hidden'); }
        });
}

function renderCreditsAdminTab(contentArea) {
    contentArea.innerHTML = '<div class="max-w-4xl mx-auto">' +
        '<div class="flex justify-between items-center mb-10">' +
        '<h3 class="text-2xl font-black text-slate-900 dark:text-slate-100">Solicitações de créditos</h3>' +
        '<button type="button" id="credits-admin-refresh" class="bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 font-bold px-4 py-3 rounded-2xl text-xs flex items-center gap-2">Atualizar</button></div>' +
        '<div id="credits-admin-error" class="hidden mb-6 p-4 bg-red-50 border border-red-200 rounded-2xl text-red-700 text-sm font-medium"></div>' +
        '<div id="credits-admin-list"></div></div>';
    document.getElementById('credits-admin-refresh').onclick = function() { loadCreditsAdminList(); };
    loadCreditsAdminList();
}

function loadCreditsAdminList() {
    var listEl = document.getElementById('credits-admin-list');
    var errEl = document.getElementById('credits-admin-error');
    if (!listEl) return;
    listEl.innerHTML = '<div class="py-12 text-center"><span class="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin inline-block"></span></div>';
    if (errEl) errEl.classList.add('hidden');
    fetch(API_BASE + 'credit-requests.php', { credentials: 'include' }).then(function(r) { return r.json(); }).then(function(data) {
        if (!data.success || !data.data || !data.data.items) {
            listEl.innerHTML = '<div class="py-24 text-center border-2 border-dashed border-slate-200 dark:border-slate-600 rounded-[2rem]"><p class="text-slate-400 font-bold uppercase text-[10px]">Nenhuma solicitação de créditos</p></div>';
            return;
        }
        var items = data.data.items;
        if (items.length === 0) {
            listEl.innerHTML = '<div class="py-24 text-center border-2 border-dashed border-slate-200 dark:border-slate-600 rounded-[2rem]"><p class="text-slate-400 font-bold uppercase text-[10px]">Nenhuma solicitação de créditos</p></div>';
            return;
        }
        var html = '<div class="space-y-4">';
        items.forEach(function(r) {
            var statusLabel = r.status === 'pending' ? 'Pendente' : r.status === 'approved' ? 'Aprovado' : 'Recusado';
            var statusClass = r.status === 'pending' ? 'text-amber-600' : r.status === 'approved' ? 'text-emerald-600' : 'text-red-600';
            var dateStr = r.createdAt ? new Date(r.createdAt).toLocaleString('pt-BR') : '';
            var reviewedStr = r.reviewedAt ? ' · ' + new Date(r.reviewedAt).toLocaleString('pt-BR') : '';
            var who = (r.requestedByName || r.requestedByEmail || '—');
            html += '<div class="bg-white dark:bg-slate-800 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600 flex flex-wrap items-center justify-between gap-4">';
            html += '<div class="flex items-center gap-6">';
            html += '<div class="w-12 h-12 bg-slate-100 dark:bg-slate-700 rounded-xl flex items-center justify-center text-xl font-black text-slate-600 dark:text-slate-400">' + (r.tenantName ? r.tenantName.charAt(0).toUpperCase() : 'E') + '</div>';
            html += '<div><h4 class="font-extrabold text-slate-900 dark:text-slate-100 text-lg">' + (r.tenantName || 'Empresa') + '</h4>';
            html += '<p class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">' + who + ' · ' + r.tokensRequested + ' créditos · ' + dateStr + '</p>';
            html += '<p class="text-xs font-bold mt-1 ' + statusClass + '">' + statusLabel + reviewedStr + '</p></div></div>';
            if (r.status === 'pending') {
                html += '<div class="flex items-center gap-2"><button type="button" class="btn-credit-approve bg-emerald-100 text-emerald-700 hover:bg-emerald-200 font-bold px-4 py-2 rounded-xl text-xs" data-id="' + r.id + '">Aceitar</button>';
                html += '<button type="button" class="btn-credit-reject bg-red-100 text-red-700 hover:bg-red-200 font-bold px-4 py-2 rounded-xl text-xs" data-id="' + r.id + '">Recusar</button></div>';
            }
            html += '</div>';
        });
        html += '</div>';
        listEl.innerHTML = html;
        listEl.querySelectorAll('.btn-credit-approve').forEach(function(btn) {
            btn.onclick = function() { reviewCreditRequest(btn.dataset.id, 'approved'); };
        });
        listEl.querySelectorAll('.btn-credit-reject').forEach(function(btn) {
            btn.onclick = function() { reviewCreditRequest(btn.dataset.id, 'rejected'); };
        });
    }).catch(function() {
        listEl.innerHTML = '<div class="py-24 text-center border-2 border-dashed border-slate-200 dark:border-slate-600 rounded-[2rem]"><p class="text-slate-400 font-bold uppercase text-[10px]">Erro ao carregar</p></div>';
    });
}

function reviewCreditRequest(id, status) {
    var errEl = document.getElementById('credits-admin-error');
    if (errEl) errEl.classList.add('hidden');
    fetch(API_BASE + 'credit-requests.php', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ id: id, status: status })
    }).then(function(r) { return r.json(); }).then(function(data) {
        if (data.success) loadCreditsAdminList();
        else if (errEl) { errEl.textContent = data.error || 'Erro ao processar.'; errEl.classList.remove('hidden'); }
    }).catch(function() {
        if (errEl) { errEl.textContent = 'Erro de conexão.'; errEl.classList.remove('hidden'); }
    });
}
function setActiveTab(tab) {
    // Bloqueia antes de alterar estado, título ou conteúdo. Isso protege
    // menus duplicados, caches de navegação e acionamentos manuais.
    var profile = AppState.user ? String(AppState.user.profile || '').toLowerCase() : '';
    if (['api-busca', 'notifications'].includes(tab) && profile !== 'super_admin') {
        tab = 'dashboard';
    }
    AppState.activeTab = tab;
    
    document.querySelectorAll('.tab-btn').forEach(btn => {
        if (btn.dataset.tab === tab) {
            btn.className = 'tab-btn w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all font-semibold text-sm bg-blue-600 text-white shadow-xl shadow-blue-900/30';
        } else {
            btn.className = 'tab-btn w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all font-semibold text-sm hover:bg-slate-100 dark:hover:bg-slate-700/50 text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-slate-300';
        }
    });
    
    const titles = {
        dashboard: 'Dashboard',
        search: 'Prospecção Inteligente',
        history: 'Arquivo de Buscas',
        'cnpj-lookup': 'Consulta CNPJ (Avançada)', 
        'cnpj-advanced': 'Busca Simples (Segmento)',
        'request-credits': 'Solicitar Créditos',
        'choose-plan': 'Meu plano',
        team: 'Minha Equipe', 
        'saas-config': 'Empresa SaaS',
        'latest-companies': 'Recém-Abertas',
        plans: 'Planos',
        companies: 'Empresas',
        credits: 'Créditos',
        'api-busca': 'API de Busca',
        notifications: 'Notificações',
        linkedin: 'Pesquisa LinkedIn',
        settings: 'Integração CRM',
        requests: 'Solicitações',
        'landing-page': 'Landing Page'
    };
    document.getElementById('page-title').textContent = titles[tab] || 'Dashboard';
    
    loadTab(tab);
}

function loadTab(tab) {
    const contentArea = document.getElementById('content-area');
    
    if (AppState.user) {
        const profile = String(AppState.user.profile).toLowerCase();
        const isSuperAdmin = (profile === 'super_admin');

        // As abas abaixo manipulam dados globais da plataforma. Nunca devem ser
        // carregadas por uma empresa, mesmo se uma aba anterior ficar ativa.
        const superAdminOnlyTabs = ['saas-config', 'plans', 'companies', 'credits', 'api-busca', 'notifications', 'landing-page'];
        if (!isSuperAdmin && superAdminOnlyTabs.includes(tab)) {
            setActiveTab('dashboard');
            return;
        }

        // O administrador administra o webhook geral da empresa; supervisor e
        // usuário normal administram somente o próprio webhook.
        const canManageWebhook = ['admin', 'supervisor', 'normal'].includes(profile);
        if (tab === 'settings' && !isSuperAdmin && !canManageWebhook) {
            setActiveTab('dashboard');
            return;
        }

        const canManageTeam = ['super_admin', 'admin', 'supervisor', 'manager', 'gerente'].includes(profile);
        if (tab === 'team' && !canManageTeam) {
            setActiveTab('dashboard');
            return;
        }

        const canUseLinkedIn = profile === 'admin'
            || profile === 'manager'
            || profile === 'gerente'
            || isSuperAdmin;

        if (tab === 'linkedin' && !canUseLinkedIn) {
            setActiveTab('dashboard');
            return;
        }

        // A configuração e o monitoramento da API de Busca são exclusivos do super administrador.
        if (tab === 'api-busca' && !isSuperAdmin) {
            setActiveTab('search');
            return;
        }

        // Supervisores podem configurar exclusivamente o webhook pessoal. Gerentes
        // e supervisores não acessam configurações globais, financeiras ou empresariais.
        if (profile === 'supervisor' || profile === 'manager' || profile === 'gerente') {
            const restrictedOperationalTabs = profile === 'supervisor'
                ? ['saas-config', 'plans', 'companies', 'credits', 'api-busca', 'notifications', 'choose-plan']
                : ['settings', 'saas-config', 'plans', 'companies', 'credits', 'api-busca', 'notifications', 'choose-plan'];
            if (restrictedOperationalTabs.includes(tab)) {
                setActiveTab('dashboard');
                return;
            }
        }
    }

    // Carregamento normal das abas...
    if (tab === 'dashboard') {
        renderDashboardTab(contentArea);
    } else if (tab === 'request-credits') {
        renderRequestCreditsTab(contentArea);
    } else if (tab === 'team') {
        renderTeamTab(contentArea);
    } else if (tab === 'search') {
        contentArea.innerHTML = getProspectingHTML();
        setupProspectingEvents();
    } else if (tab === 'history') {
        loadHistory();
    } else if (tab === 'cnpj-lookup') {
        renderCnpjLookupTab(contentArea);
    } else if (tab === 'cnpj-advanced') {
        renderCnpjAdvancedTab(contentArea);
    } else if (tab === 'choose-plan') {
        renderChoosePlanTab(contentArea);
    } else if (tab === 'credits') {
        // Aba administrativa distinta de “Solicitações”. Mostra a gestão de
        // solicitações de créditos sem misturar os pedidos de planos.
        renderCreditsAdminTab(contentArea);
    } else if (tab === 'requests') {
        renderRequestsTab(contentArea);
    } else if (tab === 'saas-config') {
        renderSaasConfigTab(contentArea);
    } else if (tab === 'plans') {
        loadPlansTab(contentArea);
    } else if (tab === 'companies') {
        loadCompaniesTab(contentArea);
    } else if (tab === 'help') {
        if (typeof renderHelpTab === 'function') {
            renderHelpTab(contentArea);
        } else {
            contentArea.innerHTML = '<div class="p-8 text-sm font-semibold text-slate-500">A aba de ajuda não está disponível no momento.</div>';
        }
    } else if (tab === 'linkedin') {
        if (typeof window.renderLinkedInTab === 'function') {
            window.renderLinkedInTab(contentArea);
        } else {
            contentArea.innerHTML = '<div class="p-8 text-sm font-semibold text-red-600">A interface de pesquisa LinkedIn não foi carregada. Verifique a inclusão de assets/js/linkedin-ui.js no index.php.</div>';
        }
    } else if (tab === 'notifications') {
        if (typeof window.renderNotificationsTab === 'function') {
            window.renderNotificationsTab(contentArea);
        } else {
            contentArea.innerHTML = '<div class="max-w-3xl mx-auto py-16 text-center"><h3 class="text-xl font-black text-slate-900 dark:text-slate-100 mb-2">Central de notificações indisponível</h3><p class="text-sm font-semibold text-slate-500 dark:text-slate-400">Verifique se o arquivo <code class="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800">assets/js/notification-ui.js</code> foi incluído antes do app.js no index.php.</p></div>';
        }
    } else if (tab === 'api-busca') {
        contentArea.innerHTML = getApiBuscaHTML();
        setupApiBuscaEvents();
        const usagePanel = document.getElementById('apify-usage-panel');
        if (usagePanel && typeof window.renderApifyUsagePanel === 'function') {
            window.renderApifyUsagePanel(usagePanel).catch(function (error) {
                console.error('Erro ao carregar o monitoramento das contas:', error);
            });
        }
        loadSettingsForm();
    } else if (tab === 'settings') {
        contentArea.innerHTML = getSettingsHTML();
        setupSettingsEvents();
        loadSettingsForm();
    } else if (tab === 'landing-page') {
        if (typeof renderLandingPageTab === 'function') {
            renderLandingPageTab(contentArea);
        } else {
            contentArea.innerHTML = `
                <div class="max-w-4xl mx-auto py-20 text-center">
                    <h3 class="text-2xl font-black text-slate-900 dark:text-slate-100 mb-2">Editor de Landing Page</h3>
                    <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">Gerencie as seções, textos e planos exibidos na página inicial.</p>
                    <div class="p-6 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-sm font-bold">
                        O módulo de edição visual da Landing Page está ativo. Certifique-se de que o arquivo JS responsável pelas seções públicas está incluído no seu template HTML principal.
                    </div>
                </div>
            `;
        }
}

function renderRequestsTab(contentArea) {
    if (!contentArea) return;
    contentArea.innerHTML = `
        <div class="max-w-5xl mx-auto py-10">
            <div class="flex items-center justify-between gap-4 mb-8">
                <div>
                    <p class="text-xs font-black uppercase tracking-[0.18em] text-blue-600 mb-2">Aprovação manual</p>
                    <h3 class="text-2xl font-black text-slate-900 dark:text-slate-100">Solicitações</h3>
                    <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Analise os pedidos pendentes de créditos e planos das empresas.</p>
                </div>
                <button type="button" id="requests-refresh" class="bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 font-bold px-4 py-3 rounded-2xl text-xs">Atualizar</button>
            </div>
            <div id="requests-credits-section" class="mb-8"></div>
            <div id="requests-plans-section" class="mb-8"></div>
        </div>`;
    document.getElementById('requests-refresh').onclick = loadRequestsTab;
    loadRequestsTab();
}

function loadRequestsTab() {
    const creditsSection = document.getElementById('requests-credits-section');
    const plansSection = document.getElementById('requests-plans-section');
    if (!creditsSection || !plansSection) return;

    const loading = '<div class="py-8 text-center text-sm font-bold text-slate-400">Carregando solicitações...</div>';
    creditsSection.innerHTML = loading;
    plansSection.innerHTML = loading;

    Promise.all([
        fetch(API_BASE + 'credit-requests.php', { credentials: 'include' }).then(r => r.json()),
        fetch(API_BASE + 'plan-requests.php', { credentials: 'include' }).then(r => r.json())
    ]).then(([creditsData, plansData]) => {
        const credits = creditsData?.success && Array.isArray(creditsData.data?.items) ? creditsData.data.items : [];
        const plans = plansData?.success && Array.isArray(plansData.data?.items) ? plansData.data.items : [];
        renderRequestsSection(creditsSection, 'Solicitações de créditos', credits, 'credit');
        renderRequestsSection(plansSection, 'Solicitações de planos', plans, 'plan');
    }).catch(error => {
        console.error('Falha ao carregar solicitações:', error);
        const errorHtml = '<div class="rounded-2xl border border-red-200 bg-red-50 dark:bg-red-950/30 dark:border-red-900 p-5 text-sm font-bold text-red-700 dark:text-red-300">Não foi possível carregar as solicitações agora. Atualize a página e tente novamente.</div>';
        creditsSection.innerHTML = errorHtml;
        plansSection.innerHTML = '';
    });
}

function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, char => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        "'": '&#39;',
        '"': '&quot;'
    }[char]));
}

function renderRequestsSection(sectionEl, title, items, kind) {
    const pending = items.filter(item => item.status === 'pending');
    if (!pending.length) {
        sectionEl.innerHTML = `<div class="rounded-[1.5rem] border border-dashed border-slate-200 dark:border-slate-700 p-6"><h4 class="font-black text-slate-800 dark:text-slate-100">${title}</h4><p class="text-sm text-slate-400 mt-1">Nenhuma solicitação pendente.</p></div>`;
        return;
    }
    const rows = pending.map(item => {
        const company = escapeHtml(item.tenantName || 'Empresa');
        const requester = escapeHtml(item.requestedByName || item.requestedByEmail || '—');
        const date = item.createdAt ? new Date(item.createdAt).toLocaleString('pt-BR') : '';
        const details = kind === 'credit'
            ? `${Number(item.tokensRequested || item.amount || 0).toLocaleString('pt-BR')} créditos`
            : `${escapeHtml(item.planName || 'Plano')} · ${Number(item.planTokenLimit || 0).toLocaleString('pt-BR')} créditos`;
        const approveLabel = kind === 'credit' ? 'Aprovar créditos' : 'Aprovar plano';
        return `<div class="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4"><div><h5 class="font-black text-slate-900 dark:text-slate-100">${company}</h5><p class="text-xs font-bold text-slate-500 mt-1">${requester} · ${details}</p><p class="text-[11px] text-slate-400 mt-1">${date}</p></div><div class="flex gap-2"><button class="request-approve bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-xl text-xs" data-id="${item.id}" data-kind="${kind}">${approveLabel}</button><button class="request-reject bg-red-50 hover:bg-red-100 text-red-700 font-bold px-4 py-2 rounded-xl text-xs" data-id="${item.id}" data-kind="${kind}">Recusar</button></div></div>`;
    }).join('');
    sectionEl.innerHTML = `<h4 class="font-black text-slate-900 dark:text-slate-100 mb-4">${title} <span class="text-sm text-amber-600">(${pending.length} pendente${pending.length > 1 ? 's' : ''})</span></h4><div class="space-y-3">${rows}</div>`;
    sectionEl.querySelectorAll('.request-approve, .request-reject').forEach(button => {
        button.onclick = () => {
            const status = button.classList.contains('request-approve') ? 'approved' : 'rejected';
            if (button.dataset.kind === 'credit') reviewCreditRequest(button.dataset.id, status);
            else reviewPlanRequest(button.dataset.id, status, document.getElementById('content-area'));
            setTimeout(loadRequestsTab, 600);
        };
    });
}

function renderSaasConfigTab(contentArea) {
    contentArea.innerHTML = `
        <div class="max-w-4xl mx-auto space-y-8 pb-20">
            <div>
                <h3 class="text-2xl font-black text-slate-900 dark:text-slate-100">Configurações do Sistema SaaS</h3>
                <p class="text-sm text-slate-500 dark:text-slate-400">Configure as chaves globais da plataforma, gateway de pagamento, WhatsApp e servidores de e-mail SMTP.</p>
            </div>

            <div id="saas-config-error" class="hidden p-4 bg-red-50 border border-red-200 rounded-2xl text-red-700 text-sm font-medium"></div>
            <div id="saas-config-success" class="hidden p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-700 text-sm font-medium"></div>

            <form id="saas-config-form" class="space-y-8">
                <!-- PAINEL 1: CONFIGURAÇÕES GERAIS -->
                <div class="bg-white dark:bg-slate-800 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm space-y-6">
                    <h4 class="text-lg font-black text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-700 pb-3 flex items-center gap-2">⚙️ Configurações Gerais</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Nome da Empresa SaaS</label>
                            <input id="saas-config-company" type="text" required class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-semibold" placeholder="Ex: Maps Prospector" />
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Valor do Crédito Avulso (R$)</label>
                            <input id="saas-config-avulso" type="text" required class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-semibold" placeholder="Ex: 2.00" />
                        </div>
                    </div>
                </div>

                <!-- PAINEL 2: GATEWAY DE PAGAMENTO (INFINITEPAY) -->
                <div class="bg-[#0F172A] p-8 rounded-[2rem] border border-slate-800 text-white space-y-6 relative overflow-hidden">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-emerald-600/10 rounded-full blur-3xl"></div>
                    <h4 class="text-lg font-black text-white border-b border-slate-800 pb-3 flex items-center gap-2">💳 Gateway de Pagamento (InfinitePay)</h4>
                    <p class="text-xs text-slate-400">Insira seu $handle da InfinitePay e a Chave de API para recebimento automático via PIX e Cartão.</p>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-[10px] font-black text-slate-300 uppercase mb-1">Usuário / $Handle da InfinitePay</label>
                            <input id="saas-config-infinite-handle" type="text" class="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3 outline-none focus:border-emerald-500 font-semibold text-white placeholder:text-slate-600" placeholder="Ex: seunome" />
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-slate-300 uppercase mb-1">Chave de API (InfinitePay Token)</label>
                            <input id="saas-config-infinite-key" type="password" class="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3 outline-none focus:border-emerald-500 font-semibold text-white placeholder:text-slate-600" placeholder="Insira o Token de API" />
                        </div>
                    </div>
                </div>

                <!-- PAINEL 3: INTEGRAÇÃO WHATSAPP (API ATENDO) -->
                <div class="bg-[#0F172A] p-8 rounded-[2rem] border border-slate-800 text-white space-y-6 relative overflow-hidden">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 rounded-full blur-3xl"></div>
                    <h4 class="text-lg font-black text-white border-b border-slate-800 pb-3 flex items-center gap-2">💬 Disparador de WhatsApp (API Atendo)</h4>
                    <p class="text-xs text-slate-400">Insira a URL e o Token JWT da sua API do Atendo.</p>
                    <div class="space-y-4">
                        <div>
                            <label class="block text-[10px] font-black text-slate-300 uppercase mb-1">URL da API do WhatsApp</label>
                            <input id="saas-config-wa-url" type="url" class="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-semibold text-white placeholder:text-slate-600" placeholder="https://off.atendo.log.br/v1/api/external/..." />
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-slate-300 uppercase mb-1">Token de Autenticação da API</label>
                            <input id="saas-config-wa-token" type="password" class="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-semibold text-white placeholder:text-slate-600" placeholder="Insira o Token JWT" />
                        </div>
                    </div>
                </div>

                <!-- PAINEL 4: SERVIDOR DE E-MAIL (SMTP AUTENTICADO) -->
                <div class="bg-white dark:bg-slate-800 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm space-y-6">
                    <h4 class="text-lg font-black text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-700 pb-3 flex items-center gap-2">✉️ Servidor de E-mail (SMTP)</h4>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Configure as credenciais SMTP do seu domínio para disparar e-mails de confirmação e alertas.</p>
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div class="md:col-span-2">
                            <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Servidor SMTP (Host)</label>
                            <input id="saas-config-smtp-host" type="text" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-semibold" placeholder="mail.atendo.log.br" />
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Porta SMTP</label>
                            <input id="saas-config-smtp-port" type="text" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-semibold" placeholder="587" />
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Usuário SMTP</label>
                            <input id="saas-config-smtp-user" type="text" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-semibold" placeholder="exemplo@atendo.log.br" />
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Senha SMTP</label>
                            <input id="saas-config-smtp-pass" type="password" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-semibold" placeholder="Senha do e-mail" />
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Criptografia</label>
                            <select id="saas-config-smtp-secure" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-semibold">
                                <option value="tls" selected>TLS (Recomendado)</option>
                                <option value="ssl">SSL</option>
                                <option value="none">Nenhuma</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">E-mail do Remetente</label>
                            <input id="saas-config-smtp-from-email" type="email" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-semibold" placeholder="noreply@atendo.log.br" />
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Nome do Remetente</label>
                            <input id="saas-config-smtp-from-name" type="text" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-semibold" placeholder="Maps Prospector" />
                        </div>
                    </div>
                </div>

                <button type="submit" id="saas-config-submit" class="w-full py-5 rounded-[1.5rem] bg-blue-600 text-white font-black hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 dark:shadow-blue-900/30">Salvar Todas as Configurações</button>
            </form>
        </div>
    `;
    loadSaasConfigForm();
    setupSaasConfigEvents();
}

function loadSaasConfigForm() {
    fetch(API_BASE + 'platform-config.php', { credentials: 'include' })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (!data.success || !data.data) return;
            var d = data.data;
            var companyEl = document.getElementById('saas-config-company');
            var avulsoEl = document.getElementById('saas-config-avulso');
            if (companyEl) companyEl.value = d.saasCompanyName || '';
            if (avulsoEl) avulsoEl.value = (d.creditPriceAvulso != null && d.creditPriceAvulso > 0) ? String(d.creditPriceAvulso) : '0';
            
            var infHandleEl = document.getElementById('saas-config-infinite-handle');
            var infKeyEl = document.getElementById('saas-config-infinite-key');
            if (infHandleEl) infHandleEl.value = d.infinitepayHandle || '';
            if (infKeyEl) infKeyEl.value = d.infinitepayApiKey || '';

            var waUrlEl = document.getElementById('saas-config-wa-url');
            var waTokenEl = document.getElementById('saas-config-wa-token');
            if (waUrlEl) waUrlEl.value = d.whatsappApiUrl || '';
            if (waTokenEl) waTokenEl.value = d.whatsappApiToken || '';

            var smtpHostEl = document.getElementById('saas-config-smtp-host');
            var smtpPortEl = document.getElementById('saas-config-smtp-port');
            var smtpUserEl = document.getElementById('saas-config-smtp-user');
            var smtpPassEl = document.getElementById('saas-config-smtp-pass');
            var smtpSecureEl = document.getElementById('saas-config-smtp-secure');
            var smtpFromEmailEl = document.getElementById('saas-config-smtp-from-email');
            var smtpFromNameEl = document.getElementById('saas-config-smtp-from-name');
            if (smtpHostEl) smtpHostEl.value = d.smtpHost || '';
            if (smtpPortEl) smtpPortEl.value = d.smtpPort || '587';
            if (smtpUserEl) smtpUserEl.value = d.smtpUser || '';
            if (smtpPassEl) smtpPassEl.value = d.smtpPass || '';
            if (smtpSecureEl) smtpSecureEl.value = d.smtpSecure || 'tls';
            if (smtpFromEmailEl) smtpFromEmailEl.value = d.smtpFromEmail || '';
            if (smtpFromNameEl) smtpFromNameEl.value = d.smtpFromName || '';
        })
        .catch(function() {});
}

function setupSaasConfigEvents() {
    var form = document.getElementById('saas-config-form');
    if (!form) return;
    form.onsubmit = function(e) {
        e.preventDefault();
        var companyEl = document.getElementById('saas-config-company');
        var avulsoEl = document.getElementById('saas-config-avulso');
        var avulso = avulsoEl && avulsoEl.value ? parseFloat(String(avulsoEl.value).replace(',', '.')) : 0;
        
        var infHandleEl = document.getElementById('saas-config-infinite-handle');
        var infKeyEl = document.getElementById('saas-config-infinite-key');
        var waUrlEl = document.getElementById('saas-config-wa-url');
        var waTokenEl = document.getElementById('saas-config-wa-token');

        var smtpHostEl = document.getElementById('saas-config-smtp-host');
        var smtpPortEl = document.getElementById('saas-config-smtp-port');
        var smtpUserEl = document.getElementById('saas-config-smtp-user');
        var smtpPassEl = document.getElementById('saas-config-smtp-pass');
        var smtpSecureEl = document.getElementById('saas-config-smtp-secure');
        var smtpFromEmailEl = document.getElementById('saas-config-smtp-from-email');
        var smtpFromNameEl = document.getElementById('saas-config-smtp-from-name');

        document.getElementById('saas-config-error').classList.add('hidden');
        document.getElementById('saas-config-success').classList.add('hidden');
        var btn = document.getElementById('saas-config-submit');
        if (btn) { btn.disabled = true; btn.textContent = 'Salvando...'; }
        
        fetch(API_BASE + 'platform-config.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
                saasCompanyName: companyEl ? companyEl.value.trim() : '',
                creditPriceAvulso: avulso,
                infinitepayHandle: infHandleEl ? infHandleEl.value.trim() : '',
                infinitepayApiKey: infKeyEl ? infKeyEl.value.trim() : '',
                whatsappApiUrl: waUrlEl ? waUrlEl.value.trim() : '',
                whatsappApiToken: waTokenEl ? waTokenEl.value.trim() : '',
                smtpHost: smtpHostEl ? smtpHostEl.value.trim() : '',
                smtpPort: smtpPortEl ? smtpPortEl.value.trim() : '587',
                smtpUser: smtpUserEl ? smtpUserEl.value.trim() : '',
                smtpPass: smtpPassEl ? smtpPassEl.value : '',
                smtpSecure: smtpSecureEl ? smtpSecureEl.value : 'tls',
                smtpFromEmail: smtpFromEmailEl ? smtpFromEmailEl.value.trim() : '',
                smtpFromName: smtpFromNameEl ? smtpFromNameEl.value.trim() : ''
            })
        }).then(function(r) { return r.json(); }).then(function(data) {
            if (data.success) {
                var successEl = document.getElementById('saas-config-success');
                if (successEl) { successEl.textContent = data.message || 'Configurações globais salvas!'; successEl.classList.remove('hidden'); }
                loadSidebarCompanyName();
            } else {
                var err = document.getElementById('saas-config-error');
                if (err) { err.textContent = data.error || 'Erro ao salvar.'; err.classList.remove('hidden'); }
            }
        }).catch(function() {
            var err = document.getElementById('saas-config-error');
            if (err) { err.textContent = 'Erro de conexão.'; err.classList.remove('hidden'); }
        }).finally(function() {
            if (btn) { btn.disabled = false; btn.textContent = 'Salvar Todas as Configurações'; }
        });
    };
}
function loadPlansTab(contentArea) {
    contentArea.innerHTML = '<div class="max-w-4xl mx-auto py-10">' +
        '<div id="plans-requests-section" class="mb-10 hidden"></div>' +
        '<div class="flex justify-between items-center mb-10 flex-wrap gap-4"><h3 class="text-2xl font-black text-slate-900 dark:text-slate-100">Planos e limite de tokens <span id="plans-total" class="text-slate-500 dark:text-slate-400 font-normal text-lg"></span></h3><div class="flex items-center gap-3"><button type="button" id="plans-refresh-btn" class="bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 font-bold px-4 py-3 rounded-2xl text-xs flex items-center gap-2">Atualizar lista</button><button type="button" id="plans-create-btn" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-3 rounded-2xl text-xs flex items-center gap-2">Criar plano</button><span class="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin inline-block" id="plans-spinner"></span></div></div>' +
        '<div id="plans-list"></div></div>';

    var refreshBtn = document.getElementById('plans-refresh-btn');
    if (refreshBtn) {
        refreshBtn.onclick = function() {
            fetchPlansList(); // 💡 Chama a função de busca sem reiniciar a aba
        };
    }
    var createBtn = document.getElementById('plans-create-btn');
    if (createBtn) {
        createBtn.onclick = function() {
            showPlansCreateModal(contentArea);
        };
    }

    fetchPlansList(); // 💡 Executa a busca uma única vez
}

function fetchPlansList() {
    var listEl = document.getElementById('plans-list');
    var spinnerEl = document.getElementById('plans-spinner');
    var requestsSection = document.getElementById('plans-requests-section');

    Promise.all([
        fetch(API_BASE + 'plan-requests.php', { credentials: 'include' }).then(function(r) { return r.json(); }),
        fetch(API_BASE + 'plans.php', { method: 'GET', credentials: 'include', cache: 'no-store' }).then(function(r) {
            if (spinnerEl) spinnerEl.remove();
            return r.json().catch(function() { return { success: false, error: 'Resposta inválida do servidor.' }; });
        })
    ]).then(function(results) {
        var requestsData = results[0];
        var data = results[1];
        var planRequests = (requestsData.success && requestsData.data && requestsData.data.items) ? requestsData.data.items : [];
        var pendingRequests = planRequests.filter(function(r) { return r.status === 'pending'; });

        if (requestsSection && pendingRequests.length > 0) {
            requestsSection.classList.remove('hidden');
            var rHtml = '<h4 class="text-lg font-black text-slate-900 dark:text-slate-100 mb-4">Solicitações de plano (pendentes)</h4><div class="space-y-4">';
            pendingRequests.forEach(function(r) {
                var dateStr = r.createdAt ? new Date(r.createdAt).toLocaleString('pt-BR') : '';
                var planInfo = (r.planName || '—') + ' (' + (r.planTokenLimit ? r.planTokenLimit.toLocaleString('pt-BR') : '') + ' tokens · R$ ' + (r.planPrice != null ? Number(r.planPrice).toFixed(2).replace('.', ',') : '0,00') + '/mês)';
                rHtml += '<div class="bg-white dark:bg-slate-800 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600 flex flex-wrap items-center justify-between gap-4">';
                rHtml += '<div class="flex items-center gap-6"><div class="w-12 h-12 bg-slate-100 dark:bg-slate-700 rounded-xl flex items-center justify-center text-xl font-black text-slate-600 dark:text-slate-400">' + (r.tenantName ? r.tenantName.charAt(0).toUpperCase() : 'E') + '</div>';
                rHtml += '<div><h4 class="font-extrabold text-slate-900 dark:text-slate-100 text-lg">' + (r.tenantName || 'Empresa') + '</h4><p class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">' + (r.requestedByName || r.requestedByEmail || '—') + ' · Plano: ' + planInfo + '</p><p class="text-xs text-amber-600 font-bold mt-1">' + dateStr + ' · Pendente</p></div></div>';
                rHtml += '<div class="flex items-center gap-2"><button type="button" class="btn-plan-request-approve bg-emerald-100 text-emerald-700 hover:bg-emerald-200 font-bold px-4 py-2 rounded-xl text-xs" data-id="' + r.id + '">Confirmar</button><button type="button" class="btn-plan-request-reject bg-red-100 text-red-700 hover:bg-red-200 font-bold px-4 py-2 rounded-xl text-xs" data-id="' + r.id + '">Recusar</button></div></div>';
            });
            rHtml += '</div>';
            requestsSection.innerHTML = rHtml;
        } else {
            if (requestsSection) requestsSection.classList.add('hidden');
        }

        if (!listEl) return;
        if (!data.success) {
            listEl.innerHTML = '<div class="py-8 p-5 bg-amber-50 border border-amber-200 rounded-2xl text-amber-800 text-sm font-medium">' + (data.error || 'Erro ao carregar planos.') + '</div>';
            return;
        }
        var items = (data.data && data.data.items) ? data.data.items : (Array.isArray(data.data) ? data.data : []);
        var total = (data.data && typeof data.data.total === 'number') ? data.data.total : items.length;
        var isSuperAdmin = AppState.user && String(AppState.user.profile).toLowerCase() === 'super_admin';

        if (!Array.isArray(items) || items.length === 0) {
            listEl.innerHTML = '<div class="py-24 text-center border-2 border-dashed border-slate-200 dark:border-slate-600 rounded-[2rem]"><p class="text-slate-400 font-bold uppercase text-[10px]">Nenhum plano cadastrado</p></div>';
            var totalEl = document.getElementById('plans-total');
            if (totalEl) totalEl.textContent = '0 plano(s)';
            return;
        }

        var html = '<div class="space-y-4">';
        items.forEach(function(p) {
            var tokenText = (p.tokenLimit === 0 || p.tokenLimit === '0') ? 'Ilimitado' : (p.tokenLimit + ' créditos');
            var priceMonthly = parseFloat(p.priceMonthly || 0);
            var priceText = priceMonthly > 0 ? (' · R$ ' + priceMonthly.toFixed(2).replace('.', ',') + '/mês') : ' · Grátis';
            var statusLabel = p.status === 'active' ? 'Ativo' : 'Inativo';
            var statusClass = p.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-400';
            var planId = String(p.id);
            var planName = (p.name || '').replace(/"/g, '&quot;');

            html += '<div class="bg-white dark:bg-slate-800 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600 flex items-center justify-between flex-wrap gap-4">';
            html += '<div class="flex items-center gap-6">';
            html += '<div class="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-lg font-black text-blue-600">' + ((p.tokenLimit === 0 || p.tokenLimit === '0') ? '∞' : p.tokenLimit) + '</div>';
            html += '<div><h4 class="font-extrabold text-slate-900 dark:text-slate-100 text-lg">' + (p.name || '') + '</h4>';
            html += '<p class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">' + (p.slug || '') + ' · ' + tokenText + priceText + ' · <span class="' + statusClass + ' px-2 py-0.5 rounded-full text-xs font-bold">' + statusLabel + '</span></p></div></div>';
            
            html += '<div class="flex items-center gap-2">';
            if (!isSuperAdmin && priceMonthly > 0) {
                html += '<button type="button" class="btn-request-plan bg-blue-600 hover:bg-blue-700 text-white font-bold px-5 py-2 rounded-xl text-xs" data-plan-id="' + planId + '" data-price="' + priceMonthly + '">Solicitar plano</button>';
            }
            if (isSuperAdmin) {
                html += '<button type="button" class="btn-plan-edit bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold px-4 py-2 rounded-xl text-xs" data-id="' + planId + '">Editar</button>';
                if (planId !== '1') {
                    html += '<button type="button" class="btn-plan-delete text-red-500 hover:bg-red-50 font-bold px-4 py-2 rounded-xl text-xs" data-id="' + planId + '" data-name="' + planName + '">Excluir</button>';
                }
            }
            html += '</div></div>';
        });
        html += '</div>';
        listEl.innerHTML = html;

        listEl.querySelectorAll('.btn-request-plan').forEach(function(btn) {
            btn.onclick = async function() {
                var planId = btn.getAttribute('data-plan-id');
                btn.disabled = true;
                btn.textContent = 'Enviando solicitação...';

                try {
                    const res = await fetch(API_BASE + 'create-payment.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        credentials: 'include',
                        body: JSON.stringify({
                            type: 'plan',
                            amount: 0,
                            planId: parseInt(planId, 10)
                        })
                    });
                    const data = await res.json().catch(function() { return null; });
                    if (data && data.success) {
                        btn.textContent = 'Solicitação enviada';
                        btn.classList.remove('bg-blue-600', 'hover:bg-blue-700');
                        btn.classList.add('bg-emerald-600', 'cursor-default');
                    } else {
                        alert((data && data.error) || 'Erro ao enviar a solicitação de plano.');
                    }
                } catch (e) {
                    alert('Erro de conexão ao enviar a solicitação de plano.');
                } finally {
                    btn.disabled = false;
                    btn.textContent = 'Solicitar plano';
                }
            };
        });

        var totalEl = document.getElementById('plans-total');
        if (totalEl) totalEl.textContent = total + ' plano(s)';
    }).catch(function() {
        if (spinnerEl) spinnerEl.remove();
        if (listEl) listEl.innerHTML = '<div class="py-8 p-5 bg-red-50 border border-red-200 rounded-2xl text-red-700 text-sm font-medium">Erro ao carregar planos.</div>';
    });
}

function reviewPlanRequest(id, status, contentArea) {
    fetch(API_BASE + 'plan-requests.php', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ id: parseInt(id, 10), status: status })
    }).then(function(r) { return r.json(); }).then(function(data) {
        if (data.success) {
            loadPlansTab(contentArea);
        }
    });
}
function showPlansDeleteModal(contentArea, planId, planName) {
    var overlay = document.createElement('div');
    overlay.id = 'plans-delete-overlay';
    overlay.className = 'fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4';
    var safeName = (planName || 'este plano').replace(/"/g, '&quot;');
    overlay.innerHTML = '<div class="bg-white dark:bg-slate-800 rounded-[2rem] shadow-2xl p-8 max-w-md w-full" onclick="event.stopPropagation()">' +
        '<h4 class="text-xl font-black text-slate-900 dark:text-slate-100 mb-2">Excluir plano</h4>' +
        '<p class="text-slate-600 dark:text-slate-400 text-sm mb-6">Excluir o plano <strong>"' + safeName + '"</strong>? Nenhuma empresa pode estar vinculada a ele.</p>' +
        '<p id="plans-delete-error" class="text-red-600 text-sm font-medium mb-4 hidden"></p>' +
        '<div class="flex gap-3">' +
        '<button type="button" id="plans-delete-cancel" class="flex-1 py-3 rounded-xl border border-slate-200 dark:border-slate-600 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700">Cancelar</button>' +
        '<button type="button" id="plans-delete-confirm" class="flex-1 py-3 rounded-xl bg-red-600 text-white font-bold hover:bg-red-700 disabled:opacity-70">Excluir</button>' +
        '</div></div>';
    overlay.onclick = function(e) {
        if (e.target === overlay) overlay.remove();
    };
    document.body.appendChild(overlay);
    var cancelBtn = document.getElementById('plans-delete-cancel');
    var confirmBtn = document.getElementById('plans-delete-confirm');
    var errorEl = document.getElementById('plans-delete-error');
    cancelBtn.onclick = function() { overlay.remove(); };
    confirmBtn.onclick = function() {
        errorEl.classList.add('hidden');
        confirmBtn.disabled = true;
        confirmBtn.textContent = 'Excluindo...';
        fetch(API_BASE + 'plans.php?id=' + encodeURIComponent(planId), { method: 'DELETE', credentials: 'include' })
            .then(function(r) { return r.json(); })
            .then(function(res) {
                if (res.success) {
                    overlay.remove();
                    if (contentArea) loadPlansTab(contentArea);
                    if (document.getElementById('toast') && document.getElementById('toast-message')) {
                        document.getElementById('toast-message').textContent = res.message || 'Plano removido com sucesso.';
                        document.getElementById('toast').classList.remove('hidden');
                        setTimeout(function() { document.getElementById('toast').classList.add('hidden'); }, 3000);
                    }
                } else {
                    errorEl.textContent = res.error || 'Erro ao excluir.';
                    errorEl.classList.remove('hidden');
                    confirmBtn.disabled = false;
                    confirmBtn.textContent = 'Excluir';
                }
            })
            .catch(function() {
                errorEl.textContent = 'Erro de conexão.';
                errorEl.classList.remove('hidden');
                confirmBtn.disabled = false;
                confirmBtn.textContent = 'Excluir';
            });
    };
}

function showPlansCreateModal(contentArea) {
    var overlay = document.createElement('div');
    overlay.id = 'plans-create-overlay';
    overlay.className = 'fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4';
    overlay.innerHTML = '<div class="bg-white dark:bg-slate-800 rounded-[2rem] shadow-2xl p-8 max-w-md w-full" onclick="event.stopPropagation()">' +
        '<h4 class="text-xl font-black text-slate-900 dark:text-slate-100 mb-6">Criar plano</h4>' +
        '<form id="plans-create-form" class="space-y-4">' +
        '<div><label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Nome</label>' +
        '<input type="text" id="plan-name" required placeholder="Ex: Básico, Pro" class="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium placeholder-slate-400 dark:placeholder-slate-500" /></div>' +
        '<div><label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Quantos tokens</label>' +
        '<input type="number" id="plan-tokens" min="0" value="100" placeholder="100" class="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium placeholder-slate-400 dark:placeholder-slate-500" />' +
        '<p class="text-[10px] text-slate-400 mt-1">0 = ilimitado. 1 token = 1 página de resultados (até 50 itens por página).</p></div>' +
        '<div><label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Valor mensal (R$)</label>' +
        '<input type="number" id="plan-price" min="0" step="0.01" value="0" placeholder="0,00" class="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium placeholder-slate-400 dark:placeholder-slate-500" /></div>' +
        '<p id="plans-create-error" class="text-red-600 text-sm font-medium hidden"></p>' +
        '<div class="flex gap-3 pt-4">' +
        '<button type="button" id="plans-create-cancel" class="flex-1 py-3 rounded-xl border border-slate-200 dark:border-slate-600 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700">Cancelar</button>' +
        '<button type="submit" id="plans-create-submit" class="flex-1 py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700">Criar plano</button>' +
        '</div></form></div>';
    overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };
    document.body.appendChild(overlay);
    var form = document.getElementById('plans-create-form');
    var cancelBtn = document.getElementById('plans-create-cancel');
    var errorEl = document.getElementById('plans-create-error');
    cancelBtn.onclick = function() { overlay.remove(); };
    form.onsubmit = function(e) {
        e.preventDefault();
        var name = (document.getElementById('plan-name').value || '').trim();
        var tokenLimit = parseInt(document.getElementById('plan-tokens').value, 10) || 0;
        if (tokenLimit < 0) tokenLimit = 0;
        var priceMonthly = parseFloat((document.getElementById('plan-price').value || '0').toString().replace(',', '.')) || 0;
        if (!name) { errorEl.textContent = 'Nome é obrigatório.'; errorEl.classList.remove('hidden'); return; }
        var slug = name.toLowerCase().normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'plano';
        errorEl.classList.add('hidden');
        var submitBtn = document.getElementById('plans-create-submit');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Salvando...';
        fetch(API_BASE + 'plans.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ name: name, slug: slug, tokenLimit: tokenLimit, priceMonthly: priceMonthly, period: 'monthly', status: 'active' })
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.success) {
                overlay.remove();
                if (contentArea) loadPlansTab(contentArea);
                if (document.getElementById('toast') && document.getElementById('toast-message')) {
                    document.getElementById('toast-message').textContent = 'Plano criado com sucesso.';
                    document.getElementById('toast').classList.remove('hidden');
                    setTimeout(function() { document.getElementById('toast').classList.add('hidden'); }, 3000);
                }
            } else {
                errorEl.textContent = data.error || 'Erro ao criar plano.';
                errorEl.classList.remove('hidden');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Criar plano';
            }
        })
        .catch(function() {
            errorEl.textContent = 'Erro de conexão.';
            errorEl.classList.remove('hidden');
            submitBtn.disabled = false;
            submitBtn.textContent = 'Criar plano';
        });
    };
}
function showPlansEditModal(contentArea, planId) {
    Promise.all([
        fetch(API_BASE + 'plans.php?id=' + encodeURIComponent(planId), { credentials: 'include' }).then(function(r) { return r.json(); }),
        fetch(API_BASE + 'plans.php', { method: 'GET', credentials: 'include', cache: 'no-store' }).then(function(r) { return r.json(); })
    ])
    .then(function(results) {
        var data = results[0];
        var plansData = results[1];
        if (!data.success || !data.data) {
            alert(data.error || 'Plano não encontrado.');
            return;
        }
        var p = data.data;
        var plans = (plansData.success && plansData.data && plansData.data.items) ? plansData.data.items : [];
        
        var optionsHtml = plans.map(function(item) {
            return '<option value="' + item.id + '"' + (String(item.id) === String(planId) ? ' selected' : '') + '>' + item.name + '</option>';
        }).join('');

        var overlay = document.createElement('div');
        overlay.id = 'plans-edit-overlay';
        overlay.className = 'fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4';
        overlay.innerHTML = '<div class="bg-white dark:bg-slate-800 rounded-[2rem] shadow-2xl p-8 max-w-md w-full" onclick="event.stopPropagation()">' +
            '<h4 class="text-xl font-black text-slate-900 dark:text-slate-100 mb-6">Editar plano</h4>' +
            '<form id="plans-edit-form" class="space-y-4">' +
            '<div><label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Nome</label>' +
            '<input type="text" id="plan-edit-name" required class="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium" value="' + (p.name || '').replace(/"/g, '&quot;') + '" /></div>' +
            '<div><label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Identificador (slug)</label>' +
            '<input type="text" id="plan-edit-slug" class="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium" value="' + (p.slug || '').replace(/"/g, '&quot;') + '" /></div>' +
            '<div><label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Limite de tokens</label>' +
            '<input type="number" id="plan-edit-tokens" min="0" class="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium" value="' + (p.tokenLimit != null ? p.tokenLimit : 100) + '" /></div>' +
            '<div><label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Valor mensal (R$)</label>' +
            '<input type="number" id="plan-edit-price" min="0" step="0.01" class="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium" value="' + (p.priceMonthly != null ? p.priceMonthly : 0) + '" /></div>' +
            '<div><label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Período</label>' +
            '<select id="plan-edit-period" class="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium">' +
            '<option value="monthly"' + (p.period === 'yearly' ? '' : ' selected') + '>Mensal</option><option value="yearly"' + (p.period === 'yearly' ? ' selected' : '') + '>Anual</option></select></div>' +
            '<div><label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Status</label>' +
            '<select id="plan-edit-status" class="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-semibold">' +
            '<option value="active"' + (p.status === 'inactive' ? '' : ' selected') + '>Ativo</option><option value="inactive"' + (p.status === 'inactive' ? ' selected' : '') + '>Inativo</option></select></div>' +
            '<p id="plans-edit-error" class="text-red-600 text-sm font-medium hidden"></p>' +
            '<div class="flex gap-3 pt-4">' +
            '<button type="button" id="plans-edit-cancel" class="flex-1 py-3 rounded-xl border border-slate-200 dark:border-slate-600 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700">Cancelar</button>' +
            '<button type="submit" id="plans-edit-submit" class="flex-1 py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700">Salvar</button>' +
            '</div></form></div>';
            
        overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };
        document.body.appendChild(overlay);
        var form = document.getElementById('plans-edit-form');
        var cancelBtn = document.getElementById('plans-edit-cancel');
        var errorEl = document.getElementById('plans-edit-error');
        cancelBtn.onclick = function() { overlay.remove(); };
        form.onsubmit = function(e) {
            e.preventDefault();
            var name = (document.getElementById('plan-edit-name').value || '').trim();
            var slug = (document.getElementById('plan-edit-slug').value || '').trim();
            var tokenLimit = parseInt(document.getElementById('plan-edit-tokens').value, 10) || 0;
            var priceMonthly = parseFloat((document.getElementById('plan-edit-price').value || '0').toString().replace(',', '.')) || 0;
            var period = document.getElementById('plan-edit-period').value || 'monthly';
            var status = document.getElementById('plan-edit-status').value || 'active';
            if (!name) { errorEl.textContent = 'Nome é obrigatório.'; errorEl.classList.remove('hidden'); return; }
            if (!slug) slug = name.toLowerCase().normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'plano';
            errorEl.classList.add('hidden');
            var submitBtn = document.getElementById('plans-edit-submit');
            submitBtn.disabled = true;
            submitBtn.textContent = 'Salvando...';
            fetch(API_BASE + 'plans.php', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ id: planId, name: name, slug: slug, tokenLimit: tokenLimit, priceMonthly: priceMonthly, period: period, status: status })
            })
            .then(function(r) { return r.json(); })
            .then(function(res) {
                if (res.success) {
                    overlay.remove();
                    if (contentArea) loadPlansTab(contentArea);
                    if (document.getElementById('toast') && document.getElementById('toast-message')) {
                        document.getElementById('toast-message').textContent = 'Plano atualizado com sucesso.';
                        document.getElementById('toast').classList.remove('hidden');
                        setTimeout(function() { document.getElementById('toast').classList.add('hidden'); }, 3000);
                    }
                } else {
                    errorEl.textContent = res.error || 'Erro ao atualizar.';
                    errorEl.classList.remove('hidden');
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Salvar';
                }
            })
            .catch(function() {
                errorEl.textContent = 'Erro de conexão.';
                errorEl.classList.remove('hidden');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Salvar';
            });
        };
    })
    .catch(function() { alert('Erro ao carregar plano.'); });
}
function showAddCompanyModal() {
    fetch(API_BASE + 'plans.php', { method: 'GET', credentials: 'include', cache: 'no-store' })
        .then(function(r) { return r.json().catch(function() { return { success: false, data: { items: [] } }; }); })
        .then(function(data) {
            var plans = (data.success && data.data && data.data.items) ? data.data.items : (Array.isArray(data.data) ? data.data : []);
            var activePlans = plans.filter(function(p) { return p.status === 'active'; });
            var optionsHtml = activePlans.map(function(p) {
                var label = p.name + (p.tokenLimit === 0 ? ' (ilimitado)' : ' (' + p.tokenLimit + ' tokens)');
                return '<option value="' + p.id + '">' + label + '</option>';
            }).join('');
            if (!optionsHtml) optionsHtml = '<option value="1">Básico (100 tokens)</option>';
            
            var overlay = document.createElement('div');
            overlay.id = 'add-company-overlay';
            overlay.className = 'fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4 overflow-y-auto';
            overlay.innerHTML = '<div class="bg-white dark:bg-slate-800 rounded-[2rem] shadow-2xl p-8 max-w-md w-full my-8" onclick="event.stopPropagation()">' +
                '<h4 class="text-xl font-black text-slate-900 dark:text-slate-100 mb-6">Nova Empresa</h4>' +
                '<form id="add-company-form" class="space-y-4">' +
                '<div>' +
                '<label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Nome da Empresa</label>' +
                '<input type="text" id="add-company-name" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-bold" placeholder="Ex: Minha Empresa Ltda" required>' +
                '</div>' +
                '<div>' +
                '<label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Identificador (slug)</label>' +
                '<input type="text" id="add-company-slug" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-bold" placeholder="Ex: minha-empresa">' +
                '<p class="text-[10px] text-slate-400 mt-1">Se vazio, gera automático.</p>' +
                '</div>' +
                '<div>' +
                '<label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Plano</label>' +
                '<select id="add-company-plan" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-bold">' + optionsHtml + '</select>' +
                '</div>' +
                '<hr class="border-slate-200 dark:border-slate-600 my-4">' +
                '<p class="text-sm font-bold text-slate-700 dark:text-slate-300 mb-3">Dados do Administrador</p>' +
                '<div>' +
                '<label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Nome do Administrador</label>' +
                '<input type="text" id="add-company-admin-name" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-bold" placeholder="Ex: João Silva">' +
                '</div>' +
                '<div>' +
                '<label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">E-mail do Administrador</label>' +
                '<input type="email" id="add-company-admin-email" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-bold" required>' +
                '</div>' +
                '<div>' +
                '<label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Senha</label>' +
                '<input type="password" id="add-company-admin-password" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-bold" required minlength="6">' +
                '</div>' +
                '<p id="add-company-error" class="text-red-600 text-sm font-medium hidden"></p>' +
                '<div class="flex gap-3 pt-4">' +
                '<button type="button" id="add-company-cancel" class="flex-1 py-3 rounded-xl border border-slate-200 dark:border-slate-600 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700">Cancelar</button>' +
                '<button type="submit" id="add-company-submit" class="flex-1 py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700">Criar Empresa</button>' +
                '</div></form></div>';
            overlay.onclick = function(ev) { if (ev.target === overlay) overlay.remove(); };
            document.body.appendChild(overlay);
            
            var form = document.getElementById('add-company-form');
            var cancelBtn = document.getElementById('add-company-cancel');
            var errorEl = document.getElementById('add-company-error');
            var submitBtn = document.getElementById('add-company-submit');
            var nameInput = document.getElementById('add-company-name');
            var slugInput = document.getElementById('add-company-slug');
            var adminNameInput = document.getElementById('add-company-admin-name');
            var adminEmailInput = document.getElementById('add-company-admin-email');
            var adminPasswordInput = document.getElementById('add-company-admin-password');

            if (nameInput && slugInput) {
                nameInput.addEventListener('input', function() {
                    var name = nameInput.value.trim();
                    if (!slugInput.value.trim()) {
                        var slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
                        slugInput.value = slug;
                    }
                    if (!adminNameInput.value.trim()) adminNameInput.value = name;
                });
            }
            form.onsubmit = function(e) {
                e.preventDefault();
                var name = nameInput.value.trim();
                var slug = slugInput.value.trim();
                var planId = document.getElementById('add-company-plan').value;
                var adminName = adminNameInput.value.trim();
                var adminEmail = adminEmailInput.value.trim();
                var adminPassword = adminPasswordInput.value;
                if (!name || !adminEmail || !adminPassword || adminPassword.length < 6) {
                    errorEl.textContent = 'Preencha os campos obrigatórios corretamente.';
                    errorEl.classList.remove('hidden');
                    return;
                }
                errorEl.classList.add('hidden');
                submitBtn.disabled = true;
                submitBtn.textContent = 'Criando...';
                fetch(API_BASE + 'tenants.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'same-origin',
                    body: JSON.stringify({ name: name, slug: slug, planId: parseInt(planId, 10), status: 'active', adminName: adminName, adminEmail: adminEmail, adminPassword: adminPassword })
                })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    if (res.success) {
                        overlay.remove();
                        showToast('Empresa criada com sucesso!');
                        loadCompaniesTab(document.getElementById('content-area'));
                    } else {
                        errorEl.textContent = res.error || 'Erro ao criar empresa.';
                        errorEl.classList.remove('hidden');
                        submitBtn.disabled = false;
                        submitBtn.textContent = 'Criar Empresa';
                    }
                });
            };
            cancelBtn.onclick = function() { overlay.remove(); };
        });
}

function loadCompaniesTab(contentArea) {
    contentArea.innerHTML = '<div class="max-w-4xl mx-auto py-10"><div class="flex justify-between items-center mb-10 flex-wrap gap-4"><h3 class="text-2xl font-black text-slate-900 dark:text-slate-100">Empresas cadastradas <span id="companies-total" class="text-slate-500 dark:text-slate-400 font-normal text-lg"></span></h3><div class="flex items-center gap-3"><button type="button" id="btn-add-company" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-5 py-3 rounded-2xl text-xs flex items-center gap-2"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-width="2.5" d="M12 4v16m8-8H4" /></svg>Nova Empresa</button><button type="button" id="companies-refresh-btn" class="bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 font-bold px-4 py-3 rounded-2xl text-xs flex items-center gap-2">Atualizar</button><span class="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin inline-block" id="companies-spinner"></span></div></div><div id="companies-list"></div></div>';

    var refreshBtn = document.getElementById('companies-refresh-btn');
    var addBtn = document.getElementById('btn-add-company');
    if (refreshBtn) refreshBtn.onclick = function() { fetchCompaniesList(); };
    if (addBtn) addBtn.onclick = function() { showAddCompanyModal(); };

    fetchCompaniesList();
}

function fetchCompaniesList() {
    var listEl = document.getElementById('companies-list');
    var spinnerEl = document.getElementById('companies-spinner');

    var apiUrl = API_BASE + 'tenants.php';
    var plansUrl = API_BASE + 'plans.php';

    Promise.all([
        fetch(apiUrl, { method: 'GET', credentials: 'include', cache: 'no-store' }).then(function(r) { return r.json().catch(function() { return { success: false, error: 'Resposta inválida do servidor.' }; }); }),
        fetch(plansUrl, { method: 'GET', credentials: 'include', cache: 'no-store' }).then(function(r) { return r.json().catch(function() { return { success: false, data: { items: [] } }; }); })
    ]).then(function(results) {
        var data = results[0];
        var plansData = results[1];
        if (spinnerEl) spinnerEl.remove();
        if (!listEl) return;
        if (!data.success) {
            listEl.innerHTML = '<div class="py-8 p-5 bg-amber-50 border border-amber-200 rounded-2xl text-amber-800 text-sm font-medium">' + (data.error || 'Erro ao carregar empresas.') + '</div>';
            return;
        }
        var items = (data.data && data.data.items) ? data.data.items : (Array.isArray(data.data) ? data.data : []);
        var total = (data.data && typeof data.data.total === 'number') ? data.data.total : items.length;
        var plans = (plansData.success && plansData.data && plansData.data.items) ? plansData.data.items : (Array.isArray(plansData.data) ? plansData.data : []);
        var activePlans = plans.filter(function(p) { return p.status === 'active'; });

        if (!Array.isArray(items) || items.length === 0) {
            listEl.innerHTML = '<div class="py-24 text-center border-2 border-dashed border-slate-200 dark:border-slate-600 rounded-[2rem]"><p class="text-slate-400 font-bold uppercase text-[10px]">Nenhuma empresa cadastrada</p></div>';
            return;
        }

        var html = '<div class="space-y-4">';
        items.forEach(function(t) {
            var statusLabel = t.status === 'active' ? 'Ativa' : 'Suspensa';
            var statusClass = t.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700';
            var toggleLabel = t.status === 'active' ? 'Desativar' : 'Ativar';
            var planInfo = (t.plan || '') + (t.planTokenLimit != null ? (t.planTokenLimit === 0 ? ' (ilimitado)' : ' (' + t.planTokenLimit + ' tokens)') : '');
            var tokensUsed = t.tokensUsed != null ? t.tokensUsed : 0;
            var tokensLimit = t.tokensLimit != null ? t.tokensLimit : 0;
            var tokensInfo = tokensLimit > 0 ? ' · Tokens: ' + tokensUsed + '/' + tokensLimit : ' · Tokens: ' + tokensUsed + ' (ilimitado)';

            html += '<div class="bg-white dark:bg-slate-800 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600 flex items-center justify-between flex-wrap gap-4">';
            html += '<div class="flex items-center gap-6">';
            // AQUI ESTAVA O ERRO - AGORA CORRIGIDO PARA justify-center:
            html += '<div class="w-12 h-12 bg-slate-100 dark:bg-slate-700 rounded-xl flex items-center justify-center text-xl font-black text-slate-600 dark:text-slate-400">' + (t.name ? t.name.charAt(0).toUpperCase() : '') + '</div>';
            html += '<div><h4 class="font-extrabold text-slate-900 dark:text-slate-100 text-lg">' + (t.name || '') + '</h4>';
            html += '<p class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">' + (t.slug || '') + (t.email ? ' · ' + (t.email) : '') + ' · Plano: ' + planInfo + tokensInfo + ' · ' + (t.usersCount || 0) + ' usuário(s) · <span class="' + statusClass + ' px-2 py-0.5 rounded-full text-xs font-bold">' + statusLabel + '</span></p></div></div>';
            html += '<div class="flex items-center gap-2">';
            html += '<button type="button" class="btn-access-tenant px-4 py-2 rounded-xl text-xs font-bold bg-emerald-100 text-emerald-700 hover:bg-emerald-200" data-id="' + t.id + '" data-name="' + (t.name || '').replace(/"/g, '&quot;') + '">Acessar</button>';
            html += '<button type="button" class="btn-edit-tenant px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200" data-id="' + t.id + '" data-name="' + (t.name || '').replace(/"/g, '&quot;') + '" data-email="' + (t.email || '').replace(/"/g, '&quot;') + '">Editar</button>';
            html += '<button type="button" class="btn-toggle-tenant px-4 py-2 rounded-xl text-xs font-bold ' + (t.status === 'active' ? 'bg-amber-100 text-amber-700 hover:bg-amber-200' : 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200') + '" data-id="' + t.id + '" data-name="' + (t.name || '').replace(/"/g, '&quot;') + '" data-status="' + (t.status === 'active' ? 'suspended' : 'active') + '">' + toggleLabel + '</button>';
            html += '<button type="button" class="btn-link-plan px-4 py-2 rounded-xl text-xs font-bold bg-blue-100 text-blue-700 hover:bg-blue-200" data-id="' + t.id + '" data-name="' + (t.name || '').replace(/"/g, '&quot;') + '" data-plan-id="' + (t.planId || '1') + '">Vincular plano</button>';
            if (t.status === 'suspended') {
                html += '<button type="button" class="btn-delete-tenant px-4 py-2 rounded-xl text-xs font-bold bg-red-100 text-red-700 hover:bg-red-200" data-id="' + t.id + '" data-name="' + (t.name || '').replace(/"/g, '&quot;') + '">Excluir</button>';
            }
            html += '</div></div>';
        });
        html += '</div>';
        listEl.innerHTML = html;

        var totalEl = document.getElementById('companies-total');
        if (totalEl) totalEl.textContent = total + ' empresa(s)';

        listEl.querySelectorAll('.btn-access-tenant').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var tenantId = btn.dataset.id;
                if (!tenantId) return;
                btn.disabled = true;
                fetch(API_BASE + 'auth.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({ action: 'impersonate', tenantId: tenantId })
                })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    if (res.success) {
                        AppState.user = res.data.user;
                        AppState.tenant = res.data.tenant || null;
                        AppState.tokenUsage = res.data.tokenUsage || null;
                        AppState.impersonating = !!(res.data.impersonating);
                        AppState.impersonatingTenantName = res.data.impersonatingTenantName || '';
                        AppState.activeTab = 'dashboard';
                        showDashboard();
                        loadConfig();
                    } else {
                        alert(res.error || 'Erro ao acessar empresa.');
                    }
                })
                .catch(function() { alert('Erro de conexão.'); })
                .finally(function() { btn.disabled = false; });
            });
        });

        listEl.querySelectorAll('.btn-toggle-tenant').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var id = btn.dataset.id;
                var name = btn.dataset.name;
                var newStatus = btn.dataset.status;
                var action = newStatus === 'active' ? 'ativar' : 'desativar';
                if (!confirm('Deseja ' + action + ' a empresa "' + name + '"?')) return;
                btn.disabled = true;
                fetch(API_BASE + 'tenants.php', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'same-origin',
                    body: JSON.stringify({ id: id, status: newStatus })
                })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    if (res.success) { fetchCompaniesList(); }
                    else { alert(res.error || 'Erro ao atualizar.'); }
                })
                .catch(function() { alert('Erro de conexão.'); })
                .finally(function() { btn.disabled = false; });
            });
        });

        listEl.querySelectorAll('.btn-link-plan').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var tenantId = btn.dataset.id;
                var tenantName = btn.dataset.name;
                var currentPlanId = btn.dataset.planId || '1';
                var optionsHtml = activePlans.map(function(p) {
                    var label = p.name + (p.tokenLimit === 0 ? ' (ilimitado)' : ' (' + p.tokenLimit + ' tokens)');
                    return '<option value="' + p.id + '"' + (String(p.id) === String(currentPlanId) ? ' selected' : '') + '>' + label + '</option>';
                }).join('');
                if (!optionsHtml) optionsHtml = '<option value="1">Básico</option>';
                var overlay = document.getElementById('companies-link-plan-overlay');
                if (overlay) overlay.remove();
                overlay = document.createElement('div');
                overlay.id = 'companies-link-plan-overlay';
                overlay.className = 'fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4';
                overlay.innerHTML = '<div class="bg-white dark:bg-slate-800 rounded-[2rem] shadow-2xl p-8 max-w-md w-full" onclick="event.stopPropagation()">' +
                    '<h4 class="text-xl font-black text-slate-900 dark:text-slate-100 mb-2">Vincular empresa ao plano</h4>' +
                    '<p class="text-sm text-slate-500 dark:text-slate-400 mb-4">' + (tenantName ? 'Empresa: ' + tenantName : '') + '</p>' +
                    '<form id="companies-link-plan-form" class="space-y-4">' +
                    '<label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Plano</label>' +
                    '<select id="companies-link-plan-select" class="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium">' + optionsHtml + '</select>' +
                    '<p id="companies-link-plan-error" class="text-red-600 text-sm font-medium hidden"></p>' +
                    '<div class="flex gap-3 pt-4">' +
                    '<button type="button" id="companies-link-plan-cancel" class="flex-1 py-3 rounded-xl border border-slate-200 dark:border-slate-600 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700">Cancelar</button>' +
                    '<button type="submit" id="companies-link-plan-submit" class="flex-1 py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700">Vincular</button>' +
                    '</div></form></div>';
                overlay.onclick = function(ev) { if (ev.target === overlay) overlay.remove(); };
                document.body.appendChild(overlay);
                var form = document.getElementById('companies-link-plan-form');
                form.onsubmit = function(e) {
                    e.preventDefault();
                    var planId = document.getElementById('companies-link-plan-select').value;
                    var submitBtn = document.getElementById('companies-link-plan-submit');
                    submitBtn.disabled = true;
                    fetch(API_BASE + 'tenants.php', {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        credentials: 'same-origin',
                        body: JSON.stringify({ id: tenantId, planId: parseInt(planId, 10) })
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(res) {
                        if (res.success) { overlay.remove(); fetchCompaniesList(); }
                        else { document.getElementById('companies-link-plan-error').textContent = res.error || 'Erro.'; document.getElementById('companies-link-plan-error').classList.remove('hidden'); submitBtn.disabled = false; }
                    });
                };
                document.getElementById('companies-link-plan-cancel').onclick = function() { overlay.remove(); };
            });
        });

        listEl.querySelectorAll('.btn-edit-tenant').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var tenantId = btn.dataset.id;
                var tenantName = btn.dataset.name || '';
                var tenantEmail = btn.dataset.email || '';
                var overlay = document.getElementById('companies-edit-tenant-overlay');
                if (overlay) overlay.remove();
                overlay = document.createElement('div');
                overlay.id = 'companies-edit-tenant-overlay';
                overlay.className = 'fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4';
                overlay.innerHTML = '<div class="bg-white dark:bg-slate-800 rounded-[2rem] shadow-2xl p-8 max-w-md w-full" onclick="event.stopPropagation()">' +
                    '<h4 class="text-xl font-black text-slate-900 dark:text-slate-100 mb-2">Editar empresa</h4>' +
                    '<form id="companies-edit-tenant-form" class="space-y-4">' +
                    '<div><label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Nome</label>' +
                    '<input type="text" id="companies-edit-tenant-name" value="' + tenantName.replace(/"/g, '&quot;') + '" class="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium" placeholder="Nome da empresa"></div>' +
                    '<div><label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">E-mail</label>' +
                    '<input type="email" id="companies-edit-tenant-email" value="' + tenantEmail.replace(/"/g, '&quot;') + '" class="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium" placeholder="admin@empresa.com"></div>' +
                    '<p id="companies-edit-tenant-error" class="text-red-600 text-sm font-medium hidden"></p>' +
                    '<div class="flex gap-3 pt-4">' +
                    '<button type="button" id="companies-edit-tenant-cancel" class="flex-1 py-3 rounded-xl border border-slate-200 dark:border-slate-600 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700">Cancelar</button>' +
                    '<button type="submit" id="companies-edit-tenant-submit" class="flex-1 py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700">Salvar</button>' +
                    '</div></form></div>';
                overlay.onclick = function(ev) { if (ev.target === overlay) overlay.remove(); };
                document.body.appendChild(overlay);
                var form = document.getElementById('companies-edit-tenant-form');
                form.onsubmit = function(e) {
                    e.preventDefault();
                    var name = document.getElementById('companies-edit-tenant-name').value.trim();
                    var email = document.getElementById('companies-edit-tenant-email').value.trim().toLowerCase();
                    if (!name) return;
                    fetch(API_BASE + 'tenants.php', {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        credentials: 'same-origin',
                        body: JSON.stringify({ id: tenantId, name: name, email: email })
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(res) {
                        if (res.success) { overlay.remove(); fetchCompaniesList(); }
                    });
                };
                document.getElementById('companies-edit-tenant-cancel').onclick = function() { overlay.remove(); };
            });
        });

        listEl.querySelectorAll('.btn-delete-tenant').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var id = btn.dataset.id;
                var name = btn.dataset.name;
                if (!confirm('Excluir a empresa "' + name + '"?')) return;
                fetch(API_BASE + 'tenants.php?id=' + encodeURIComponent(id), { method: 'DELETE', credentials: 'same-origin' })
                    .then(function(r) { return r.json(); })
                    .then(function(res) { if (res.success) fetchCompaniesList(); });
            });
        });
    }).catch(function(err) {
        console.error(err);
        if (spinnerEl) spinnerEl.remove();
        if (listEl) listEl.innerHTML = '<div class="py-8 p-5 bg-red-50 border border-red-200 rounded-2xl text-red-700 text-sm font-medium">Erro ao carregar empresas.</div>';
    });
}
// GPS
function refreshLocation() {
    AppState.locStatus = 'loading';
    updateGPSUI();
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            async (pos) => {
                AppState.userCoords = { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
                AppState.locStatus = 'success';
                try {
                    const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${AppState.userCoords.latitude}&lon=${AppState.userCoords.longitude}&zoom=10`);
                    if (res.ok) {
                        const data = await res.json();
                        const addr = data.address;
                        const city = addr.city || addr.town || '';
                        const state = addr.state || '';
                        if (city) AppState.userLocationName = city + (state ? ' - ' + state : '');
                    }
                } catch (e) { console.warn(e); }
                updateGPSUI();
            },
            () => { AppState.locStatus = 'error'; updateGPSUI(); },
            { enableHighAccuracy: true, timeout: 10000 }
        );
    }
}

function updateGPSUI() {
    const indicator = document.getElementById('gps-indicator');
    const status = document.getElementById('gps-status');
    if (!indicator || !status) return;
    const locationDiv = document.getElementById('gps-location');
    const locationName = document.getElementById('gps-location-name');
    const btnText = document.getElementById('gps-btn-text');
    const icon = document.getElementById('gps-icon');
    if (AppState.locStatus === 'success') {
        indicator.className = 'w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]';
        status.textContent = 'Localização Ativa';
        if (AppState.userLocationName && locationDiv && locationName) {
            locationDiv.classList.remove('hidden');
            locationName.textContent = AppState.userLocationName;
        }
        if (btnText) btnText.textContent = 'Recarregar GPS';
        if (icon) icon.classList.remove('animate-spin');
    } else if (AppState.locStatus === 'loading') {
        indicator.className = 'w-2 h-2 rounded-full bg-yellow-500 animate-pulse';
        status.textContent = 'Detectando...';
        if (locationDiv) locationDiv.classList.add('hidden');
        if (btnText) btnText.textContent = 'Localizando...';
        if (icon) icon.classList.add('animate-spin');
    } else {
        indicator.className = 'w-2 h-2 rounded-full bg-red-500';
        status.textContent = 'GPS Inativo';
        if (locationDiv) locationDiv.classList.add('hidden');
        if (btnText) btnText.textContent = 'Recarregar GPS';
        if (icon) icon.classList.remove('animate-spin');
    }
}

function getProspectingHTML() {
    const tokenUsage = AppState.tokenUsage || { used: 0, limit: 0 }; 
    const maxTokens = (tokenUsage && tokenUsage.limit > 0) ? Math.max(1, tokenUsage.limit - tokenUsage.used) : 1000;
    
    return `
        <div class="max-w-[1400px] mx-auto">
            <div id="search-token-limit-banner" class="hidden mb-6 p-4 bg-amber-50 border border-amber-200 rounded-2xl text-amber-800 text-sm font-medium flex items-center gap-2">
                <span class="text-lg">⚠️</span>
                <span>Você atingiu o limite de tokens. Solicite mais créditos em <strong>Solicitar Créditos</strong> ou aguarde o próximo período.</span>
            </div>
            
            <div class="hidden">
                <button id="toggle-gps" class="hidden">USAR MEU GPS</button>
                <input type="hidden" id="search-method" value="scraper">
                <input type="number" id="search-max-places" value="200">
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-[2rem] shadow-sm border border-slate-200 dark:border-slate-600 mb-10">
                <div class="grid grid-cols-1 md:grid-cols-12 gap-4">
                    <div class="md:col-span-4">
                        <label class="block text-[10px] font-black text-slate-400 uppercase mb-1 ml-1 tracking-widest">O que busca?</label>
                        <input id="search-query" type="text" class="w-full px-5 py-3 rounded-xl bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 focus:border-blue-500 outline-none font-bold text-sm transition-all placeholder-slate-400 dark:placeholder-slate-500" placeholder="Ex: Petshop, Clínica, Padaria...">
                    </div>
                    <div class="md:col-span-4">
                        <label class="block text-[10px] font-black text-slate-400 uppercase mb-1 ml-1 tracking-widest">Onde?</label>
                        <input id="search-location" type="text" class="w-full px-5 py-3 rounded-xl bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 focus:border-blue-500 outline-none font-bold text-sm transition-all placeholder-slate-400 dark:placeholder-slate-500" placeholder="Cidade ou Região">
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-[10px] font-black text-slate-400 uppercase mb-1 ml-1 tracking-widest">Tag CRM</label>
                        <input id="search-tag" type="text" class="w-full px-5 py-3 rounded-xl bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 focus:border-blue-500 outline-none font-bold text-sm placeholder-slate-400 dark:placeholder-slate-500" placeholder="Ex: leads_novos">
                    </div>
                    <div class="md:col-span-2 flex items-end">
                        <button id="btn-search" class="w-full py-3.5 bg-slate-900 hover:bg-blue-600 text-white font-black rounded-xl transition-all shadow-lg shadow-slate-900/30 dark:shadow-lg dark:shadow-black/20 disabled:opacity-50 flex items-center justify-center uppercase tracking-wider text-xs">
                            Buscar Tudo
                        </button>
                    </div>
                </div>
            </div>
            
            <div id="error-info" class="hidden mb-8 p-5 bg-amber-50 border-l-4 border-amber-400 text-amber-900 rounded-r-2xl shadow-sm"></div>
            <div id="results-header" class="hidden mb-6 flex flex-wrap justify-between items-end gap-4 px-2">
                <div>
                    <h3 class="text-xl font-black text-slate-900 dark:text-slate-100 tracking-tight">Resultados da Busca</h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400 font-medium">
                        Exibindo <span id="visible-count" class="font-bold text-slate-900 dark:text-slate-100">0</span> de <span id="total-count" class="font-bold text-slate-900 dark:text-slate-100">0</span> empresas encontradas
                    </p>
                    <p class="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">
                        Tokens disponíveis na conta: <span id="available-tokens" class="font-bold text-slate-900 dark:text-slate-100">—</span>
                    </p>
                </div>
                <div id="results-header-buttons" class="flex items-center gap-3">
                    <button id="btn-export-excel" type="button" class="flex items-center gap-2 px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl transition-all text-xs font-black uppercase shadow-lg shadow-emerald-900/20" title="Exportar pesquisa atual para Excel">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                        Exportar para Excel
                    </button>
                    <button id="btn-export-webhook" type="button" class="hidden flex items-center gap-2 px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-all text-xs font-black uppercase shadow-lg shadow-blue-900/20" title="Enviar pesquisa atual para o Webhook">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>
                        Exportar para Webhook
                    </button>
                </div>
            </div>
            
            <div id="leads-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 mb-12"></div>
            
            <div id="load-more-container" class="hidden flex justify-center mb-20"></div>
            
            <div id="empty-state" class="py-32 text-center">
                <div class="w-28 h-28 bg-blue-500/10 dark:bg-blue-500/5 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl relative animate-pulse">
                    <div class="absolute inset-0 rounded-full border border-blue-500/30 animate-ping" style="animation-duration: 2s;"></div>
                    <span class="text-5xl animate-bounce" style="animation-duration: 3s;">🗺️</span>
                </div>
                <h4 class="text-xs font-black text-slate-800 dark:text-slate-200 uppercase tracking-[0.25em] mb-2 animate-pulse">Pronto para Prospectar?</h4>
                <p class="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Digite uma atividade e cidade acima para iniciar a busca</p>
            </div>
        </div>
    `;
} 

function setupProspectingEvents() {
    const btnSearch = document.getElementById('btn-search');
    if (btnSearch) {
        btnSearch.addEventListener('click', function(e) {
            e.preventDefault();
            performSearch();
        });
    }
    const queryInput = document.getElementById('search-query');
    const locationInput = document.getElementById('search-location');
    if (queryInput) {
        queryInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') performSearch();
        });
    }
    if (locationInput) {
        locationInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') performSearch();
        });
    }
    const btnExportExcel = document.getElementById('btn-export-excel');
    if (btnExportExcel) {
        btnExportExcel.addEventListener('click', function(e) {
            e.preventDefault();
            exportCurrentSearchToExcel();
        });
    }
    const btnExportWebhook = document.getElementById('btn-export-webhook');
    if (btnExportWebhook) {
        btnExportWebhook.addEventListener('click', function(e) {
            e.preventDefault();
            exportCurrentSearchToWebhook();
        });
    }
}

function escapeCsv(val) {
    if (val == null || val === undefined) return '';
    const s = String(val).trim();
    if (s.includes(',') || s.includes('"') || s.includes('\n') || s.includes('\r')) {
        return '"' + s.replace(/"/g, '""') + '"';
    }
    return s;
}

/**
 * Normaliza telefones retornados por provedores de mapas.
 * Mantém o valor original quando não é possível identificar com segurança
 * um número brasileiro ou internacional.
 */
function formatPhoneDisplay(value) {
    if (value == null) return '';

    if (Array.isArray(value)) {
        const formatted = value
            .flatMap(item => formatPhoneDisplay(item).split(' / '))
            .map(item => item.trim())
            .filter(Boolean);
        return [...new Set(formatted)].join(' / ');
    }

    if (typeof value === 'object') {
        const nested = value.phone || value.phoneNumber || value.number || value.value || '';
        return formatPhoneDisplay(nested);
    }

    const raw = String(value).trim();
    if (!raw) return '';

    const chunks = raw
        .split(/\s*(?:\/|;|\||\n)\s*/)
        .map(item => item.trim())
        .filter(Boolean);

    const formatted = chunks.map(item => {
        const extensionMatch = item.match(/(?:ext\.?|x|ramal)\s*([0-9]+)\s*$/i);
        const extension = extensionMatch ? ` ramal ${extensionMatch[1]}` : '';
        let digits = item.replace(/(?:ext\.?|x|ramal)\s*[0-9]+\s*$/i, '').replace(/\D/g, '');

        // Remove prefixos internacionais de discagem e o zero de tronco.
        digits = digits.replace(/^00+/, '');
        if (digits.length > 11 && digits.startsWith('0')) digits = digits.replace(/^0+/, '');

        // Retorno brasileiro com código do país: 55 + DDD + telefone.
        if (digits.startsWith('55')) {
            const local = digits.slice(2);
            if (local.length === 10 || local.length === 11) {
                const area = local.slice(0, 2);
                const number = local.slice(2);
                const splitAt = number.length === 9 ? 5 : 4;
                return `+55 ${area} ${number.slice(0, splitAt)}-${number.slice(splitAt)}${extension}`;
            }
        }

        // Retorno brasileiro sem código do país: assume DDD + telefone.
        if (digits.length === 10 || digits.length === 11) {
            const area = digits.slice(0, 2);
            const number = digits.slice(2);
            const splitAt = number.length === 9 ? 5 : 4;
            return `+55 ${area} ${number.slice(0, splitAt)}-${number.slice(splitAt)}${extension}`;
        }

        // Para outros países ou formatos incompletos, não inventa agrupamento.
        return item + extension;
    }).filter(Boolean);

    return [...new Set(formatted)].join(' / ');
}

function getLeadPhoneValue(lead) {
    if (!lead) return '';
    return lead.phone || lead.phoneNumber || lead.internationalPhone || lead.telephone || lead.phoneNumbers || '';
}

function exportCurrentSearchToExcel() {
    if (!AppState.searchId) {
        showError('Sessão da pesquisa expirada. Faça uma nova busca.');
        return;
    }
    const leads = (AppState.leads || []);
    if (leads.length === 0) {
        alert('Nenhum lead encontrado para exportar.');
        return;
    }
    const ctx = AppState.currentSearch || {};
    const queryEl = document.getElementById('search-query');
    const locationEl = document.getElementById('search-location');
    const tagEl = document.getElementById('search-tag');
    const query = (ctx.query !== undefined && ctx.query !== '') ? ctx.query : (queryEl ? queryEl.value.trim() : '');
    const location = (ctx.location !== undefined && ctx.location !== '') ? ctx.location : ((locationEl && locationEl.value !== undefined) ? String(locationEl.value || '').trim() : '');
    const tag = (ctx.tag !== undefined && ctx.tag !== '') ? ctx.tag : (tagEl ? tagEl.value.trim() : '');
    const dateStr = new Date().toLocaleString('pt-BR');

    const rows = [];
    const headers = ['Pesquisa', 'Local', 'Tag', 'Data da Pesquisa', 'Nome', 'Telefone', 'Email', 'Endereço', 'CNPJ', 'Sócios', 'Site', 'Maps'];
    rows.push(headers);

    for (const lead of leads) {
        rows.push([
            escapeCsv(query),
            escapeCsv(location),
            escapeCsv(tag),
            escapeCsv(dateStr),
            escapeCsv(lead.name),
            escapeCsv(formatPhoneDisplay(getLeadPhoneValue(lead))),
            escapeCsv(lead.email || ''),
            escapeCsv(lead.address || ''),
            escapeCsv(lead.cnpj || ''),
            escapeCsv(lead.partners || ''),
            escapeCsv(lead.website || ''),
            escapeCsv(lead.mapsUri || '')
        ]);
    }

    const csvContent = rows.map(row => row.join(';')).join('\r\n');
    const BOM = '\uFEFF';
    const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'pesquisa_atual_' + new Date().toISOString().slice(0, 10) + '.csv';
    a.click();
    URL.revokeObjectURL(url);
}

async function exportCurrentSearchToWebhook() {
    const leads = AppState.leads || [];
    if (leads.length === 0) {
        alert('Nenhum lead na pesquisa atual para enviar.');
        return;
    }
    // A URL efetiva é resolvida pelo servidor na ordem: pessoal, empresa e
    // plataforma. Não bloqueie a exportação aqui, pois o usuário pode usar
    // corretamente um dos níveis de fallback sem ter URL pessoal.
    const btn = document.getElementById('btn-export-webhook');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<span class="animate-pulse">Enviando...</span>';
    }
    try {
        const res = await fetch(API_BASE + 'export-bulk.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ leadIds: leads.map(l => l.id) })
        });
        const data = await res.json();
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg> Exportar para Webhook';
        }
        if (data.success) {
            showToast(data.message || 'Enviado para o Webhook.');
        } else {
            alert('❌ Erro: ' + (data.error || 'Erro desconhecido'));
        }
    } catch (e) {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg> Exportar para Webhook';
        }
        alert('❌ Erro de conexão: ' + e.message);
    }
}
async function performSearch() {
    var limitReached = (AppState.tokenUsage && AppState.tokenUsage.limitReached) || (AppState.tenant && AppState.tenant.status === 'suspended');
    if (limitReached) {
        showError('Você atingiu o limite de tokens do seu plano para este período. Solicite mais créditos em "Solicitar Créditos" ou aguarde o próximo período.');
        return;
    }

    const query = document.getElementById('search-query').value.trim();
    const location = document.getElementById('search-location')?.value.trim() || '';
    const tag = document.getElementById('search-tag').value.trim();
    const useGPS = document.getElementById('toggle-gps') ? document.getElementById('toggle-gps').textContent === 'GPS ATIVO' : false;
    
    if (!query) {
        showError('Digite o ramo de atividade (Ex: Petshop).');
        return;
    }
    
    if (!useGPS && !location) {
        showError('Digite a cidade ou ative o GPS.');
        return;
    }
    
    const btn = document.getElementById('btn-search');
    btn.disabled = true;
    btn.innerHTML = '<div class="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>';
    
    hideError();
    AppState.leads = [];
    AppState.visibleCount = 12;
    
    try {
        var maxPlacesEl = document.getElementById('search-max-places');
        var maxPlaces = 200;
        var tokenUsage = AppState.tokenUsage;
        var maxTokens = (tokenUsage && tokenUsage.limit > 0) ? Math.max(1, tokenUsage.limit - tokenUsage.used) : 1000;
        
        if (maxPlacesEl && maxPlacesEl.value) {
            var v = parseInt(maxPlacesEl.value, 10);
            if (!isNaN(v)) maxPlaces = Math.max(1, Math.min(maxTokens, v));
        }
        var methodEl = document.getElementById('search-method');
        var searchMethod = methodEl && methodEl.value ? methodEl.value : 'scraper';
        const res = await fetch(API_BASE + 'search.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                query,
                location: useGPS ? null : location,
                tag,
                useGPS,
                coords: useGPS ? AppState.userCoords : null,
                locationName: useGPS ? AppState.userLocationName : null,
                maxCrawledPlacesPerSearch: maxPlaces,
                searchMethod: searchMethod
            })
        });
        
        if (!res.ok) {
            const text = await res.text();
            let errorMsg = `Erro ${res.status}: Erro interno do servidor`;
            try {
                if (text) {
                    const errorData = JSON.parse(text);
                    errorMsg = errorData.error || errorData.message || errorMsg;
                }
            } catch (e) { }
            showError(errorMsg);
            return;
        }
        
        const text = await res.text();
        if (!text || text.trim() === '') {
            showError('Erro: Resposta vazia do servidor.');
            return;
        }
        
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            showError('Erro ao processar resposta do servidor: ' + e.message);
            return;
        }
        
        if (data.success) {
    AppState.leads = data.data.leads;
    AppState.searchId = data.data.searchId || null;
    if (data.data.tokenUsage) AppState.tokenUsage = data.data.tokenUsage;
    var locationText = useGPS ? (AppState.userLocationName || 'Localização GPS') : location;
    AppState.currentSearch = { query: query, location: locationText, tag: tag };

    // 💡 NOVO: Se outro usuário já pesquisou este mesmo termo antes, exibe o aviso:
    if (data.data.searchedBy) {
        showToast(`⚠️ Este termo já foi pesquisado anteriormente por: ${data.data.searchedBy}`, 'warning');
    } else if (data.data.duplicatesRemoved > 0) {
        showToast(data.data.duplicatesRemoved + ' resultado(s) duplicado(s) removidos.', 'warning');
    }
            
            if (data.data.isNewSearch) {
    var realSearchId = String(data.data.searchId || Date.now());
    var newItem = { 
        id: realSearchId, // ✅ Usa o ID verdadeiro gravado no banco
        query: query, 
        location: locationText, 
        tag: tag, 
        timestamp: new Date().toISOString(), 
        resultsCount: AppState.leads.length, 
        leads: AppState.leads.slice() 
    };
    AppState.history = [newItem].concat(AppState.history.filter(function(h) { return h.id !== realSearchId; })).slice(0, 50);
} else {
                showToast('Pesquisa continuada - novos resultados adicionados.', 'success');
            }
            displayLeads();
        } else {
            showError(data.error || 'Erro ao buscar leads');
        }
    } catch (e) {
        showError('Erro de conexão: ' + e.message);
    } finally {
        btn.disabled = false;
        btn.textContent = 'Buscar Tudo';
    }
}

function displayLeads() {
    const grid = document.getElementById('leads-grid');
    const emptyState = document.getElementById('empty-state');
    const resultsHeader = document.getElementById('results-header');
    const loadMoreContainer = document.getElementById('load-more-container');

    // A renderização pode ser acionada por um timeout depois que o usuário
    // mudou de aba. Nesse caso, os elementos pertencentes à busca já não
    // existem no DOM e a função deve encerrar sem alterar o painel atual.
    if (!grid || !emptyState || !resultsHeader || !loadMoreContainer) {
        return;
    }

    if (!Array.isArray(AppState.leads)) {
        AppState.leads = [];
    }
    
    if (AppState.leads.length === 0) {
        grid.innerHTML = '';
        emptyState.classList.remove('hidden');
        resultsHeader.classList.add('hidden');
        loadMoreContainer.classList.add('hidden');
        return;
    }
    
    emptyState.classList.add('hidden');
    resultsHeader.classList.remove('hidden');

    const btnExportWebhook = document.getElementById('btn-export-webhook');
    if (btnExportWebhook) {
        // Verifica se existe URL configurada no config global ou no tenant
        const hasWebhookUrl = (AppState.config && AppState.config.baseUrl && String(AppState.config.baseUrl).trim() !== '') ||
                              (AppState.tenant && AppState.tenant.webhookUrl && String(AppState.tenant.webhookUrl).trim() !== '');
        
        btnExportWebhook.classList.toggle('hidden', !hasWebhookUrl);
    }

    const visible = AppState.leads.slice(0, AppState.visibleCount);
    const visibleCountEl = document.getElementById('visible-count');
    const totalCountEl = document.getElementById('total-count');
    if (visibleCountEl) visibleCountEl.textContent = visible.length;
    if (totalCountEl) totalCountEl.textContent = AppState.leads.length;
    var u = AppState.tokenUsage;
    var availableEl = document.getElementById('available-tokens');
    if (availableEl) {
        if (u == null) availableEl.textContent = '—';
        else if (u.limit === 0) availableEl.textContent = 'Ilimitado';
        else availableEl.textContent = Math.max(0, u.limit - u.used);
    }
    
    grid.innerHTML = visible.map(lead => getLeadCardHTML(lead)).join('');
    
    document.querySelectorAll('.btn-export').forEach(btn => {
        btn.addEventListener('click', () => { exportLead(btn.dataset.leadId); });
    });
    
    document.querySelectorAll('.btn-export-atendo').forEach(btn => {
        btn.addEventListener('click', () => { exportLeadToAtendo(btn.dataset.leadId); });
    });
    
    if (AppState.leads.length > AppState.visibleCount) {
        loadMoreContainer.classList.remove('hidden');
        loadMoreContainer.innerHTML = `
            <button id="btn-load-more" class="group relative px-8 py-4 bg-white border-2 border-slate-200 dark:border-slate-600 rounded-full shadow-lg hover:shadow-xl hover:border-blue-500 transition-all active:scale-95">
                <div class="flex items-center gap-3">
                    <div class="bg-slate-100 dark:bg-slate-700 rounded-full p-2 group-hover:bg-blue-100 dark:group-hover:bg-blue-900/50 transition-colors">
                        <svg class="w-4 h-4 text-slate-600 dark:text-slate-400 group-hover:text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M19 13l-7 7-7-7m14-8l-7 7-7-7" /></svg>
                    </div>
                    <span class="text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-widest group-hover:text-blue-700">
                        Carregar Mais Resultados (${AppState.leads.length - AppState.visibleCount} restantes)
                    </span>
                </div>
            </button>
        `;
        const loadMoreButton = document.getElementById('btn-load-more');
        if (loadMoreButton) {
            loadMoreButton.addEventListener('click', () => {
                AppState.visibleCount += 12;
                displayLeads();
            });
        }
    } else {
        loadMoreContainer.classList.add('hidden');
    }
}
// Gera o layout HTML do card de lead (dados completos sempre visíveis)
function getLeadCardHTML(lead) {
    const phoneDisplay = formatPhoneDisplay(getLeadPhoneValue(lead));
    return `
        <div class="relative mt-4 pt-10 pb-6 px-6 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-600 rounded-[1.5rem] hover:shadow-2xl hover:shadow-blue-900/5 transition-all duration-300 flex flex-col justify-between group">
            <div class="absolute -top-3 left-6 bg-blue-600 text-white text-[9px] font-black py-1.5 px-3 rounded-lg uppercase tracking-wider shadow-lg shadow-blue-200 z-10">
                ${lead.partners ? 'Dados Ricos' : 'Lead'}
            </div>
            <div>
                <h3 class="font-extrabold text-slate-900 dark:text-slate-100 text-sm uppercase leading-snug mb-4 min-h-[2.5rem]">${lead.name || ''}</h3>
                <div class="space-y-3 mb-6">
                    <div class="flex items-center gap-3 bg-emerald-50/50 dark:bg-emerald-950/20 p-2 rounded-lg -mx-2">
                        <span class="text-emerald-500 dark:text-emerald-400 text-xs">📞</span>
                        <span class="text-emerald-700 dark:text-emerald-300 font-bold text-xs">${phoneDisplay || 'Sem telefone'}</span>
                    </div>
                    ${lead.partners ? `
                        <div class="flex items-start gap-3">
                            <span class="text-purple-400 text-xs mt-0.5">👥</span>
                            <div class="flex flex-col">
                                <span class="text-[9px] font-black text-slate-400 uppercase">Sócios/Resp.</span>
                                <p class="text-slate-700 dark:text-slate-300 font-bold text-[10px] leading-tight">${lead.partners}</p>
                            </div>
                        </div>
                    ` : ''}
                    ${lead.cnpj ? `
                        <div class="flex items-center gap-3">
                            <span class="text-amber-400 text-xs">🏢</span>
                            <div class="flex flex-col">
                                <span class="text-[9px] font-black text-slate-400 uppercase">CNPJ</span>
                                <span class="text-slate-700 dark:text-slate-300 font-mono font-bold text-[10px]">${lead.cnpj}</span>
                            </div>
                        </div>
                    ` : ''}
                    ${lead.email ? `
                        <div class="flex items-center gap-3">
                            <span class="text-blue-400 text-xs">✉️</span>
                            <div class="flex flex-col overflow-hidden">
                                <span class="text-[9px] font-black text-slate-400 uppercase">Email</span>
                                <a href="mailto:${lead.email}" class="text-blue-600 dark:text-blue-400 font-bold text-[10px] hover:underline truncate w-full block">${lead.email}</a>
                            </div>
                        </div>
                    ` : ''}
                    ${lead.website ? `
                        <div class="flex items-center gap-3">
                            <span class="text-slate-500 dark:text-slate-400 text-xs">🌐</span>
                            <div class="flex flex-col overflow-hidden">
                                <span class="text-[9px] font-black text-slate-400 uppercase">Site</span>
                                <a href="${lead.website}" target="_blank" rel="noopener noreferrer" class="text-blue-600 dark:text-blue-400 font-bold text-[10px] hover:underline truncate w-full block">${lead.website}</a>
                            </div>
                        </div>
                    ` : ''}
                    <div class="flex items-start gap-3 pt-2 border-t border-slate-100 dark:border-slate-700">
                        <span class="text-rose-400 text-xs mt-0.5">📍</span>
                        <p class="text-slate-500 dark:text-slate-400 font-semibold text-[10px] leading-relaxed line-clamp-2">${lead.address || ''}</p>
                    </div>
                </div>
            </div>
            <div class="flex items-center gap-3 pt-4 border-t border-slate-100 dark:border-slate-700 mt-auto">
                <button class="btn-export flex-grow bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-900 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-600 hover:border-slate-300 font-black text-[10px] py-3 rounded-xl uppercase tracking-wide transition-all shadow-sm active:scale-95 disabled:opacity-50 flex justify-center items-center gap-2" data-lead-id="${lead.id}">
                    Exportar WEBHOOK
                </button>
                ${lead.mapsUri ? `
                    <a href="${lead.mapsUri}" target="_blank" rel="noopener noreferrer" class="w-12 h-[38px] flex-shrink-0 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-blue-500 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-slate-600 hover:border-blue-200 rounded-xl flex items-center justify-center transition-all shadow-sm" title="Ver no Google Maps">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M18.7 3.8C15 .1 9 .1 5.3 3.8c-3.7 3.7-3.7 9.8 0 13.5L12 24l6.7-6.7c3.7-3.7 3.7-9.8 0-13.5zm-6.7 10c-1.9 0-3.5-1.6-3.5-3.5s1.6-3.5 3.5-3.5 3.5 1.6 3.5 3.5-1.6 3.5-3.5 3.5z"/></svg>
                    </a>
                ` : ''}
            </div>
        </div>
    `;
}

async function exportLead(leadId) {
    const lead = AppState.leads.find(l => l.id === leadId);
    if (!lead) {
        alert('Lead não encontrado');
        return;
    }
    const numericId = leadId.replace('lead-', '');
    try {
        const res = await fetch(API_BASE + 'export.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                leadId: numericId,
                leadName: lead.name,
                leadAddress: lead.address
            })
        });
        const data = await res.json();
        if (data.success) {
            showToast(data.message || 'Enviado com sucesso para o CRM!');
        } else {
            alert('❌ Erro no Envio: ' + data.error);
        }
    } catch (e) {
        alert('❌ Erro: ' + e.message);
    }
}
// Histórico
var isHistoryLoading = false; // Impede loops de requisições concorrentes

async function loadHistory() {
    if (isHistoryLoading) return;
    isHistoryLoading = true;

    const contentArea = document.getElementById('content-area');
    contentArea.innerHTML = '<div class="max-w-5xl mx-auto"><div class="text-center py-10"><div class="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto"></div></div></div>';
    
    try {
        const res = await fetch(API_BASE + 'history.php');
        if (res.status === 507 || res.status === 508) {
            contentArea.innerHTML = '<div class="max-w-5xl mx-auto"><div class="rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm"><h3 class="text-lg font-bold text-slate-800">Histórico temporariamente indisponível</h3><p class="mt-2 text-sm text-slate-500">Não foi possível consultar o histórico neste momento. Tente novamente mais tarde.</p></div></div>';
            return;
        }
        const text = await res.text();
        if (!text || text.trim() === '') throw new Error('Resposta vazia do servidor');
        
        // Verifica se a resposta não é uma página HTML de erro antes de parsear
        if (text.trim().startsWith('<!DOCTYPE') || text.trim().startsWith('<html')) {
            throw new Error('O servidor retornou uma página de erro HTML em vez de dados JSON.');
        }

        const data = JSON.parse(text);
        if (data.success) {
            AppState.history = data.data || [];
            displayHistory();
        } else {
            throw new Error(data.error || 'Erro desconhecido');
        }
    } catch (e) {
        console.error('History error:', e);
        contentArea.innerHTML = `<div class="max-w-5xl mx-auto"><div class="bg-red-50 p-5 rounded-2xl text-red-700">Erro ao carregar histórico: ${e.message}</div></div>`;
    } finally {
        isHistoryLoading = false;
    }
}

function formatHistoryTimestamp(ts) {
    if (!ts) return '—';
    try {
        var d = new Date(ts);
        if (isNaN(d.getTime())) return '—';
        var day = String(d.getDate()).padStart(2, '0');
        var month = String(d.getMonth() + 1).padStart(2, '0');
        var year = d.getFullYear();
        var h = String(d.getHours()).padStart(2, '0');
        var m = String(d.getMinutes()).padStart(2, '0');
        return day + '/' + month + '/' + year + ' ' + h + ':' + m;
    } catch (e) { return '—'; }
}

function getHistoryItemCount(item) {
    return item.resultsCount ?? item.results_count ?? (item.leads && item.leads.length) ?? 0;
}

function applyHistoryFilters(history, searchText, dateFrom, dateTo) {
    var search = (searchText || '').trim().toLowerCase();
    var from = (dateFrom || '').trim();
    var to = (dateTo || '').trim();
    return history.filter(function(item) {
        if (search) {
            var q = (item.query || '').toLowerCase();
            var loc = (item.location || '').toLowerCase();
            var tag = (item.tag || '').toLowerCase();
            if (q.indexOf(search) === -1 && loc.indexOf(search) === -1 && tag.indexOf(search) === -1) return false;
        }
        var ts = item.timestamp;
        if (ts && (from || to)) {
            try {
                var d = new Date(ts);
                if (isNaN(d.getTime())) return false;
                var dateStr = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
                if (from && dateStr < from) return false;
                if (to && dateStr > to) return false;
            } catch (e) { return false; }
        }
        return true;
    });
}

function renderHistoryList(listEl, filtered) {
    listEl.innerHTML = filtered.map(function(item) {
        var count = getHistoryItemCount(item);
        var dateTime = formatHistoryTimestamp(item.timestamp);
        var tagLabel = (item.tag && item.tag.trim()) ? item.tag.trim() : '—';
        return '<div class="bg-white dark:bg-slate-800 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600 flex items-center justify-between group hover:border-blue-300 transition-all hover:shadow-md">' +
            '<div class="flex items-center gap-6">' +
            '<div class="w-12 h-12 bg-slate-50 dark:bg-slate-800/50 rounded-xl flex items-center justify-center text-xl">🔎</div>' +
            '<div>' +
            '<h4 class="font-extrabold text-slate-900 dark:text-slate-100 text-lg capitalize">' + (item.query || '') + '</h4>' +
            '<p class="text-[11px] font-bold text-slate-400 mt-1 uppercase tracking-wider">📍 ' + (item.location || 'Local Automático') + ' <span class="ml-2">🏷 ' + tagLabel + '</span> <span class="ml-2 text-slate-500">' + dateTime + '</span> <span class="ml-2 text-blue-500">(' + count + ' leads)</span></p>' +
            '</div></div>' +
            '<div class="flex items-center gap-2">' +
            '<button class="btn-use-history bg-slate-900 text-white font-bold px-6 py-3 rounded-2xl text-xs hover:bg-blue-600 transition-colors" data-history-id="' + item.id + '">Ver Novamente</button>' +
            '</div>' +
            '</div>';
    }).join('');
    
    listEl.querySelectorAll('.btn-use-history').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var historyId = btn.dataset.historyId;
            var item = AppState.history.find(function(h) { return h.id == historyId; });
            
            if (item) {
                // Se for uma Consulta de CNPJ
                if (item.tag === 'CNPJ_AVANCADA' || (item.query && item.query.includes('Consulta CNPJ:'))) {
                    // Extrai apenas os números do CNPJ salvo na string "Consulta CNPJ: 12345678000190"
                    var cnpjBuscado = item.query.replace(/\D/g, ''); 
                    
                    if (cnpjBuscado && cnpjBuscado.length >= 14) {
                        setActiveTab('cnpj-lookup'); // Abre a aba de Consulta CNPJ
                        setTimeout(function() {
                            var cnpjInput = document.getElementById('cnpj-simple-input');
                            if (cnpjInput) {
                                cnpjInput.value = cnpjBuscado; // Preenche o campo
                                performCnpjSimpleLookup(); // Força a busca automaticamente
                            }
                        }, 200);
                    } else {
                        showToast('O CNPJ desta consulta não pode ser lido corretamente.', 'warning');
                    }
                } 
                // Se for uma busca comum do Google Maps
                else {
                    AppState.searchId = String(item.id);
                    AppState.leads = (item.leads || []).map(function(l) { return l; });
                    AppState.currentSearch = { query: item.query || '', location: item.location || '', tag: item.tag || '' };
                    setActiveTab('search'); // Abre a aba de Prospecção
                    setTimeout(function() {
                        if (AppState.activeTab === 'search' && document.getElementById('leads-grid')) {
                            displayLeads();
                        }
                    }, 100);
                }
            }
        });
    });
}
function displayHistory() {
    const contentArea = document.getElementById('content-area');
    if (AppState.history.length === 0) {
        contentArea.innerHTML = `
            <div class="max-w-5xl mx-auto">
                <div class="py-24 text-center border-2 border-dashed border-slate-200 dark:border-slate-600 rounded-[2rem]">
                    <p class="text-slate-400 font-bold uppercase text-[10px]">Nenhum registro encontrado</p>
                </div>
            </div>
        `;
        return;
    }
    contentArea.innerHTML = `
        <div class="max-w-5xl mx-auto">
            <div class="bg-slate-50 dark:bg-slate-800/50 p-5 rounded-2xl border border-slate-200 dark:border-slate-600 mb-6">
                <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-3">Buscar resultados</label>
                <div class="flex flex-wrap gap-3 items-end">
                    <div class="flex-1 min-w-[200px]">
                        <input id="history-search" type="text" class="w-full px-4 py-2.5 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-900 dark:text-slate-100 font-bold text-sm placeholder-slate-400 focus:border-blue-500 outline-none" placeholder="Termo, local ou tag">
                    </div>
                    <div>
                        <label class="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">De</label>
                        <input id="history-date-from" type="date" class="px-4 py-2.5 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-900 dark:text-slate-100 font-bold text-sm focus:border-blue-500 outline-none">
                    </div>
                    <div>
                        <label class="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Até</label>
                        <input id="history-date-to" type="date" class="px-4 py-2.5 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-900 dark:text-slate-100 font-bold text-sm focus:border-blue-500 outline-none">
                    </div>
                </div>
            </div>
            <div class="flex justify-between items-center mb-10">
                <div><h3 class="text-2xl font-black text-slate-900 dark:text-slate-100">Histórico Recente</h3></div>
                <button id="btn-clear-history" class="text-xs font-extrabold text-red-500 hover:bg-red-50 px-5 py-2 rounded-xl">Limpar Tudo</button>
            </div>
            <div class="space-y-4" id="history-list"></div>
        </div>
    `;
    var listEl = document.getElementById('history-list');
    function refreshFilteredList() {
        var searchVal = (document.getElementById('history-search') && document.getElementById('history-search').value) || '';
        var fromVal = (document.getElementById('history-date-from') && document.getElementById('history-date-from').value) || '';
        var toVal = (document.getElementById('history-date-to') && document.getElementById('history-date-to').value) || '';
        var filtered = applyHistoryFilters(AppState.history, searchVal, fromVal, toVal);
        renderHistoryList(listEl, filtered);
    }
    refreshFilteredList();
    var searchInput = document.getElementById('history-search');
    var dateFromInput = document.getElementById('history-date-from');
    var dateToInput = document.getElementById('history-date-to');
    if (searchInput) searchInput.addEventListener('input', refreshFilteredList);
    if (dateFromInput) dateFromInput.addEventListener('change', refreshFilteredList);
    if (dateToInput) dateToInput.addEventListener('change', refreshFilteredList);
    
    document.getElementById('btn-clear-history').addEventListener('click', async () => {
        if (confirm('Deseja apagar o histórico de buscas?')) {
            try {
                const res = await fetch(API_BASE + 'history.php', { method: 'DELETE' });
                const data = await res.json();
                if (data.success) {
                    AppState.history = [];
                    displayHistory();
                }
            } catch (e) { alert('Erro ao limpar histórico: ' + e.message); }
        }
    });
}

// Carregar pastas do usuário
async function loadFolders() {
    try {
        const res = await fetch(API_BASE + 'folders.php');
        const data = await res.json();
        if (data.success) {
            AppState.folders = data.data || [];
            updateFolderSelect();
        }
    } catch (e) { console.error('Erro ao carregar pastas:', e); }
}

function updateFolderSelect() {
    const folderSelect = document.getElementById('search-folder');
    if (!folderSelect) return;
    const folderOptions = AppState.folders.map(f => `<option value="${f.id}">${f.name}</option>`).join('');
    folderSelect.innerHTML = '<option value="">Sem pasta</option>' + folderOptions;
}

// Criar nova pasta
async function createFolder(name) {
    try {
        const res = await fetch(API_BASE + 'folders.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name })
        });
        const data = await res.json();
        if (data.success) {
            await loadFolders();
            return data.data;
        }
    } catch (e) { console.error('Erro ao criar pasta:', e); }
    return null;
}
function getApiBuscaHTML() {
    const isSuperAdmin = AppState.user && String(AppState.user.profile).toLowerCase() === 'super_admin';

    if (!isSuperAdmin) {
        return `
            <div class="max-w-3xl mx-auto py-20 text-center">
                <div class="bg-amber-50 p-6 rounded-2xl border border-amber-200 dark:bg-amber-900/10 dark:border-amber-800">
                    <h3 class="text-amber-800 dark:text-amber-400 font-bold">Acesso Restrito</h3>
                    <p class="text-amber-600 dark:text-amber-500 text-sm">Esta área é exclusiva para o administrador da plataforma.</p>
                </div>
            </div>
        `;
    }

    return `
        <div class="max-w-4xl mx-auto space-y-8 pb-20">
            <div class="bg-white dark:bg-slate-800 p-10 rounded-[2.5rem] border border-slate-200 dark:border-slate-600 shadow-sm">
                <h3 class="text-2xl font-black text-slate-900 dark:text-slate-100 mb-8 tracking-tight">Gerenciador de chaves de pesquisa (rotação automática)</h3>
                <div class="space-y-8">
                    
                    <!-- Formulário para Adicionar Nova Chave -->
                    <div class="bg-[#0F172A] p-6 rounded-[2rem] border border-slate-800 text-white relative overflow-hidden">
                        <div class="absolute top-0 right-0 w-32 h-32 bg-purple-600/10 rounded-full blur-3xl"></div>
                        <h4 class="font-black text-lg mb-3 flex items-center gap-2">➕ Adicionar nova chave de pesquisa</h4>
                        <p class="text-xs text-slate-400 mb-4">Cadastre múltiplas chaves. O sistema fará a rotação automática entre elas a cada busca realizada.</p>
                        
                        <form id="form-add-apify-key" class="space-y-4">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-[10px] font-black text-slate-300 uppercase mb-1 ml-1">Identificação (Apelido)</label>
                                    <input id="apify-key-label" type="text" required class="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3 outline-none focus:border-purple-500 font-bold text-white text-xs" placeholder="Ex.: Conta de pesquisa 01">
                                </div>
                                <div>
                                    <label class="block text-[10px] font-black text-slate-300 uppercase mb-1 ml-1">Token / chave de pesquisa</label>
                                    <input id="apify-key-token" type="password" required class="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3 outline-none focus:border-purple-500 font-bold text-white text-xs" placeholder="Cole o token fornecido pelo serviço de pesquisa">
                                </div>
                            </div>
                            <button type="submit" id="btn-save-apify-key" class="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-black rounded-xl transition shadow-lg text-xs uppercase tracking-wider">Salvar Chave</button>
                        </form>
                    </div>

                    <!-- Tabela de Chaves Cadastradas -->
                    <div class="bg-slate-50 dark:bg-slate-700/30 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-700">
                        <h4 class="font-black text-lg mb-4 text-slate-900 dark:text-white">Chaves Cadastradas no Sistema</h4>
                        <div id="apify-keys-list-container" class="overflow-x-auto">
                            <p class="text-xs text-slate-500 text-center py-4">Carregando chaves...</p>
                        </div>
                    </div>

                    <div id="apify-usage-panel" class="bg-slate-50 dark:bg-slate-700/30 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-700"></div>

                    <!-- TOKEN MAPBOX -->
                    <div id="block-mapbox-token" class="bg-[#0F172A] p-6 rounded-[2rem] border border-slate-800 text-white relative overflow-hidden">
                        <div class="absolute top-0 right-0 w-32 h-32 bg-green-600/10 rounded-full blur-3xl"></div>
                        <h4 class="font-black text-lg mb-3 flex items-center gap-2">Token Mapbox (GeoSearch)</h4>
                        <div>
                            <label class="block text-[10px] font-black text-slate-300 uppercase mb-2 ml-1">Mapbox Access Token</label>
                            <input id="setting-mapbox-token" type="password" class="w-full bg-slate-900/50 border border-slate-700 rounded-2xl px-6 py-4 outline-none focus:border-green-500 font-bold text-white placeholder:text-slate-500" placeholder="pk.eyJ1Ijoi...">
                        </div>
                    </div>

                    <!-- URL DE CNPJ -->
                    <div class="bg-[#0F172A] p-6 rounded-[2rem] border border-slate-800 text-white relative overflow-hidden">
                        <div class="absolute top-0 right-0 w-32 h-32 bg-emerald-600/10 rounded-full blur-3xl"></div>
                        <h4 class="font-black text-lg mb-3 flex items-center gap-2">🏢 URL de Consulta de CNPJ</h4>
                        <div>
                            <label class="block text-[10px] font-black text-slate-300 uppercase mb-1">URL da API de CNPJ</label>
                            <input id="setting-cnpj-url" type="url" class="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3 outline-none font-semibold text-white" placeholder="https://publica.cnpj.ws/cnpj/{cnpj}" />
                            <span class="text-[10px] text-slate-400 mt-1 block">Você pode usar {cnpj} como marcador onde o número será inserido.</span>
                        </div>
                    </div>

                    <button id="btn-save-settings" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-5 rounded-[1.5rem] shadow-xl transition-all active:scale-[0.98]">Salvar Outras Configurações</button>
                </div>
            </div>
        </div>
    `;
}

// Garante visibilidade global
window.getApiBuscaHTML = getApiBuscaHTML;

function setupApiBuscaEvents() {
    loadApifyKeysList();

    const btnSaveKey = document.getElementById('btn-save-apify-key');
    if (btnSaveKey) {
        btnSaveKey.onclick = async function(e) {
            e.preventDefault(); // 💡 Interrompe qualquer comportamento padrão
            e.stopPropagation();

            const labelInput = document.getElementById('apify-key-label');
            const tokenInput = document.getElementById('apify-key-token');
            const btn = document.getElementById('btn-save-apify-key');

            const label = labelInput ? labelInput.value.trim() : '';
            const apiKey = tokenInput ? tokenInput.value.trim() : '';

            if (!apiKey) {
                alert('Por favor, informe a chave de pesquisa.');
                return;
            }

            btn.disabled = true;
            btn.textContent = 'Salvando...';

            try {
                const res = await fetch(API_BASE + 'apify-keys.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({ action: 'create', label: label || 'Chave de pesquisa', api_key: apiKey })
                });
                const data = await res.json();
                
                if (data.success) {
                    if (labelInput) labelInput.value = '';
                    if (tokenInput) tokenInput.value = '';
                    showToast('Chave de pesquisa adicionada com sucesso!');
                    loadApifyKeysList(); // 💡 Atualiza a tabela na mesma hora sem refresh
                } else {
                    alert(data.error || 'Erro ao salvar chave.');
                }
            } catch (err) {
                alert('Erro de conexão: ' + err.message);
            } finally {
                btn.disabled = false;
                btn.textContent = 'Salvar Chave';
            }
        };
    }

    var btnSave = document.getElementById('btn-save-settings');
    if (btnSave) {
        btnSave.onclick = function(e) {
            e.preventDefault();
            saveSettings();
        };
    }
}

async function loadApifyKeysList() {
    const container = document.getElementById('apify-keys-list-container');
    if (!container) return;

    try {
        const res = await fetch(API_BASE + 'apify-keys.php', { credentials: 'include' });
        const data = await res.json();

        if (data.success && Array.isArray(data.data)) {
            if (data.data.length === 0) {
                container.innerHTML = `<p class="text-xs text-slate-500 dark:text-slate-400 text-center py-6 font-bold">Nenhuma chave de pesquisa cadastrada. O sistema usará a chave padrão se houver.</p>`;
                return;
            }

            let html = `
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b border-slate-200 dark:border-slate-600 text-[10px] font-black text-slate-400 uppercase">
                            <th class="py-3 px-4">Identificação</th>
                            <th class="py-3 px-4">Chave Mascarada</th>
                            <th class="py-3 px-4 text-center">Buscas Realizadas</th>
                            <th class="py-3 px-4 text-center">Status</th>
                            <th class="py-3 px-4 text-right">Ações</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200 dark:divide-slate-700 text-xs">
            `;

            data.data.forEach(k => {
                const isActive = k.is_active == 1;
                html += `
                    <tr class="hover:bg-slate-100/50 dark:hover:bg-slate-700/30">
                        <td class="py-3 px-4 font-bold text-slate-800 dark:text-slate-200">${k.label}</td>
                        <td class="py-3 px-4 font-mono text-slate-500">${k.masked_key}</td>
                        <td class="py-3 px-4 text-center font-black text-blue-600 dark:text-blue-400">${k.tokens_used}</td>
                        <td class="py-3 px-4 text-center">
                            <span class="px-2.5 py-1 rounded-full text-[10px] font-bold ${isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}">
                                ${isActive ? 'Ativa' : 'Inativa'}
                            </span>
                        </td>
                        <td class="py-3 px-4 text-right space-x-2">
                            <button onclick="toggleApifyKey('${k.id}', '${isActive ? 0 : 1}')" class="px-3 py-1.5 rounded-lg font-bold ${isActive ? 'bg-amber-100 text-amber-800 hover:bg-amber-200' : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'}">
                                ${isActive ? 'Desativar' : 'Ativar'}
                            </button>
                            <button onclick="deleteApifyKey('${k.id}')" class="px-3 py-1.5 rounded-lg font-bold bg-red-100 text-red-700 hover:bg-red-200">
                                Excluir
                            </button>
                        </td>
                    </tr>
                `;
            });

            html += `</tbody></table>`;
            container.innerHTML = html;
        } else {
            container.innerHTML = `<p class="text-xs text-red-500 text-center py-4">Erro ao carregar lista de chaves.</p>`;
        }
    } catch (e) {
        container.innerHTML = `<p class="text-xs text-red-500 text-center py-4">Erro de conexão.</p>`;
    }
}

async function toggleApifyKey(id, newState) {
    try {
        const res = await fetch(API_BASE + 'apify-keys.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ action: 'toggle', id, is_active: newState })
        });
        const data = await res.json();
        if (data.success) {
            loadApifyKeysList();
        } else {
            alert(data.error || 'Erro ao alterar status.');
        }
    } catch (e) {
        alert('Erro de conexão.');
    }
}

async function deleteApifyKey(id) {
    if (!confirm('Tem certeza que deseja excluir esta chave de pesquisa?')) return;

    try {
        const res = await fetch(API_BASE + 'apify-keys.php', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ id })
        });
        const data = await res.json();
        if (data.success) {
            showToast('Chave removida com sucesso!');
            loadApifyKeysList();
        } else {
            alert(data.error || 'Erro ao excluir chave.');
        }
    } catch (e) {
        alert('Erro de conexão.');
    }
}

// Torna global
window.loadApifyKeysList = loadApifyKeysList;
window.toggleApifyKey = toggleApifyKey;
window.deleteApifyKey = deleteApifyKey;

function loadSettingsForm() {
    var cfg = AppState.config || {};
    var isSuperAdmin = AppState.user && String(AppState.user.profile).toLowerCase() === 'super_admin';

    if (!isSuperAdmin) {
        var tenantNameEl = document.getElementById('setting-tenant-name');
        if (tenantNameEl) {
            tenantNameEl.value = cfg.tenantName || (AppState.tenant && AppState.tenant.name) || '';
        }
        var companyWebhookEl = document.getElementById('setting-company-webhook-url');
        if (companyWebhookEl) {
            companyWebhookEl.value = cfg.companyWebhookUrl || '';
        }
        var personalWebhookEl = document.getElementById('setting-personal-webhook-url');
        if (personalWebhookEl) {
            personalWebhookEl.value = cfg.personalWebhookUrl || cfg.webhookUrl || cfg.baseUrl || '';
        }
        return;
    }
    
    var map = {
        'setting-tenant': cfg.tenantName,
        'setting-url': cfg.atendoWaBaseUrl || cfg.baseUrl || '',
        'setting-atendo-wa-admin-number': cfg.atendoWaAdminNumber || cfg.whatsappAdminNumber || '551731981705'
    };

    Object.keys(map).forEach(function(id) {
        var el = document.getElementById(id);
        if (el && map[id] !== undefined) {
            el.value = map[id] || '';
        }
    });

    var platformWebhookEl = document.getElementById('setting-platform-webhook-url');
    if (platformWebhookEl) {
        platformWebhookEl.value = cfg.platformWebhookUrl || '';
    }

    // Nunca devolve o token completo para o campo do navegador.
    // Exibe apenas a máscara retornada pelo backend e marca o campo para que
    // essa máscara nunca seja enviada como se fosse um novo token.
    var tokenEl = document.getElementById('setting-token');
    if (tokenEl) {
        var maskedToken = cfg.atendoWaTokenMasked || cfg.tokenMasked || '';
        if (maskedToken) {
            tokenEl.value = maskedToken;
            tokenEl.dataset.tokenMasked = 'true';
            tokenEl.placeholder = 'Token configurado — digite um novo para substituir';
            tokenEl.setAttribute('aria-label', 'Token Bearer configurado, exibido de forma mascarada');
        } else {
            tokenEl.value = '';
            tokenEl.dataset.tokenMasked = 'false';
            tokenEl.placeholder = 'Cole um novo token Bearer da API Atendo';
            tokenEl.setAttribute('aria-label', 'Novo token Bearer da API Atendo');
        }
    }
}


function getSettingsHTML() {
    var isSuperAdmin = AppState.user && String(AppState.user.profile).toLowerCase() === 'super_admin';

    if (!isSuperAdmin) {
        var profile = AppState.user ? String(AppState.user.profile).toLowerCase() : '';
        var canEditTenantName = profile === 'admin';
        return `
            <div class="max-w-3xl mx-auto space-y-8 pb-20">
                <div class="bg-white dark:bg-slate-800 p-10 rounded-[2.5rem] border border-slate-200 dark:border-slate-600 shadow-sm">
                    <div class="max-w-2xl">
                        <p class="text-xs font-black tracking-[0.18em] text-blue-600 uppercase mb-3">Integração CRM</p>
                        <h3 class="text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight">${canEditTenantName ? 'Empresa e integração' : 'Meu webhook pessoal'}</h3>
                        <p class="text-sm leading-6 text-slate-500 dark:text-slate-300 mt-3">${canEditTenantName ? 'O webhook geral é usado pelos membros sem webhook pessoal. Cada pessoa pode configurar uma URL própria, que sempre terá prioridade.' : 'Defina a URL que receberá somente as suas exportações. Se deixá-la vazia, o sistema usa o webhook geral da empresa e, em último caso, o da plataforma.'}</p>
                    </div>
                    ${canEditTenantName ? `
                    <div class="mt-8 bg-slate-50 dark:bg-slate-700/60 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600">
                        <label for="setting-tenant-name" class="block text-[10px] font-black text-slate-500 dark:text-slate-300 uppercase mb-2 ml-1">Nome da empresa</label>
                        <input id="setting-tenant-name" type="text" maxlength="120" class="w-full bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-2xl px-6 py-4 outline-none focus:border-blue-500 font-bold placeholder-slate-400 dark:placeholder-slate-500 ${canEditTenantName ? '' : 'opacity-70 cursor-not-allowed'}" placeholder="Nome da sua empresa" ${canEditTenantName ? '' : 'readonly aria-readonly="true"'}>
                        <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-3">${canEditTenantName ? 'Esse nome será exibido no painel da sua empresa.' : 'Somente o administrador da empresa pode alterar este nome.'}</p>
                    </div>
                    <div class="mt-8 bg-slate-50 dark:bg-slate-700/60 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600">
                        <label for="setting-company-webhook-url" class="block text-[10px] font-black text-slate-500 dark:text-slate-300 uppercase mb-2 ml-1">Webhook geral da empresa</label>
                        <input id="setting-company-webhook-url" type="url" autocomplete="url" class="w-full bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-2xl px-6 py-4 outline-none focus:border-blue-500 font-bold placeholder-slate-400 dark:placeholder-slate-500" placeholder="https://sua-plataforma.com/webhooks/leads">
                        <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-3">Usado como padrão pela empresa quando o usuário que exporta não possuir um webhook pessoal configurado.</p>
                    </div>
                    ` : ''}
                    <div class="mt-8 bg-slate-50 dark:bg-slate-700/60 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600">
                        <label for="setting-personal-webhook-url" class="block text-[10px] font-black text-slate-500 dark:text-slate-300 uppercase mb-2 ml-1">Meu webhook pessoal</label>
                        <input id="setting-personal-webhook-url" type="url" autocomplete="url" class="w-full bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-2xl px-6 py-4 outline-none focus:border-blue-500 font-bold placeholder-slate-400 dark:placeholder-slate-500" placeholder="https://sua-plataforma.com/webhooks/meus-leads">
                        <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-3">Tem prioridade sobre o webhook da empresa e sobre o padrão da plataforma. Deixe vazio para usar automaticamente os níveis de fallback.</p>
                    </div>
                    <div class="mt-6">
                        <button id="btn-save-settings" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-5 rounded-[1.5rem] shadow-xl shadow-blue-100 dark:shadow-blue-900/30 transition-all active:scale-[0.98]">Salvar configurações</button>
                    </div>
                </div>
            </div>
        `;
    }
    
    return `
        <div class="max-w-3xl mx-auto space-y-8 pb-20">
            <div class="bg-white dark:bg-slate-800 p-10 rounded-[2.5rem] border border-slate-200 dark:border-slate-600 shadow-sm">
                <h3 class="text-2xl font-black text-slate-900 dark:text-slate-100 mb-8 tracking-tight">Configurações de Conexão</h3>
                <div class="space-y-8">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-[10px] font-black text-slate-400 dark:text-slate-300 uppercase mb-2 ml-1">Nome da Instância / Empresa</label>
                            <input id="setting-tenant" type="text" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-2xl px-6 py-4 outline-none focus:border-blue-500 font-bold placeholder-slate-400 dark:placeholder-slate-500" placeholder="Nome da empresa SaaS">
                        </div>
                    </div>

                    <div class="bg-slate-50 dark:bg-slate-700/60 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600 space-y-5">
                        <div>
                            <h4 class="font-black text-lg text-slate-900 dark:text-slate-100">WhatsApp — API Atendo</h4>
                            <p class="text-xs text-slate-500 dark:text-slate-300 mt-1">Configure a conexão usada para as notificações da plataforma. O token nunca deve ser colocado no frontend ou em mensagens de teste.</p>
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-slate-500 dark:text-slate-300 uppercase mb-2 ml-1">URL da API Atendo</label>
                            <input id="setting-url" type="url" autocomplete="url" class="w-full bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-2xl px-6 py-4 outline-none focus:border-blue-500 font-bold placeholder-slate-400 dark:placeholder-slate-500" placeholder="https://off.atendo.log.br/v1/api/external/...">
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-slate-500 dark:text-slate-300 uppercase mb-2 ml-1">Token Bearer da API Atendo</label>
                            <div class="flex gap-3">
                                <input id="setting-token" type="password" autocomplete="new-password" class="min-w-0 flex-1 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-2xl px-6 py-4 outline-none focus:border-blue-500 font-bold placeholder-slate-400 dark:placeholder-slate-500" placeholder="Cole um novo token Bearer da API Atendo">
                                <button id="btn-toggle-atendo-token" type="button" class="px-5 rounded-2xl border border-slate-200 dark:border-slate-600 text-slate-600 dark:text-slate-200 font-bold hover:bg-white dark:hover:bg-slate-800" aria-label="Mostrar ou ocultar token">Mostrar</button>
                            </div>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-2">Deixe vazio para manter o token atual. O valor salvo deve ser exibido apenas de forma mascarada.</p>
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-slate-500 dark:text-slate-300 uppercase mb-2 ml-1">Número administrativo para alertas</label>
                            <input id="setting-atendo-wa-admin-number" type="tel" autocomplete="tel" class="w-full bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-2xl px-6 py-4 outline-none focus:border-blue-500 font-bold placeholder-slate-400 dark:placeholder-slate-500" placeholder="551731981705">
                        </div>
                    </div>

                    <div class="bg-slate-50 dark:bg-slate-700/60 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-600 space-y-3">
                        <div>
                            <h4 class="font-black text-lg text-slate-900 dark:text-slate-100">Webhook padrão da plataforma</h4>
                            <p class="text-xs text-slate-500 dark:text-slate-300 mt-1">Último nível de fallback. Ele é utilizado apenas quando o usuário que exporta e a empresa dele não tiverem um webhook configurado.</p>
                        </div>
                        <div>
                            <label for="setting-platform-webhook-url" class="block text-[10px] font-black text-slate-500 dark:text-slate-300 uppercase mb-2 ml-1">URL padrão do webhook</label>
                            <input id="setting-platform-webhook-url" type="url" autocomplete="url" class="w-full bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-2xl px-6 py-4 outline-none focus:border-blue-500 font-bold placeholder-slate-400 dark:placeholder-slate-500" placeholder="https://sua-plataforma.com/webhooks/padrao">
                        </div>
                    </div>

                    ${isSuperAdmin ? `
                    <!-- CAIXA DA INFINITEPAY -->
                    <div class="bg-[#0F172A] p-6 rounded-[2rem] border border-slate-800 text-white space-y-4">
                        <h4 class="font-black text-lg text-emerald-400 flex items-center gap-2">💳 Gateway de Recebimento (InfinitePay)</h4>
                        <div class="space-y-3">
                            <div>
                                <label class="block text-[10px] font-black text-slate-300 uppercase mb-1">Usuário / $Handle InfinitePay</label>
                                <input id="saas-config-infinite-handle" type="text" class="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3 outline-none focus:border-emerald-500 font-bold text-white text-xs" placeholder="Ex: seunome" />
                            </div>
                            <div>
                                <label class="block text-[10px] font-black text-slate-300 uppercase mb-1">Chave de API / Token InfinitePay</label>
                                <input id="saas-config-infinite-key" type="password" class="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3 outline-none focus:border-emerald-500 font-bold text-white text-xs" placeholder="Token de API" />
                            </div>
                        </div>
                    </div>
                    ` : ''}

                    <div class="mt-6">
                        <button id="btn-save-settings" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-5 rounded-[1.5rem] shadow-xl shadow-blue-100 dark:shadow-blue-900/30 transition-all active:scale-[0.98]">Salvar Alterações</button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function setupSettingsEvents() {
    var btnSave = document.getElementById('btn-save-settings');
    if (btnSave) {
        btnSave.onclick = function() {
            saveSettings();
        };
    }

    var toggleTokenBtn = document.getElementById('btn-toggle-atendo-token');
    var tokenInput = document.getElementById('setting-token');
    if (toggleTokenBtn && tokenInput) {
        tokenInput.oninput = function() {
            // Qualquer edição transforma o conteúdo em um novo segredo.
            tokenInput.dataset.tokenMasked = 'false';
        };
        toggleTokenBtn.onclick = function() {
            var isHidden = tokenInput.type === 'password';
            tokenInput.type = isHidden ? 'text' : 'password';
            toggleTokenBtn.textContent = isHidden ? 'Ocultar' : 'Mostrar';
        };
    }
}

async function saveSettings() {
    const btn = document.getElementById('btn-save-settings');
    if (!btn) return;

    btn.disabled = true;
    btn.textContent = 'Salvando...';
    
    var isSuperAdmin = AppState.user && String(AppState.user.profile).toLowerCase() === 'super_admin';

    if (!isSuperAdmin) {
        var profile = AppState.user ? String(AppState.user.profile).toLowerCase() : '';
        var personalWebhookEl = document.getElementById('setting-personal-webhook-url');
        var personalWebhookUrl = personalWebhookEl ? personalWebhookEl.value.trim() : '';
        var tenantNameEl = document.getElementById('setting-tenant-name');
        var payload = { personalWebhookUrl: personalWebhookUrl };
        if (profile === 'admin') {
            var companyWebhookEl = document.getElementById('setting-company-webhook-url');
            payload.companyWebhookUrl = companyWebhookEl ? companyWebhookEl.value.trim() : '';
        }
        if (tenantNameEl && !tenantNameEl.readOnly) {
            payload.tenantName = tenantNameEl.value.trim();
        }

        try {
            const res = await fetch(API_BASE + 'settings.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(payload)
            });
            const data = await res.json();
            if (data.success) {
                showToast(profile === 'admin' ? 'Configurações da empresa salvas com sucesso.' : 'Webhook pessoal salvo com sucesso.');
                await loadConfig();
            } else {
                alert('Erro ao salvar: ' + (data.error || 'Erro desconhecido'));
            }
        } catch (e) {
            alert('Erro de conexão: ' + e.message);
        } finally {
            btn.disabled = false;
            btn.textContent = 'Salvar configurações';
        }
        return;
    }
    
    var urlEl = document.getElementById('setting-url');
    var tokenEl = document.getElementById('setting-token');
    var tenantEl = document.getElementById('setting-tenant');
    
    var tokenValue = tokenEl ? tokenEl.value.trim() : '';
    var tokenIsMasked = tokenEl && tokenEl.dataset.tokenMasked === 'true';
    var adminNumberEl = document.getElementById('setting-atendo-wa-admin-number');
    var platformWebhookEl = document.getElementById('setting-platform-webhook-url');
    var payload = {
        baseUrl: urlEl ? urlEl.value.trim() : '',
        tenantName: tenantEl ? tenantEl.value.trim() : 'Nome da empresa SaaS',
        atendoWaAdminNumber: adminNumberEl ? adminNumberEl.value.trim() : '',
        platformWebhookUrl: platformWebhookEl ? platformWebhookEl.value.trim() : ''
    };

    // Só envia token quando o administrador digitou um novo segredo.
    // Assim, deixar o campo vazio não apaga o token já armazenado no backend.
    if (tokenValue && !tokenIsMasked) payload.token = tokenValue;

    if (isSuperAdmin) {
        var scraperEl = document.getElementById('setting-scraper-api');
        var openrouterEl = document.getElementById('setting-openrouter-api');
        var mapboxEl = document.getElementById('setting-mapbox-token');
        var cnpjUrlEl = document.getElementById('setting-cnpj-url');

        payload.scraperApiKey = scraperEl ? scraperEl.value.trim() : '';
        payload.openrouterApiKey = openrouterEl ? openrouterEl.value.trim() : '';
        payload.mapboxAccessToken = mapboxEl ? mapboxEl.value.trim() : '';
        payload.cnpjApiUrl = cnpjUrlEl ? cnpjUrlEl.value.trim() : '';
    }

    try {
        const res = await fetch(API_BASE + 'settings.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        
        if (data.success) {
            showToast('Configurações de conexão salvas!');
            loadConfig();
        } else {
            alert('Erro ao salvar: ' + (data.error || 'Erro desconhecido'));
        }
    } catch (e) {
        alert('Erro de conexão: ' + e.message);
    } finally {
        btn.disabled = false;
        btn.textContent = 'Salvar Alterações';
    }
}

// Carrega APENAS os municípios da hospedagem. 
// Os CNAEs serão consultados na VPS via Proxy PHP para segurança e performance.
async function loadLocalDatabase() {
    if (!AppState.localData) {
        AppState.localData = { municipios: [], loaded: false };
    }
    if (AppState.localData.loaded) return;
    
    try {
        const resMun = await fetch('data/municipios.json').then(r => r.json());
        
        if (resMun && resMun.resultados) {
            AppState.localData.municipios = resMun.resultados.map(m => ({
                codigo: m.codigo,
                descricao_norm: m.descricao.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim(),
                descricao: m.descricao
            }));
        }
        AppState.localData.loaded = true;
    } catch (e) {
        console.error("Erro ao carregar base de municípios:", e);
        AppState.localData.loaded = true; 
    }
}

// Inicializa a Busca Avançada
function setupCnpjAdvancedEvents() {
    loadLocalDatabase();
}

function showError(message) {
    const errorDiv = document.getElementById('error-info');
    if (errorDiv) {
        errorDiv.classList.remove('hidden');
        errorDiv.innerHTML = `<div class="flex items-center gap-3"><p class="text-xs font-bold">${message}</p></div>`;
    }
}

function hideError() {
    const errorDiv = document.getElementById('error-info');
    if (errorDiv) errorDiv.classList.add('hidden');
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    const toastMsg = document.getElementById('toast-message');
    if (!toast) return;
    toastMsg.textContent = message;
    toast.classList.remove('hidden', 'bg-green-600', 'bg-amber-500', 'bg-red-600');
    toast.classList.add(type === 'warning' ? 'bg-amber-500' : type === 'error' ? 'bg-red-600' : 'bg-green-600');
    setTimeout(() => toast.classList.add('hidden'), 4000);
}

// Listener Global de Cliques e Fechamento de Menus
document.addEventListener('click', function(e) {
    const btnTab = e.target.closest('.tab-btn');
    if (btnTab && btnTab.dataset.tab) setActiveTab(btnTab.dataset.tab);

    const item = e.target.closest('.cnae-item');
    const menu = document.getElementById('cnae-suggestions');
    if (item && menu) {
        document.getElementById('adv-segment').value = item.dataset.desc;
        document.getElementById('selected-cnae-code').value = item.dataset.code;
        menu.style.display = 'none';
    } else if (menu && !e.target.closest('#adv-segment')) {
        menu.style.display = 'none';
    }
});

// Renderiza a interface da Consulta CNPJ (Simples por Número de CNPJ)
function renderCnpjLookupTab(contentArea) {
    if (!contentArea) return;

    contentArea.innerHTML = `
        <div class="max-w-4xl mx-auto pb-20">
            <div class="bg-white dark:bg-slate-800 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm mb-8">
                <h3 class="text-xl font-black text-slate-900 dark:text-slate-100 mb-2">Consulta Avançada de CNPJ</h3>
                <p class="text-xs text-slate-500 dark:text-slate-400 mb-6">Digite um CNPJ para buscar as informações completas da empresa diretamente na base local.</p>
                
                <div class="flex flex-col sm:flex-row gap-4">
                    <div class="flex-1">
                        <label class="block text-[10px] font-black text-slate-400 uppercase mb-1 ml-1">Número do CNPJ</label>
                        <input id="cnpj-simple-input" type="text" maxlength="18" class="w-full px-5 py-3 rounded-xl bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 focus:border-blue-500 outline-none font-bold text-sm" placeholder="00.000.000/0001-00">
                    </div>
                    <div class="flex items-end">
                        <button id="btn-cnpj-simple-search" type="button" onclick="performCnpjSimpleLookup()" class="w-full sm:w-auto px-8 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-black rounded-xl transition-all shadow-lg shadow-blue-600/30 uppercase tracking-wider text-xs flex justify-center items-center gap-2">
                            Consultar CNPJ
                        </button>
                    </div>
                </div>
            </div>

            <!-- Resultado da Consulta -->
            <div id="cnpj-simple-result" class="hidden"></div>
        </div>
    `;

    // Adiciona evento de apertar ENTER no campo de busca
    const input = document.getElementById('cnpj-simple-input');
    if (input) {
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') performCnpjSimpleLookup();
        });
    }
}

async function performCnpjSimpleLookup() {
    const input = document.getElementById('cnpj-simple-input');
    const resultDiv = document.getElementById('cnpj-simple-result');
    const btn = document.getElementById('btn-cnpj-simple-search');

    const cnpj = input ? input.value.replace(/[^0-9]/g, '') : '';

    if (!cnpj || cnpj.length !== 14) {
        alert('Por favor, digite um CNPJ válido com 14 dígitos.');
        return;
    }

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<span class="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span> Consultando...';
    }

    if (resultDiv) {
        resultDiv.classList.remove('hidden');
        resultDiv.innerHTML = '<div class="py-12 text-center text-slate-500 font-bold">Realizando Consulta de inforações</div>';
    }

    try {
        const res = await fetch(API_BASE + 'cnpj-advanced-search.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ cnae: '', municipio: '', uf: '', cnpj: cnpj })
        });

        const data = await res.json();

        if (data.success && data.data && data.data.length > 0) {
            const emp = data.data[0];

            resultDiv.innerHTML = `
                <div class="bg-white dark:bg-slate-800 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm space-y-6">
                    <div class="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-700 pb-4">
                        <div>
                            <span class="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-3 py-1 rounded-full uppercase">${emp.situation || 'ATIVA'}</span>
                            <h3 class="text-xl font-black text-slate-900 dark:text-slate-100 mt-2">${emp.name}</h3>
                            ${emp.tradeName ? `<p class="text-xs text-slate-500 font-bold">Nome Fantasia: ${emp.tradeName}</p>` : ''}
                        </div>
                        <div class="text-right">
                            <p class="text-xs font-mono font-bold text-slate-400">CNPJ</p>
                            <p class="text-base font-black text-slate-800 dark:text-slate-200">${emp.cnpj}</p>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-3">
                            <p class="text-xs text-slate-500 dark:text-slate-400">📌 <strong>CNAE Principal:</strong> <span class="text-slate-800 dark:text-slate-200 font-bold">${emp.cnae_codigo} - ${emp.cnae_descricao}</span></p>
                            <p class="text-xs text-slate-500 dark:text-slate-400">📞 <strong>Telefone:</strong> <span class="text-slate-800 dark:text-slate-200 font-bold">${emp.phone || 'Não informado'}</span></p>
                            <p class="text-xs text-slate-500 dark:text-slate-400">✉️ <strong>E-mail:</strong> <span class="text-slate-800 dark:text-slate-200 font-bold">${emp.email || 'Não informado'}</span></p>
                            <p class="text-xs text-slate-500 dark:text-slate-400">🗓️ <strong>Abertura:</strong> <span class="text-slate-800 dark:text-slate-200 font-bold">${emp.data_abertura || 'N/A'}</span></p>
                        </div>
                        <div class="space-y-3">
                            <p class="text-xs text-slate-500 dark:text-slate-400">📍 <strong>Endereço:</strong> <span class="text-slate-800 dark:text-slate-200 font-bold">${emp.address}</span></p>
                            <p class="text-xs text-slate-500 dark:text-slate-400">💰 <strong>Capital Social:</strong> <span class="text-slate-800 dark:text-slate-200 font-bold">R$ ${parseFloat(emp.capital).toLocaleString('pt-BR')}</span></p>
                            <p class="text-xs text-slate-500 dark:text-slate-400">👥 <strong>Sócios:</strong> <span class="text-slate-800 dark:text-slate-200 font-bold">${emp.socios || 'Não informado'}</span></p>
                        </div>
                    </div>
                </div>
            `;
        } else {
            resultDiv.innerHTML = `
                <div class="p-8 text-center bg-amber-50 dark:bg-amber-900/20 text-amber-800 dark:text-amber-400 rounded-2xl border border-amber-200 dark:border-amber-800 font-bold text-sm">
                    CNPJ não encontrado na base pública.
                </div>
            `;
        }
    } catch (e) {
        if (resultDiv) {
            resultDiv.innerHTML = `<div class="p-6 text-center text-red-600 font-bold text-sm">Erro ao consultar CNPJ: ${e.message}</div>`;
        }
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = 'Consultar CNPJ';
        }
    }
}
// Garante visibilidade no escopo global
window.renderCnpjLookupTab = renderCnpjLookupTab;
window.performCnpjSimpleLookup = performCnpjSimpleLookup;

// Renderiza a interface da Busca Avançada por Segmento / CNAE
function renderCnpjAdvancedTab(contentArea) {
    contentArea.innerHTML = `
        <div class="max-w-6xl mx-auto pb-20">
            <div class="bg-white dark:bg-slate-800 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm mb-8">
                <h3 class="text-xl font-black text-slate-900 dark:text-slate-100 mb-6">Busca por Segmento (CNAE)</h3>
                
                <div class="grid grid-cols-1 md:grid-cols-12 gap-4 relative">
                    <!-- Campo Segmento com Autocomplete -->
                    <div class="md:col-span-5 relative">
                        <label class="block text-[10px] font-black text-slate-400 uppercase mb-1 ml-1">Segmento / Atividade (CNAE)</label>
                        <input id="adv-segment" type="text" class="w-full px-5 py-3 rounded-xl bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 focus:border-blue-500 outline-none font-bold text-sm" placeholder="Ex: Mercado, Padaria, TI...">
                        <input type="hidden" id="selected-cnae-code">
                        
                        <!-- Dropdown de Sugestões CNAE -->
                        <div id="cnae-suggestions" class="absolute left-0 right-0 top-full mt-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-600 rounded-2xl shadow-2xl z-50 max-h-60 overflow-y-auto hidden"></div>
                    </div>

                    <!-- UF / Estado -->
                    <div class="md:col-span-2">
                        <label class="block text-[10px] font-black text-slate-400 uppercase mb-1 ml-1">UF</label>
                        <input id="adv-uf" type="text" maxlength="2" class="w-full px-5 py-3 rounded-xl bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 focus:border-blue-500 outline-none font-bold text-sm uppercase" placeholder="SP">
                    </div>

                    <!-- Município -->
                    <div class="md:col-span-3">
                        <label class="block text-[10px] font-black text-slate-400 uppercase mb-1 ml-1">Cidade / Município</label>
                        <input id="adv-city" type="text" class="w-full px-5 py-3 rounded-xl bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 focus:border-blue-500 outline-none font-bold text-sm" placeholder="Ex: São Paulo">
                    </div>

                    <!-- Botão de Busca -->
                    <div class="md:col-span-2 flex items-end">
                        <button id="btn-adv-search" type="button" onclick="performCnpjAdvancedSearch()" class="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-black rounded-xl transition-all shadow-lg shadow-blue-600/30 uppercase tracking-wider text-xs flex justify-center items-center gap-2">
                            Buscar
                        </button>
                    </div>
                </div>
            </div>

            <!-- Header dos Resultados -->
            <div id="adv-results-header" class="hidden mb-6 flex justify-between items-center px-2">
                <h4 class="text-lg font-black text-slate-900 dark:text-slate-100">Empresas Encontradas (<span id="adv-total-count">0</span>)</h4>
            </div>

            <!-- Grid de Resultados -->
            <div id="adv-results-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"></div>
        </div>
    `;

    setupCnpjAdvancedEvents();
}


// Executa a consulta na API local via Proxy
async function performCnpjAdvancedSearch() {
    const cnae = document.getElementById('selected-cnae-code')?.value || document.getElementById('adv-segment')?.value || '';
    const uf = document.getElementById('adv-uf')?.value.trim() || '';
    const municipio = document.getElementById('adv-city')?.value.trim() || '';
    const btn = document.getElementById('btn-adv-search');
    const grid = document.getElementById('adv-results-grid');
    const header = document.getElementById('adv-results-header');
    const totalCount = document.getElementById('adv-total-count');

    if (!cnae && !municipio) {
        alert('Por favor, informe ao menos um segmento ou cidade para pesquisar.');
        return;
    }

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<span class="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span> Buscando...';
    }

    try {
        const res = await fetch(API_BASE + 'cnpj-advanced-search.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cnae, uf, municipio })
        });

        const data = await res.json();

        if (data.success && data.data && data.data.length > 0) {
            header.classList.remove('hidden');
            totalCount.textContent = data.data.length;

            grid.innerHTML = data.data.map(empresa => `
                <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-600 shadow-sm hover:shadow-md transition">
                    <div class="flex items-center justify-between mb-3">
                        <span class="bg-blue-100 text-blue-800 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase">${empresa.situation}</span>
                        <span class="text-[10px] font-mono text-slate-400">${empresa.cnpj}</span>
                    </div>
                    <h4 class="font-extrabold text-slate-900 dark:text-slate-100 text-sm mb-2 line-clamp-1" title="${empresa.name}">${empresa.name}</h4>
                    <p class="text-xs text-blue-600 dark:text-blue-400 font-bold mb-4 line-clamp-1">📌 ${empresa.cnae_codigo} - ${empresa.cnae_descricao}</p>
                    
                    <div class="space-y-2 text-xs text-slate-600 dark:text-slate-400 border-t border-slate-100 dark:border-slate-700 pt-3">
                        <p>📞 <strong>Tel:</strong> ${empresa.phone || 'Não informado'}</p>
                        <p>✉️ <strong>Email:</strong> ${empresa.email || 'Não informado'}</p>
                        <p class="line-clamp-2">📍 <strong>Endereço:</strong> ${empresa.address}</p>
                    </div>
                </div>
            `).join('');
        } else {
            header.classList.add('hidden');
            grid.innerHTML = `
                <div class="col-span-full py-16 text-center bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-600">
                    <p class="text-slate-400 font-bold text-sm">Nenhuma empresa encontrada com os filtros informados.</p>
                </div>
            `;
        }
    } catch (e) {
        alert('Erro ao realizar a busca avançada: ' + e.message);
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = 'Buscar';
        }
    }
}
// Função para abrir e fechar submenus na sidebar
function toggleSubmenu(elementOrId) {
    var submenu = null;

    if (typeof elementOrId === 'string') {
        submenu = document.getElementById(elementOrId);
    } else if (elementOrId && elementOrId.nodeType) {
        // Se foi passado o 'this' (botão), procura o próximo elemento ou submenu filho
        var parent = elementOrId.parentElement;
        submenu = parent ? parent.querySelector('.submenu, [id*="submenu"], ul, div') : null;
    }

    if (submenu) {
        submenu.classList.toggle('hidden');
    } else if (elementOrId && elementOrId.classList) {
        elementOrId.classList.toggle('hidden');
    }
}

// Garante que a função fique visível globalmente para o HTML
window.toggleSubmenu = toggleSubmenu;

// Listener de Digitação: Consulta a VPS em Tempo Real via Proxy PHP
var cnaeTimeoutDelay = null; 
document.addEventListener('input', function(e) {
    if (e.target.id === 'adv-segment') {
        const input = e.target;
        const menu = document.getElementById('cnae-suggestions');
        const termo = input.value.trim();

        if (termo.length < 2) {
            if (menu) menu.style.display = 'none';
            return;
        }

        clearTimeout(cnaeTimeoutDelay);
        cnaeTimeoutDelay = setTimeout(async () => {
            try {
                // MÁGICA: Em vez de bater na VPS (que causa bloqueio de HTTPS), 
                // bate no seu arquivo PHP interno, que faz o trabalho sujo.
                const res = await fetch(API_BASE + `cnae-search.php?q=${encodeURIComponent(termo)}`);
                const data = await res.json();
                
                const resultados = data.resultados || data.data || (Array.isArray(data) ? data : []);

                if (resultados.length > 0 && menu) {
                    menu.innerHTML = resultados.map(c => {
                        const codigo = c.codigo_cnae || c.codigo || c.id || '';
                        const descricao = c.descricao_cnae || c.descricao || c.name || '';
                        
                        return `
                        <div class="cnae-item" data-code="${codigo}" data-desc="${descricao}" 
                             style="padding: 12px; border-bottom: 1px solid #eee; cursor: pointer; color: #333; font-size: 13px;">
                            <b style="color: #7c3aed;">${codigo}</b> - ${descricao}
                        </div>
                        `;
                    }).join('');
                    menu.style.display = 'block';
                } else if (menu) {
                    menu.innerHTML = '<div style="padding: 12px; color: #666; font-size: 12px;">Nenhum segmento encontrado.</div>';
                    menu.style.display = 'block';
                }
            } catch (err) {
                console.error("Erro ao consultar a API de CNAE via Proxy PHP:", err);
            }
        }, 300);
    }
});

// ==========================================
// FUNÇÕES QUE FALTAVAM (Aba Equipe e Outras)
// ==========================================

// Renderiza a aba 'Minha Equipe'
function renderTeamTab(contentArea) {
    if (!contentArea) return;
    
    const profile = String(AppState.user?.profile || '').toLowerCase();
    const canManageTeam = profile === 'admin' || profile === 'super_admin' || profile === 'supervisor' || profile === 'manager' || profile === 'gerente';

    contentArea.innerHTML = `
        <div class="max-w-5xl mx-auto space-y-6 pb-20">
            <div class="flex justify-between items-center flex-wrap gap-4">
                <div>
                    <h3 class="text-2xl font-black text-slate-900 dark:text-slate-100">Minha Equipe</h3>
                    <p class="text-sm text-slate-500 dark:text-slate-400">Gerencie os acessos e cargos da sua equipe.</p>
                </div>
                ${canManageTeam ? `
                <button type="button" id="btn-open-team-modal" onclick="showAddTeamMemberModal()" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-5 py-3 rounded-2xl text-xs flex items-center gap-2 shadow-lg shadow-blue-600/20">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-width="2.5" d="M12 4v16m8-8H4"/></svg>
                    Novo Funcionário
                </button>
                ` : ''}
            </div>

            <div id="team-list-container" class="bg-white dark:bg-slate-800 rounded-[2rem] border border-slate-200 dark:border-slate-600 p-6 shadow-sm">
                <div class="py-12 text-center">
                    <span class="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin inline-block"></span>
                    <p class="mt-3 text-sm font-bold text-slate-500 dark:text-slate-400">Carregando equipe...</p>
                </div>
            </div>
        </div>
    `;
    
    loadTeamMembers();
}
// Modal para Cadastrar Funcionário
function showAddTeamMemberModal() {
    const existingModal = document.getElementById('modal-add-team-member');
    if (existingModal) existingModal.remove();

    const overlay = document.createElement('div');
    overlay.id = 'modal-add-team-member';
    overlay.className = 'fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4';
    overlay.innerHTML = `
        <div class="bg-white dark:bg-slate-800 rounded-[2rem] shadow-2xl p-8 max-w-md w-full" onclick="event.stopPropagation()">
            <h4 class="text-xl font-black text-slate-900 dark:text-slate-100 mb-6">Cadastrar Funcionário</h4>
            
            <form id="form-add-team-member" class="space-y-4">
                <div>
                    <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Nome Completo</label>
                    <input type="text" id="team-user-name" required placeholder="Ex: Maria Silva" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium">
                </div>
                
                <div>
                    <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">E-mail</label>
                    <input type="email" id="team-user-email" required placeholder="maria@empresa.com" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium">
                </div>

                <!-- 💡 NOVO: Campo de Telefone / WhatsApp -->
                <div>
                    <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">WhatsApp / Telefone</label>
                    <input type="text" id="team-user-phone" placeholder="Ex: 11999999999" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium">
                </div>

                <div>
                    <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Senha Inicial</label>
                    <input type="password" id="team-user-password" required minlength="6" placeholder="Mínimo 6 caracteres" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium">
                </div>

                <div>
                    <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Cargo / Nível de Acesso</label>
                    <select id="team-user-profile" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-bold">
                        <option value="user">Usuário (Consulta e Histórico próprio)</option>
                        <option value="supervisor">Supervisor (Consulta, Histórico geral e Equipe)</option>
                        <option value="admin">Administrador (Acesso Total)</option>
                    </select>
                </div>

                <p id="team-member-error" class="text-red-600 text-xs font-bold hidden"></p>

                <div class="flex gap-3 pt-4">
                    <button type="button" onclick="document.getElementById('modal-add-team-member').remove()" class="flex-1 py-3 rounded-xl border border-slate-200 dark:border-slate-600 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700">Cancelar</button>
                    <button type="submit" id="btn-save-team-member" class="flex-1 py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700">Salvar</button>
                </div>
            </form>
        </div>
    `;

    document.body.appendChild(overlay);

    document.getElementById('form-add-team-member').onsubmit = async function(e) {
        e.preventDefault();
        const name = document.getElementById('team-user-name').value.trim();
        const email = document.getElementById('team-user-email').value.trim().toLowerCase();
        const phone = document.getElementById('team-user-phone').value.trim(); // 💡 Captura o telefone
        const password = document.getElementById('team-user-password').value;
        const profile = document.getElementById('team-user-profile').value;
        const errEl = document.getElementById('team-member-error');
        const btn = document.getElementById('btn-save-team-member');

        errEl.classList.add('hidden');
        btn.disabled = true;
        btn.textContent = 'Salvando...';

        try {
            const res = await fetch(API_BASE + 'users.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ name, email, phone, password, profile }) // 💡 Envia o telefone no JSON
            });

            const data = await res.json();
            if (data.success) {
                overlay.remove();
                showToast('Funcionário cadastrado com sucesso!');
                loadTeamMembers();
            } else {
                errEl.textContent = data.error || 'Erro ao cadastrar funcionário.';
                errEl.classList.remove('hidden');
            }
        } catch (err) {
            errEl.textContent = 'Erro de conexão com o servidor.';
            errEl.classList.remove('hidden');
        } finally {
            btn.disabled = false;
            btn.textContent = 'Salvar';
        }
    };
}
// Carrega a lista de usuários da equipe
async function loadTeamMembers() {
    const container = document.getElementById('team-list-container');
    if (!container) return;
    
    try {
        const res = await fetch(API_BASE + 'users.php', { credentials: 'include' });
        const data = await res.json();
        
        if (data.success && Array.isArray(data.data)) {
            if (data.data.length === 0) {
                container.innerHTML = `<div class="py-12 text-center text-slate-400 font-bold text-sm">Nenhum funcionário cadastrado.</div>`;
                return;
            }

            const currentProfile = String(AppState.user?.profile || '').toLowerCase();
            const canManageMembers = ['super_admin', 'admin', 'supervisor', 'manager', 'gerente'].includes(currentProfile);
            
            const roleBadges = {
                super_admin: '<span class="bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300 px-3 py-1 rounded-full text-xs font-black">Super Admin</span>',
                admin: '<span class="bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 px-3 py-1 rounded-full text-xs font-black">Administrador</span>',
                supervisor: '<span class="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 px-3 py-1 rounded-full text-xs font-black">Supervisor</span>',
                manager: '<span class="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 px-3 py-1 rounded-full text-xs font-black">Supervisor</span>',
                user: '<span class="bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300 px-3 py-1 rounded-full text-xs font-black">Usuário</span>',
                usuario: '<span class="bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300 px-3 py-1 rounded-full text-xs font-black">Usuário</span>'
            };

            let html = '<div class="space-y-3">';
            data.data.forEach(user => {
                const profileKey = String(user.profile || 'user').toLowerCase();
                const badge = roleBadges[profileKey] || roleBadges.user;
                const escapedUser = encodeURIComponent(JSON.stringify(user));
                
                html += `
                    <div class="p-5 rounded-2xl border border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/50 flex items-center justify-between flex-wrap gap-4">
                        <div class="flex items-center gap-4">
                            <div class="w-10 h-10 rounded-xl bg-blue-600 text-white font-black flex items-center justify-center text-sm uppercase">
                                ${(user.name || 'U').charAt(0)}
                            </div>
                            <div>
                                <h4 class="font-extrabold text-slate-900 dark:text-slate-100 text-sm">${user.name || 'Sem nome'}</h4>
                                <p class="text-xs text-slate-500 dark:text-slate-400 font-medium">${user.email} ${user.phone ? '· ' + user.phone : ''}</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-3">
                            ${badge}
                            ${canManageMembers ? `
                            <button type="button" onclick="showEditTeamMemberModal('${escapedUser}')" class="bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 px-3 py-1.5 rounded-xl text-xs font-bold transition">Editar</button>
                            <button type="button" onclick="deleteTeamMember('${user.id}')" class="bg-red-100 hover:bg-red-200 text-red-700 px-3 py-1.5 rounded-xl text-xs font-bold transition">Excluir</button>
                            ` : ''}
                        </div>
                    </div>
                `;
            });
            html += '</div>';
            container.innerHTML = html;
        } else {
            container.innerHTML = `<div class="py-8 text-center text-amber-600 font-bold text-sm">${data.error || 'Erro ao carregar equipe.'}</div>`;
        }
    } catch (e) {
        container.innerHTML = `<div class="py-8 text-center text-red-500 font-bold text-sm">Erro de conexão ao carregar equipe.</div>`;
    }
}
// Modal para Editar Funcionário
// Modal para Editar Funcionário
function showEditTeamMemberModal(encodedUser) {
    const user = JSON.parse(decodeURIComponent(encodedUser));
    const existingModal = document.getElementById('modal-edit-team-member');
    if (existingModal) existingModal.remove();

    const overlay = document.createElement('div');
    overlay.id = 'modal-edit-team-member';
    overlay.className = 'fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4';
    overlay.innerHTML = `
        <div class="bg-white dark:bg-slate-800 rounded-[2rem] shadow-2xl p-8 max-w-md w-full" onclick="event.stopPropagation()">
            <h4 class="text-xl font-black text-slate-900 dark:text-slate-100 mb-6">Editar Funcionário</h4>
            
            <form id="form-edit-team-member" class="space-y-4">
                <input type="hidden" id="edit-user-id" value="${user.id}">
                <div>
                    <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Nome Completo</label>
                    <input type="text" id="edit-user-name" required value="${user.name || ''}" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium">
                </div>
                
                <div>
                    <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">E-mail</label>
                    <input type="email" id="edit-user-email" required value="${user.email || ''}" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium">
                </div>

                <div>
                    <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">WhatsApp / Telefone</label>
                    <input type="text" id="edit-user-phone" value="${user.phone || ''}" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium">
                </div>

                <div>
                    <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Nova Senha (deixe em branco para não alterar)</label>
                    <input type="password" id="edit-user-password" minlength="6" placeholder="******" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-medium">
                </div>

                <div>
                    <label class="block text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase mb-1">Cargo / Nível de Acesso</label>
                    <select id="edit-user-profile" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-bold">
                        <option value="user" ${user.profile === 'user' ? 'selected' : ''}>Usuário (Consulta e Histórico próprio)</option>
                        <option value="supervisor" ${user.profile === 'supervisor' || user.profile === 'manager' ? 'selected' : ''}>Supervisor (Consulta, Histórico geral e Equipe)</option>
                        <option value="admin" ${user.profile === 'admin' ? 'selected' : ''}>Administrador (Acesso Total)</option>
                    </select>
                </div>

                <p id="edit-member-error" class="text-red-600 text-xs font-bold hidden"></p>

                <div class="flex gap-3 pt-4">
                    <button type="button" onclick="document.getElementById('modal-edit-team-member').remove()" class="flex-1 py-3 rounded-xl border border-slate-200 dark:border-slate-600 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700">Cancelar</button>
                    <button type="submit" id="btn-update-team-member" class="flex-1 py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700">Atualizar</button>
                </div>
            </form>
        </div>
    `;

    document.body.appendChild(overlay);

    document.getElementById('form-edit-team-member').onsubmit = async function(e) {
        e.preventDefault();
        const id = document.getElementById('edit-user-id').value;
        const name = document.getElementById('edit-user-name').value.trim();
        const email = document.getElementById('edit-user-email').value.trim().toLowerCase();
        const phone = document.getElementById('edit-user-phone').value.trim();
        const password = document.getElementById('edit-user-password').value;
        const profile = document.getElementById('edit-user-profile').value;
        const errEl = document.getElementById('edit-member-error');
        const btn = document.getElementById('btn-update-team-member');

        errEl.classList.add('hidden');
        btn.disabled = true;
        btn.textContent = 'Atualizando...';

        try {
            const res = await fetch(API_BASE + 'users.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ action: 'update', id, name, email, phone, password, profile })
            });

            const data = await res.json();
            if (data.success) {
                overlay.remove();
                showToast('Funcionário atualizado com sucesso!');
                loadTeamMembers();
            } else {
                errEl.textContent = data.error || 'Erro ao atualizar funcionário.';
                errEl.classList.remove('hidden');
            }
        } catch (err) {
            errEl.textContent = 'Erro de conexão com o servidor.';
            errEl.classList.remove('hidden');
        } finally {
            btn.disabled = false;
            btn.textContent = 'Atualizar';
        }
    };
}

// Exportações globais: os botões da lista e o botão “Novo Funcionário” usam
// atributos onclick gerados dinamicamente, portanto precisam destas referências.
window.showAddTeamMemberModal = showAddTeamMemberModal;
window.showEditTeamMemberModal = showEditTeamMemberModal;

// Deletar Funcionário
async function deleteTeamMember(userId) {
    if (!confirm('Tem certeza que deseja remover este funcionário da equipe?')) return;

    try {
            const res = await fetch(API_BASE + 'users.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ action: 'update', id, name, email, phone, password, profile })
            });

            const data = await res.json();
            if (data.success) {
                overlay.remove();
                showToast('Funcionário atualizado com sucesso!');
                loadTeamMembers();
            } else {
                errEl.textContent = data.error || 'Erro ao atualizar funcionário.';
                errEl.classList.remove('hidden');
            }
        } catch (err) {
            errEl.textContent = 'Erro de conexão com o servidor.';
            errEl.classList.remove('hidden');
        } finally {
            btn.disabled = false;
            btn.textContent = 'Atualizar';
        }
    };
} 

// Deletar Funcionário
async function deleteTeamMember(userId) {
    if (!confirm('Tem certeza que deseja remover este funcionário da equipe?')) return;

    try {
        const res = await fetch(API_BASE + 'users.php', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ id: userId })
        });

        const data = await res.json();
        if (data.success) {
            showToast('Funcionário removido com sucesso!');
            loadTeamMembers();
        } else {
            alert(data.error || 'Erro ao remover funcionário.');
        }
    } catch (e) {
        alert('Erro de conexão ao remover funcionário.');
    }
}

// Renderiza a aba 'Recém-Abertas' (Fallback de segurança)
window.deleteTeamMember = deleteTeamMember;

// Renderiza a aba 'Recém-Abertas' (Fallback de segurança)
function renderLatestCompaniesTab(contentArea) {
    if (!contentArea) return;
    contentArea.innerHTML = `
        <div class="max-w-4xl mx-auto py-12 text-center">
            <h3 class="text-2xl font-black text-slate-900 dark:text-slate-100 mb-2">Empresas Recém-Abertas</h3>
            <p class="text-sm text-slate-500 dark:text-slate-400">Consulte novas empresas cadastradas no mercado.</p>
        </div>
    `;
}

// Renderiza a aba 'Landing Page' (Fallback de segurança)

async function loadSuperAdminDashboardStats() {
    try {
        const res = await fetch(API_BASE + 'admin-stats.php', { credentials: 'include' });
        const data = await res.json();
        if (data.success && data.data) {
            const d = data.data;
            
            const elCompanies = document.getElementById('stat-companies');
            const elCompaniesSub = document.getElementById('stat-companies-sub');
            const elLeads = document.getElementById('stat-leads');
            const elSearchesSub = document.getElementById('stat-searches-sub');
            const elApify = document.getElementById('stat-apify');
            const elApifySub = document.getElementById('stat-apify-sub');
            const elPending = document.getElementById('stat-pending');

            if (elCompanies) elCompanies.textContent = d.companies.total;
            if (elCompaniesSub) elCompaniesSub.textContent = `${d.companies.active} ativas · ${d.companies.suspended} suspensas`;
            
            if (elLeads) elLeads.textContent = d.leads.toLocaleString('pt-BR');
            if (elSearchesSub) elSearchesSub.textContent = `${d.searches} buscas realizadas`;
            
            if (elApify) elApify.textContent = `${d.apify.activeKeys} / ${d.apify.totalKeys}`;
            if (elApifySub) elApifySub.textContent = `${d.apify.totalUsed} execuções totais`;
            
            if (elPending) elPending.textContent = d.pendingRequests;
        }
    } catch (e) {
        console.warn("Erro ao carregar estatísticas do admin:", e);
    }
}
// Renderização e Gestão da Landing Page
function renderLandingPageTab(contentArea) {
    if (!contentArea) return;

    contentArea.innerHTML = `
        <div class="max-w-4xl mx-auto space-y-8 pb-20">
            <div>
                <h3 class="text-2xl font-black text-slate-900 dark:text-slate-100">Gerenciamento da Landing Page</h3>
                <p class="text-sm text-slate-500 dark:text-slate-400">Edite os textos, seções e chamadas da sua página inicial pública.</p>
            </div>

            <div id="landing-admin-error" class="hidden p-4 bg-red-50 border border-red-200 rounded-2xl text-red-700 text-sm font-medium"></div>
            <div id="landing-admin-success" class="hidden p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-700 text-sm font-medium"></div>

            <div id="landing-admin-sections-container" class="space-y-6">
                <div class="py-12 text-center">
                    <span class="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin inline-block"></span>
                    <p class="mt-3 text-sm font-bold text-slate-500">Carregando seções da página inicial...</p>
                </div>
            </div>
        </div>
    `;

    loadLandingAdminSections();
}

function normalizeLandingAdminSections(payload) {
    const candidates = [
        payload && payload.sections,
        payload && payload.data && payload.data.sections,
        payload && Array.isArray(payload.data) ? payload.data : null,
        payload && payload.items,
        payload && payload.data && payload.data.items
    ];
    const sections = candidates.find(function (value) { return Array.isArray(value); }) || [];
    return sections.map(function (sec) {
        const extraData = sec && (sec.extraData !== undefined ? sec.extraData : sec.extra_data);
        return Object.assign({}, sec, {
            id: sec && sec.id !== undefined ? sec.id : null,
            sectionKey: sec && (sec.sectionKey || sec.section_key) || '',
            sectionTitle: sec && (sec.sectionTitle !== undefined ? sec.sectionTitle : sec.section_title) || '',
            sectionSubtitle: sec && (sec.sectionSubtitle !== undefined ? sec.sectionSubtitle : sec.section_subtitle) || '',
            sectionContent: sec && (sec.sectionContent !== undefined ? sec.sectionContent : sec.section_content) || '',
            sectionImage: sec && (sec.sectionImage !== undefined ? sec.sectionImage : sec.section_image) || '',
            sectionOrder: sec && (sec.sectionOrder !== undefined ? sec.sectionOrder : sec.section_order) || 0,
            isActive: sec && (sec.isActive !== undefined ? sec.isActive : sec.is_active) !== false,
            extraData: extraData && typeof extraData === 'object' ? extraData : {}
        });
    });
}

async function loadLandingAdminSections() {
    const container = document.getElementById('landing-admin-sections-container');
    if (!container) return;

    try {
        const res = await fetch(API_BASE + 'landing-page.php?t=' + new Date().getTime(), {
            credentials: 'include',
            cache: 'no-store'
        });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        const responseSections = normalizeLandingAdminSections(data);
        const usingFallback = responseSections.length === 0;
        const sections = usingFallback
            ? getDefaultLandingSections().map(function (section) {
                return Object.assign({
                    id: null,
                    isFallback: true,
                    sectionImage: '',
                    sectionOrder: 0,
                    isActive: true,
                    extraData: section.extraData || {}
                }, section);
            })
            : responseSections;

        function escapeLandingAdminHtml(value) {
            return String(value == null ? '' : value)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        let html = '';
        if (usingFallback) {
            html += '<div class="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-amber-800 text-sm font-medium">' +
                'A API administrativa ainda não retornou seções cadastradas. Os campos abaixo exibem o conteúdo padrão da página inicial. Verifique se o arquivo <code>api/landing-page.php</code> está publicado e se o usuário atual é super administrador.' +
                '</div>';
        }

        sections.forEach(function (sec, index) {
                const sectionKey = sec.sectionKey || sec.section_key || ('section-' + index);
                const sectionId = sec.id !== undefined && sec.id !== null && String(sec.id).trim() !== '' ? String(sec.id) : '';
                const fieldKey = (sectionId || sectionKey || String(index)).replace(/[^a-zA-Z0-9_-]/g, '-');
                const sectionTitle = sec.sectionTitle || sec.section_title || '';
                const sectionSubtitle = sec.sectionSubtitle || sec.section_subtitle || '';
                const sectionContent = sec.sectionContent || sec.section_content || '';
                const sectionImage = sec.sectionImage || sec.section_image || '';
                const sectionOrder = Number(sec.sectionOrder !== undefined ? sec.sectionOrder : (sec.section_order || index + 1)) || index + 1;
                const isActive = sec.isActive !== undefined ? Boolean(sec.isActive) : (String(sec.is_active) !== '0');
                const extraData = sec.extraData && typeof sec.extraData === 'object'
                    ? sec.extraData
                    : (sec.extra_data && typeof sec.extra_data === 'object' ? sec.extra_data : {});
                const extraJson = JSON.stringify(extraData, null, 2);
                const submitId = sectionId || sectionKey;
                html += `
                    <div class="bg-white dark:bg-slate-800 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-600 shadow-sm space-y-4">
                        <div class="flex justify-between items-center border-b border-slate-100 dark:border-slate-700 pb-3">
                            <h4 class="font-black text-slate-900 dark:text-slate-100 text-base uppercase">SEÇÃO: ${escapeLandingAdminHtml(sectionKey)}</h4>
                            <span class="text-xs font-bold ${isActive ? 'text-emerald-700 bg-emerald-50' : 'text-slate-600 bg-slate-100'} px-3 py-1 rounded-full">${isActive ? 'Ativa' : 'Oculta'} · ${escapeLandingAdminHtml(sectionTitle || 'Sem Título')}</span>
                        </div>
                        <form onsubmit="return handleLandingSectionSubmit(event, '${escapeLandingAdminHtml(sectionId)}', '${escapeLandingAdminHtml(sectionKey)}')" class="space-y-4">
                            <div>
                                <label class="block text-[10px] font-black text-slate-400 uppercase mb-1">Título da Seção</label>
                                <input type="text" id="landing-title-${fieldKey}" value="${escapeLandingAdminHtml(sectionTitle)}" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-bold text-sm">
                            </div>
                            <div>
                                <label class="block text-[10px] font-black text-slate-400 uppercase mb-1">Subtítulo</label>
                                <input type="text" id="landing-subtitle-${fieldKey}" value="${escapeLandingAdminHtml(sectionSubtitle)}" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-bold text-sm">
                            </div>
                            <div>
                                <label class="block text-[10px] font-black text-slate-400 uppercase mb-1">Conteúdo / Texto HTML</label>
                                <textarea id="landing-content-${fieldKey}" rows="3" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl p-4 outline-none focus:border-blue-500 font-mono text-xs">${escapeLandingAdminHtml(sectionContent)}</textarea>
                            </div>
                            <div class="grid gap-4 md:grid-cols-[minmax(0,1fr)_9rem]">
                                <div>
                                    <label class="block text-[10px] font-black text-slate-400 uppercase mb-1">Imagem da seção</label>
                                    <input type="url" id="landing-image-${fieldKey}" value="${escapeLandingAdminHtml(sectionImage)}" placeholder="https://..." class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 text-sm">
                                </div>
                                <div>
                                    <label class="block text-[10px] font-black text-slate-400 uppercase mb-1">Ordem</label>
                                    <input type="number" min="0" id="landing-order-${fieldKey}" value="${escapeLandingAdminHtml(sectionOrder)}" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 outline-none focus:border-blue-500 text-sm">
                                </div>
                            </div>
                            <label class="inline-flex items-center gap-3 text-sm font-bold text-slate-700 dark:text-slate-200">
                                <input type="checkbox" id="landing-active-${fieldKey}" ${isActive ? 'checked' : ''} class="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500">
                                Exibir esta seção na página pública
                            </label>
                            <div>
                                <label class="block text-[10px] font-black text-slate-400 uppercase mb-1">Dados extras (JSON)</label>
                                <textarea id="landing-extra-${fieldKey}" rows="6" class="w-full bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-600 rounded-xl p-4 outline-none focus:border-blue-500 font-mono text-xs">${escapeLandingAdminHtml(extraJson)}</textarea>
                                <p class="mt-1 text-[11px] text-slate-500 dark:text-slate-400">Use este campo para itens, botões, links, perguntas, etapas e redes sociais da seção.</p>
                            </div>
                            <div class="text-right">
                                <button type="submit" id="btn-save-landing-${fieldKey}" data-section-id="${escapeLandingAdminHtml(sectionId)}" data-section-key="${escapeLandingAdminHtml(sectionKey)}" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-2.5 rounded-xl text-xs transition">Salvar Seção</button>
                            </div>
                        </form>
                    </div>
                `;
        });
        container.innerHTML = html;
    } catch (e) {
        container.innerHTML = `<p class="text-xs text-red-500 font-bold text-center py-6">Erro de conexão ao carregar seções. Atualize a página e tente novamente.</p>`;
    }
}

async function handleLandingSectionSubmit(e, sectionId, sectionKey) {
    if (e && e.preventDefault) e.preventDefault();

    const lookupKey = (sectionId || sectionKey || '').toString().replace(/[^a-zA-Z0-9_-]/g, '-');
    const titleEl = document.getElementById(`landing-title-${lookupKey}`);
    const subtitleEl = document.getElementById(`landing-subtitle-${lookupKey}`);
    const contentEl = document.getElementById(`landing-content-${lookupKey}`);
    const imageEl = document.getElementById(`landing-image-${lookupKey}`);
    const orderEl = document.getElementById(`landing-order-${lookupKey}`);
    const activeEl = document.getElementById(`landing-active-${lookupKey}`);
    const extraEl = document.getElementById(`landing-extra-${lookupKey}`);
    const btn = document.getElementById(`btn-save-landing-${lookupKey}`);

    if (btn) { btn.disabled = true; btn.textContent = 'Salvando...'; }

    try {
        let extraData = {};
        if (extraEl && extraEl.value.trim() !== '') {
            try {
                extraData = JSON.parse(extraEl.value);
            } catch (parseError) {
                throw new Error('O campo Dados extras precisa conter um JSON válido.');
            }
        }

        const res = await fetch(API_BASE + 'landing-page.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
                section_key: sectionKey || null,
                section_title: titleEl ? titleEl.value : '',
                section_subtitle: subtitleEl ? subtitleEl.value : '',
                section_content: contentEl ? contentEl.value : '',
                section_image: imageEl ? imageEl.value : '',
                section_order: orderEl ? Number(orderEl.value || 0) : 0,
                is_active: activeEl && activeEl.checked ? 1 : 0,
                extra_data: extraData
            })
        });

        const data = await res.json();
        if (data.success) {
            showToast(data.message || 'Seção atualizada com sucesso!');
            await loadLandingAdminSections();
        } else {
            alert(data.error || 'Erro ao salvar seção.');
        }
    } catch (err) {
        alert(err && err.message ? err.message : 'Erro de conexão ao salvar.');
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = 'Salvar Seção'; }
    }
}

// Garante visibilidade global
window.renderLandingPageTab = renderLandingPageTab;
window.handleLandingSectionSubmit = handleLandingSectionSubmit;
function openCadastroModal() {
    var landingPage = document.getElementById('landing-page');
    var loginScreen = document.getElementById('login-screen');
    
    // Oculta a landing page e abre o modal de cadastro
    if (landingPage) landingPage.style.display = 'none';
    if (loginScreen) loginScreen.style.display = 'none';
    
    showCadastro(); // Chama a função que exibe o modal de cadastro
}
// Torna global para usar nos botões
window.openCadastroModal = openCadastroModal;
// Torna global
window.renderLandingPageTab = renderLandingPageTab;
// Torna global para uso no HTML e nos botões
window.loadSuperAdminDashboardStats = loadSuperAdminDashboardStats;
window.renderLatestCompaniesTab = renderLatestCompaniesTab;
window.renderLandingPageTab = renderLandingPageTab;

console.log("MapsProspector Pro - Sistema totalmente carregado.");
