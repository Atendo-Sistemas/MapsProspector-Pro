
import React, { useState, useEffect } from 'react';
import { Lead, CRMConfig, CRMContact, SearchHistoryItem } from '../types';
import { searchLeadsOnMaps } from '../services/gemini';
import { sendBatchToN8N } from '../services/api';

interface ProspectingProps {
  config: CRMConfig;
  initialQuery?: { query: string; location: string; tag: string };
}

export const Prospecting: React.FC<ProspectingProps> = ({ config, initialQuery }) => {
  const [query, setQuery] = useState(initialQuery?.query || '');
  const [location, setLocation] = useState(initialQuery?.location || '');
  const [tag, setTag] = useState(initialQuery?.tag || '');
  const [leads, setLeads] = useState<Lead[]>([]);
  const [historyNames, setHistoryNames] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [batchLoading, setBatchLoading] = useState(false);

  useEffect(() => {
    if (initialQuery) {
        setQuery(initialQuery.query);
        setLocation(initialQuery.location);
        setTag(initialQuery.tag);
    }
  }, [initialQuery]);

  const saveToHistory = (resultsCount: number) => {
    if (resultsCount === 0) return;
    
    const newItem: SearchHistoryItem = {
      id: `hist-${Date.now()}`,
      query,
      location,
      tag,
      timestamp: new Date().toISOString(),
      resultsCount
    };

    const currentHistory = JSON.parse(localStorage.getItem('prospector_history') || '[]');
    const updatedHistory = [newItem, ...currentHistory.slice(0, 49)]; // Mantém últimos 50
    localStorage.setItem('prospector_history', JSON.stringify(updatedHistory));
  };

  const mapToCRM = (lead: Lead): CRMContact => ({
    name: lead.name,
    number: lead.phone?.replace(/\D/g, '') || "0",
    email: lead.email || "",
    cnpj: lead.cnpj || "",
    tag: tag || "prospeccao_maps",
    source: 'MapsProspector Pro',
    commentary: `Endereço: ${lead.address}`,
    extraInfo: [
      { name: 'Website', value: lead.website || '' },
      { name: 'Maps Link', value: lead.mapsUri || '' },
      { name: 'Campanha', value: tag || 'Sem Tag' },
      { name: 'Referências de Busca', value: lead.sources?.map(s => s.uri).join(', ') || '' }
    ]
  });

  const clearSearch = () => {
    if (confirm('Deseja realmente limpar todos os campos e resultados da pesquisa?')) {
      setQuery('');
      setLocation('');
      setTag('');
      setLeads([]);
      setHistoryNames([]);
    }
  };

  const performSearch = async (isLoadMore = false) => {
    if (!query) return;

    if (!config.baseUrl) {
      alert('Por favor, configure a URL do Webhook do N8N no menu lateral antes de iniciar.');
      return;
    }

    setLoading(true);
    if (!isLoadMore) {
        setLeads([]);
        setHistoryNames([]);
    }

    try {
      const currentExclude = [...historyNames, ...leads.map(l => l.name)];
      const results = await searchLeadsOnMaps(
        query, 
        location, 
        currentExclude, 
        config.selectedModel || 'gemini-3-flash-preview'
      );
      
      setLeads(isLoadMore ? [...leads, ...results] : results);
      setHistoryNames(prev => [...prev, ...results.map(r => r.name)]);

      if (!isLoadMore) {
        saveToHistory(results.length);
      }

      if (results.length === 0) {
        alert('Nenhum resultado adicional encontrado.');
      }
    } catch (err: any) {
      alert(err.message || 'Erro na pesquisa.');
    } finally {
      setLoading(false);
    }
  };

  const handleSendAll = async () => {
    if (leads.length === 0) return;
    setBatchLoading(true);
    try {
      const contacts = leads.map(mapToCRM);
      await sendBatchToN8N(config, contacts);
      alert(`Sucesso! ${contacts.length} leads enviados para o CRM.`);
    } catch (err) {
      alert('Erro ao enviar para o N8N.');
    } finally {
      setBatchLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="bg-white p-7 rounded-3xl shadow-sm border border-slate-200 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
          <div className="md:col-span-3">
            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-2 ml-1 tracking-wider">O que buscar?</label>
            <input
              className="w-full px-5 py-3.5 rounded-2xl bg-slate-50 border border-slate-200 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none text-sm transition-all"
              placeholder="Ex: Oficinas Mecânicas"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <div className="md:col-span-3">
            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-2 ml-1 tracking-wider">Localidade</label>
            <input
              className="w-full px-5 py-3.5 rounded-2xl bg-slate-50 border border-slate-200 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none text-sm transition-all"
              placeholder="Ex: Curitiba, PR"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-2 ml-1 tracking-wider">Tag CRM</label>
            <input
              className="w-full px-5 py-3.5 rounded-2xl bg-slate-50 border border-slate-200 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none text-sm transition-all"
              placeholder="Ex: maps_prospect"
              value={tag}
              onChange={(e) => setTag(e.target.value)}
            />
          </div>
          <div className="md:col-span-4 flex items-end gap-3">
            <button
              onClick={() => performSearch(false)}
              disabled={loading}
              className="flex-grow h-[52px] bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-indigo-100"
            >
              {loading ? <div className="w-5 h-5 border-2 border-white border-t-transparent animate-spin rounded-full"></div> : 'Pesquisar'}
            </button>
            <button
              onClick={clearSearch}
              title="Limpar Pesquisa"
              className="w-[52px] h-[52px] flex items-center justify-center rounded-2xl border-2 border-slate-200 text-slate-400 hover:border-red-200 hover:text-red-500 hover:bg-red-50 transition-all active:scale-95"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {leads.length > 0 && (
        <div className="flex justify-between items-center mb-6 px-2">
            <p className="text-slate-500 text-sm font-medium">Encontrados <strong>{leads.length}</strong> resultados únicos.</p>
            <button 
                onClick={handleSendAll}
                disabled={batchLoading}
                className="flex items-center gap-2 px-7 py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-2xl shadow-lg shadow-emerald-100 transition-all active:scale-[0.98]"
            >
                {batchLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent animate-spin rounded-full"></div>
                    Enviando...
                  </>
                ) : (
                  <>
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                    Exportar Tudo p/ CRM
                  </>
                )}
            </button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {leads.map((lead) => (
          <div key={lead.id} className="bg-white rounded-3xl border border-slate-200 overflow-hidden hover:border-indigo-400 hover:shadow-xl transition-all flex flex-col group">
            <div className="p-6 flex-grow">
              <h3 className="font-bold text-slate-900 text-[15px] line-clamp-2 leading-snug mb-2">{lead.name}</h3>
              <span className="text-[10px] text-slate-400 font-mono px-2 py-0.5 bg-slate-50 border border-slate-100 rounded block w-fit">
                {lead.cnpj || 'CNPJ não encontrado'}
              </span>
              <div className="mt-4 space-y-2">
                {lead.phone && <p className="text-xs font-bold text-emerald-600 truncate flex items-center gap-1.5"><span>📞</span> {lead.phone}</p>}
                {lead.email && <p className="text-xs font-semibold text-blue-600 truncate flex items-center gap-1.5"><span>✉️</span> {lead.email}</p>}
                <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed flex items-start gap-1.5"><span className="shrink-0">📍</span> {lead.address}</p>
              </div>
            </div>
            
            <div className="px-5 py-4 bg-slate-50 border-t border-slate-100 flex flex-wrap gap-2">
                {lead.website && <a href={lead.website} target="_blank" rel="noopener noreferrer" className="p-2 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-indigo-600 hover:border-indigo-200 transition-colors" title="Website Oficial">🌐</a>}
                {lead.mapsUri && <a href={lead.mapsUri} target="_blank" rel="noopener noreferrer" className="p-2 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-emerald-600 hover:border-emerald-200 transition-colors" title="Google Maps">📍</a>}
                {lead.sources?.slice(0, 2).map((source, idx) => (
                  <a key={idx} href={source.uri} target="_blank" rel="noopener noreferrer" className="p-2 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-slate-600 hover:border-slate-300 flex items-center justify-center transition-colors" title={source.title || 'Referência de Busca'}>
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.828a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /></svg>
                  </a>
                ))}
            </div>
          </div>
        ))}
      </div>

      {leads.length > 0 && (
        <div className="mt-12 mb-20 flex justify-center">
          <button
            onClick={() => performSearch(true)}
            disabled={loading}
            className="px-10 py-4 bg-white border-2 border-indigo-600 text-indigo-600 font-bold rounded-2xl hover:bg-indigo-600 hover:text-white transition-all shadow-xl shadow-indigo-100 active:scale-95"
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-indigo-600 border-t-transparent animate-spin rounded-full group-hover:border-white"></div>
                Buscando mais...
              </span>
            ) : 'Carregar mais 20 Resultados'}
          </button>
        </div>
      )}
    </div>
  );
};
