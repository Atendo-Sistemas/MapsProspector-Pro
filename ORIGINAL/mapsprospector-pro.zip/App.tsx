
import React, { useState, useEffect } from 'react';
import { CRMConfig, SearchHistoryItem, WhazingUser, WhazingTenant } from './types';
import { Prospecting } from './components/Prospecting';
import { Login } from './components/Login';

const App: React.FC = () => {
  const [auth, setAuth] = useState<{ user: WhazingUser; tenant: WhazingTenant } | null>(null);
  const [activeTab, setActiveTab] = useState<'search' | 'history' | 'settings'>('search');
  const [history, setHistory] = useState<SearchHistoryItem[]>([]);
  const [selectedHistory, setSelectedHistory] = useState<{ query: string; location: string; tag: string } | undefined>();
  const [hasApiKey, setHasApiKey] = useState<boolean>(false);
  
  const [config, setConfig] = useState<CRMConfig>({
    baseUrl: '',
    token: '',
    tenantName: 'Minha Empresa',
    selectedModel: 'gemini-3-flash-preview'
  });

  const [settingsForm, setSettingsForm] = useState<CRMConfig>({
    baseUrl: '',
    token: '',
    tenantName: '',
    selectedModel: 'gemini-3-flash-preview'
  });

  useEffect(() => {
    const checkKey = async () => {
      if (window.aistudio?.hasSelectedApiKey) {
        const selected = await window.aistudio.hasSelectedApiKey();
        setHasApiKey(selected);
      }
    };
    checkKey();

    const savedConfig = localStorage.getItem('prospector_global_config');
    if (savedConfig) {
      const parsed = JSON.parse(savedConfig);
      const finalConfig = {
        ...parsed,
        selectedModel: parsed.selectedModel || 'gemini-3-flash-preview'
      };
      setConfig(finalConfig);
      setSettingsForm(finalConfig);
    }
    loadHistory();
  }, []);

  const handleSelectKey = async () => {
    if (window.aistudio?.openSelectKey) {
      await window.aistudio.openSelectKey();
      setHasApiKey(true); // Assume sucesso após abrir o diálogo
    }
  };

  const loadHistory = () => {
    const savedHistory = localStorage.getItem('prospector_history');
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }
  };

  const saveSettings = () => {
    localStorage.setItem('prospector_global_config', JSON.stringify(settingsForm));
    setConfig(settingsForm);
    alert('Configurações salvas com sucesso!');
    setActiveTab('search');
  };

  const clearHistory = () => {
    if (confirm('Limpar todo o histórico de buscas?')) {
        localStorage.removeItem('prospector_history');
        setHistory([]);
    }
  };

  const useHistoryItem = (item: SearchHistoryItem) => {
    setSelectedHistory({
        query: item.query,
        location: item.location,
        tag: item.tag
    });
    setActiveTab('search');
  };

  if (!auth) {
    return <Login onLogin={(data) => {
      setAuth(data);
      setSettingsForm(prev => ({ ...prev, tenantName: data.tenant.name as string }));
    }} />;
  }

  return (
    <div className="flex h-screen bg-slate-50">
      <aside className="w-64 bg-slate-900 text-white flex flex-col shrink-0">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <span className="font-bold text-base leading-none">Prospector Pro</span>
          </div>
        </div>

        <nav className="flex-grow p-4 space-y-2">
          <button 
            onClick={() => setActiveTab('search')} 
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'search' ? 'bg-indigo-600 shadow-lg shadow-indigo-900/20' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            Prospecção
          </button>
          <button 
            onClick={() => {
                loadHistory();
                setActiveTab('history');
            }} 
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'history' ? 'bg-indigo-600 shadow-lg shadow-indigo-900/20' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            Histórico
          </button>
          <button 
            onClick={() => setActiveTab('settings')} 
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'settings' ? 'bg-indigo-600 shadow-lg shadow-indigo-900/20' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /></svg>
            Configurações
          </button>
        </nav>
        
        <div className="p-4 border-t border-slate-800 space-y-3">
          <div className="bg-slate-800/50 p-4 rounded-xl">
            <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Empresa</p>
            <p className="text-sm font-bold text-white truncate">{config.tenantName || auth.tenant.name}</p>
          </div>
          <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider ${hasApiKey ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'}`}>
            <div className={`w-2 h-2 rounded-full ${hasApiKey ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`}></div>
            {hasApiKey ? 'API Key Vinculada' : 'API Key Pendente'}
          </div>
        </div>
      </aside>

      <main className="flex-grow overflow-y-auto">
        <header className="bg-white border-b border-slate-200 h-16 flex items-center px-8 justify-between sticky top-0 z-40">
          <h2 className="text-slate-800 font-bold text-lg">
            {activeTab === 'search' ? 'Painel de Prospecção' : activeTab === 'history' ? 'Histórico de Buscas' : 'Configurações do Sistema'}
          </h2>
          <div className="flex items-center gap-4">
             <span className="text-xs font-bold text-slate-400">Olá, {auth.user.name.split(' ')[0]}</span>
             <button onClick={() => window.location.reload()} className="text-xs font-bold text-red-500 hover:underline">Sair</button>
          </div>
        </header>

        <div className="p-8">
          {activeTab === 'search' ? (
            <Prospecting config={config} initialQuery={selectedHistory} />
          ) : activeTab === 'history' ? (
            <div className="max-w-5xl mx-auto">
                <div className="flex justify-between items-center mb-6">
                    <p className="text-slate-500 text-sm">Registro das últimas pesquisas realizadas por você.</p>
                    <button 
                        onClick={clearHistory}
                        className="text-xs font-bold text-red-500 hover:text-red-600 px-3 py-2 rounded-lg hover:bg-red-50 transition-all"
                    >
                        Limpar Tudo
                    </button>
                </div>
                
                <div className="grid grid-cols-1 gap-4">
                    {history.length === 0 ? (
                        <div className="p-20 text-center bg-white border border-slate-200 rounded-3xl">
                            <p className="text-slate-400">Nenhuma pesquisa registrada no histórico.</p>
                        </div>
                    ) : (
                        history.map(item => (
                            <div key={item.id} className="bg-white p-6 rounded-3xl border border-slate-200 flex items-center justify-between group hover:border-indigo-300 transition-all">
                                <div className="flex items-center gap-6">
                                    <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-xl">🔍</div>
                                    <div>
                                        <h4 className="font-bold text-slate-900">{item.query}</h4>
                                        <div className="flex gap-4 mt-1">
                                            <span className="text-xs text-slate-400 flex items-center gap-1">📍 {item.location || 'Brasil'}</span>
                                            <span className="text-xs text-slate-400 flex items-center gap-1">🏷️ {item.tag || 'Sem Tag'}</span>
                                            <span className="text-xs text-slate-400 flex items-center gap-1">📅 {new Date(item.timestamp).toLocaleDateString('pt-BR')}</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="flex items-center gap-4">
                                    <span className="text-sm font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">
                                        {item.resultsCount} leads
                                    </span>
                                    <button 
                                        onClick={() => useHistoryItem(item)}
                                        className="bg-indigo-600 text-white font-bold px-5 py-2 rounded-xl text-sm shadow-lg shadow-indigo-100 opacity-0 group-hover:opacity-100 transition-all active:scale-95"
                                    >
                                        Repetir
                                    </button>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>
          ) : (
            <div className="max-w-3xl space-y-6">
                <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                  <h3 className="text-xl font-bold text-slate-900 mb-6">Integrações e Faturamento</h3>
                  
                  <div className="space-y-6">
                    <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 text-white">
                        <div className="flex items-start justify-between mb-4">
                            <div>
                                <h4 className="font-bold text-lg mb-1">Google Gemini API</h4>
                                <p className="text-xs text-slate-400 leading-relaxed max-w-md">
                                    Para evitar custos compartilhados, cada empresa deve vincular seu próprio projeto do Google Cloud com faturamento ativado.
                                </p>
                            </div>
                            <div className={`w-3 h-3 rounded-full ${hasApiKey ? 'bg-emerald-500' : 'bg-amber-500'}`}></div>
                        </div>

                        <div className="flex flex-col gap-3">
                            <button 
                                onClick={handleSelectKey}
                                className="flex items-center justify-center gap-2 w-full py-4 bg-white text-slate-900 font-bold rounded-xl hover:bg-slate-100 transition-all active:scale-[0.98]"
                            >
                                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.66l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
                                {hasApiKey ? 'Alterar Chave da Empresa' : 'Vincular Conta Google Cloud'}
                            </button>
                            <a 
                                href="https://ai.google.dev/gemini-api/docs/billing" 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-center text-[10px] text-slate-500 hover:text-white transition-colors"
                            >
                                Como configurar o faturamento e obter uma chave paga?
                            </a>
                        </div>
                    </div>

                    <div className="border-t pt-6">
                      <label className="block text-sm font-bold text-slate-700 mb-2">Nome da Empresa (Visual)</label>
                      <input 
                        type="text"
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 outline-none focus:border-indigo-500 transition-all"
                        placeholder="Ex: Atendo Log"
                        value={settingsForm.tenantName || ''}
                        onChange={(e) => setSettingsForm(prev => ({ ...prev, tenantName: e.target.value }))}
                      />
                    </div>

                    <div className="border-t pt-6">
                        <label className="block text-sm font-bold text-slate-700 mb-2">Modelo de IA Preferencial</label>
                        <select 
                            className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 outline-none focus:border-indigo-500 transition-all appearance-none cursor-pointer"
                            value={settingsForm.selectedModel}
                            onChange={(e) => setSettingsForm(prev => ({ ...prev, selectedModel: e.target.value as any }))}
                        >
                            <option value="gemini-3-flash-preview">Gemini 3 Flash (Recomendado - Veloz e Barato)</option>
                            <option value="gemini-3-pro-preview">Gemini 3 Pro (Especializado - Lento e Preciso)</option>
                        </select>
                    </div>

                    <div className="border-t pt-6">
                      <label className="block text-sm font-bold text-slate-700 mb-2">URL do Webhook N8N (Exportação CRM)</label>
                      <input 
                        type="url"
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 outline-none focus:border-indigo-500 transition-all"
                        placeholder="https://webhook.atendo.log.br/webhook/..."
                        value={settingsForm.baseUrl}
                        onChange={(e) => setSettingsForm(prev => ({ ...prev, baseUrl: e.target.value }))}
                      />
                    </div>

                    <button 
                      onClick={saveSettings}
                      className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-2xl shadow-lg transition-all active:scale-[0.99]"
                    >
                      Salvar Configurações
                    </button>
                  </div>
                </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
