
import { CRMConfig, CRMContact } from '../types';

export const sendBatchToN8N = async (config: CRMConfig, contacts: CRMContact[]) => {
  if (contacts.length === 0) return;
  
  try {
    const response = await fetch(config.baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.token}`
      },
      body: JSON.stringify({
        event: 'bulk_lead_prospecting',
        count: contacts.length,
        data: contacts.map(c => ({
          ...c,
          timestamp: new Date().toISOString()
        }))
      }),
      mode: 'cors'
    });
    
    if (!response.ok) {
        throw new Error(`Erro no Webhook N8N: ${response.status}`);
    }
    
    return true;
  } catch (error) {
    console.error('Erro ao enviar lote para N8N:', error);
    throw error;
  }
};

export const sendSingleToN8N = async (config: CRMConfig, contact: CRMContact) => {
    return sendBatchToN8N(config, [contact]);
};
