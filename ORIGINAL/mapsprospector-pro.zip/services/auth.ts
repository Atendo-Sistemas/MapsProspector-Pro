
import { WhazingUser, WhazingTenant } from '../types';

// URL do Webhook do n8n para validação de e-mail
const N8N_WEBHOOK_URL = "https://webhook.atendo.log.br/webhook/e165e89c-d9a2-42c6-8ba9-bcf6c3c2389e";

export const validateWhazingUser = async (email: string): Promise<{ user: WhazingUser; tenant: WhazingTenant } | null> => {
  const cleanEmail = email.toLowerCase().trim();
  
  console.log(`[Auth] Tentando validar: ${cleanEmail}`);
  
  try {
    const response = await fetch(N8N_WEBHOOK_URL, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({ 
        email: cleanEmail,
        timestamp: new Date().toISOString()
      }),
      // 'cors' é essencial para que o navegador permita a requisição ao seu subdomínio n8n
      mode: 'cors' 
    });
    
    if (!response.ok) {
      console.error(`[Auth] Erro HTTP: ${response.status}`);
      return null;
    }
    
    const rawData = await response.json();
    console.log(`[Auth] Resposta do n8n:`, rawData);

    // O n8n enviou um array: [{ allowed: true, companyId: 19, ... }]
    const data = Array.isArray(rawData) ? rawData[0] : rawData;

    if (data && data.allowed === true) {
      // Mapeamos os campos do seu n8n para os tipos da aplicação
      return {
        user: {
          id: data.email, // Usando email como ID do usuário já que o n8n não enviou um userId
          name: data.email.split('@')[0], // Nome amigável baseado no e-mail
          email: data.email,
          tenantId: data.companyId,
          profile: data.plan || 'active'
        },
        tenant: {
          id: data.companyId,
          name: data.companyName || 'Empresa'
        }
      };
    }
    
    console.warn("[Auth] Usuário não autorizado ou formato de resposta inesperado.");
    return null;
  } catch (error: any) {
    console.error("[Auth] Erro na requisição ao Webhook:", error);
    throw new Error("Não foi possível validar seu acesso. Verifique se o seu n8n está online e com o Webhook ativo.");
  }
};
