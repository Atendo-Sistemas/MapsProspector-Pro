
import { GoogleGenAI } from "@google/genai";
import { Lead } from "../types";

export const searchLeadsOnMaps = async (
  query: string, 
  location?: string, 
  excludeNames: string[] = [],
  modelName: string = "gemini-3-flash-preview"
): Promise<Lead[]> => {
  // A chave é injetada automaticamente em process.env.API_KEY pelo diálogo de seleção do aistudio
  const apiKey = process.env.API_KEY;
  
  if (!apiKey) {
    throw new Error("Atenção: Sua empresa ainda não vinculou uma conta Google Cloud. Vá em 'Configurações' para ativar a busca.");
  }

  // Criamos uma nova instância a cada busca para garantir o uso da chave mais recente
  const ai = new GoogleGenAI({ apiKey });

  const exclusionText = excludeNames.length > 0 
    ? `Ignore estas empresas: ${excludeNames.join(", ")}.` 
    : "";

  const prompt = `Gere uma lista de 20 leads B2B reais para "${query}" em "${location || 'Brasil'}".
  
  ${exclusionText}
  
  Extraia (usando Google Search/Maps):
  - Nome, Endereço completo, Telefone (formato internacional +55...), E-mail de contato, Website, Maps Link e CNPJ se disponível.

  RETORNO: JSON array puro. 
  Campos: "name", "address", "phone", "email", "website", "mapsUri", "cnpj".
  Valores nulos para dados não encontrados. Sem markdown.`;

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json"
      },
    });

    const text = response.text;
    if (!text) return [];

    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const extractedSources = groundingChunks?.map((chunk: any) => ({
      title: chunk.web?.title,
      uri: chunk.web?.uri
    })).filter((s: any) => s.uri) || [];

    const parsedResults = JSON.parse(text);
    if (Array.isArray(parsedResults)) {
      return parsedResults.map((item: any, index: number) => ({
        id: `lead-${Date.now()}-${index}`,
        name: item.name || "Empresa sem Nome",
        address: item.address || "Localização não disponível",
        phone: item.phone || "",
        email: item.email || "",
        website: item.website || "",
        mapsUri: item.mapsUri || "",
        cnpj: item.cnpj || "",
        sources: extractedSources
      }));
    }

    return [];
  } catch (error: any) {
    console.error(`Erro Gemini (${modelName}):`, error);
    
    if (error.message?.includes("Requested entity was not found")) {
        throw new Error("Erro de Credenciais: O projeto Google Cloud vinculado não foi encontrado ou não tem a API Gemini ativada. Verifique as configurações.");
    }
    
    throw new Error("Erro ao processar busca. Tente alternar o modelo para 'Pro' nas configurações ou verifique sua conexão.");
  }
};
