
export interface CRMConfig {
  baseUrl: string;
  token: string;
  tenantName?: string;
  selectedModel?: 'gemini-3-flash-preview' | 'gemini-3-pro-preview';
}

export interface SearchHistoryItem {
  id: string;
  query: string;
  location: string;
  tag: string;
  timestamp: string;
  resultsCount: number;
}

export interface Lead {
  id: string;
  name: string;
  address: string;
  phone?: string;
  email?: string;
  website?: string;
  mapsUri?: string;
  cnpj?: string;
  tag?: string;
  sources?: { title?: string; uri: string }[];
}

export interface CRMContact {
  name: string;
  number: string;
  email?: string;
  cnpj?: string;
  tag?: string;
  extraInfo?: { name: string; value: string }[];
  commentary?: string;
  source?: string;
}

export interface WhazingUser {
  id: string | number;
  name: string;
  email: string;
  tenantId: string | number;
  profile: string;
}

export interface WhazingTenant {
  id: string | number;
  name: string;
}
